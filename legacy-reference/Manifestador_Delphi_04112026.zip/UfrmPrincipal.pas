unit UfrmPrincipal;

interface

uses
  Winapi.Windows, Winapi.Messages, System.SysUtils, System.Variants, System.Classes, Vcl.Graphics,
  Vcl.Controls, Vcl.Forms, Vcl.Dialogs, Vcl.ComCtrls, System.Actions,
  Vcl.ActnList, Vcl.ToolWin, Vcl.Grids, Vcl.DBGrids, Vcl.Menus, Vcl.ImgList,
  Data.DB, Vcl.ExtCtrls, Vcl.StdCtrls, pcnConversao, System.ImageList;

type
  TfrmPrincipal = class(TForm)
    StatusBar1: TStatusBar;
    ActionList1: TActionList;
    DBGrid1: TDBGrid;
    CoolBar1: TCoolBar;
    MainMenu1: TMainMenu;
    Arquivo1: TMenuItem;
    ToolBar1: TToolBar;
    ToolBar2: TToolBar;
    ActionArquivoSair: TAction;
    Sair1: TMenuItem;
    ActionObterNotas: TAction;
    ActionManifestar: TAction;
    ActionDownload: TAction;
    ActionVisualizar: TAction;
    ImageList: TImageList;
    ToolButton1: TToolButton;
    ToolButton2: TToolButton;
    ToolButton3: TToolButton;
    ToolButton4: TToolButton;
    ToolButton5: TToolButton;
    DataSource: TDataSource;
    Panel1: TPanel;
    gbxPeriodo: TGroupBox;
    edDataInicial: TDateTimePicker;
    edDataFinal: TDateTimePicker;
    ActionEmpresas: TAction;
    Configuraes1: TMenuItem;
    rgFiltro: TRadioGroup;
    PopupMenuGrid: TPopupMenu;
    Manifestar1: TMenuItem;
    Download1: TMenuItem;
    Visualizar1: TMenuItem;
    gbxEmpresa: TGroupBox;
    ComboBoxEmpresa: TComboBox;
    ActionPDF: TAction;
    ToolButton6: TToolButton;
    ActionEnviarContabilidade: TAction;
    EnviarXMLcontabilidade1: TMenuItem;
    N1: TMenuItem;
    ActionConfig: TAction;
    Configuraes2: TMenuItem;
    Splitter1: TSplitter;
    DBGrid2: TDBGrid;
    dsNF_LOG: TDataSource;
    ActionImportar: TAction;
    ToolButton7: TToolButton;
    acConfDB: TAction;
    ConfigurarBancodeDados1: TMenuItem;
    LblTimer: TLabel;
    procedure ActionArquivoSairExecute(Sender: TObject);
    procedure FormCreate(Sender: TObject);
    procedure edDataInicialChange(Sender: TObject);
    procedure ActionObterNotasExecute(Sender: TObject);
    procedure ActionEmpresasExecute(Sender: TObject);
    procedure ActionManifestarExecute(Sender: TObject);
    procedure ActionVisualizarExecute(Sender: TObject);
    procedure ActionDownloadExecute(Sender: TObject);
    procedure DBGrid1DblClick(Sender: TObject);
    procedure ActionPDFExecute(Sender: TObject);
    procedure ComboBoxEmpresaChange(Sender: TObject);
    procedure ActionEnviarContabilidadeExecute(Sender: TObject);
    procedure ActionConfigExecute(Sender: TObject);
    procedure ActionImportarExecute(Sender: TObject);
    procedure acConfDBExecute(Sender: TObject);
    procedure FormClose(Sender: TObject; var Action: TCloseAction);
    procedure FormShow(Sender: TObject);
  private

    { Private declarations }
    procedure ListarNotas;
    procedure ExibirEmpresas;
    procedure Manifestar;
    procedure AtualizarComboBoxEmpresas;
    procedure StatusBarUpdadte;

  public
    { Public declarations }

  end;

var
  frmPrincipal: TfrmPrincipal;

implementation

uses
  UDMManifestador, UFrmOpcoesManifestar, UFrmEmpresas,
  UfrmEnviarXMLContabilidade, UfrmConfig, uConfACBrDFe,
  uWKConnectionParams;

{$R *.dfm}

procedure TfrmPrincipal.FormClose(Sender: TObject; var Action: TCloseAction);
begin
FWKConnectionClass.ForceEndApplication;
end;

procedure TfrmPrincipal.FormCreate(Sender: TObject);
begin

  if DMManifestador.FDConnection1.Connected then
    DMManifestador.MainLoaderSystem;

  // Inicializa��o da data inicia e final dos �ltimos 3 meses
  edDataInicial.Date := Date - 90;
  edDataFinal.Date := Date;

  // Seta as Actions "Manifestar", "Download" e "Visualizar" para que possam
  // ser habilitadas/desabilidadas conforme a situa��o de cada xml
  DMManifestador.ActionManifestar  := ActionManifestar;
  DMManifestador.ActionDownload    := ActionDownload;
  DMManifestador.ActionVisualizar  := ActionVisualizar;
  // Exibe as notas fiscais
  ListarNotas;
  // Exibe tela de configura��o no primeiro acesso
  if (DMManifestador.ZQueryEMPRESA.RecordCount = 0) then
    ExibirEmpresas;

  // Lista as empresas no CombBox
  AtualizarComboBoxEmpresas;

end;

procedure TfrmPrincipal.FormShow(Sender: TObject);
begin
  // Atualiza a status bar com a informa��o do atual do ambiente do webservice da receita
  StatusBarUpdadte;
end;

procedure TfrmPrincipal.edDataInicialChange(Sender: TObject);
begin

  // Ao alterar a data inicial o final atualiza a lista de notas fiscais
  if (DMManifestador.ZQueryNF.Active) then
    ListarNotas;

end;

procedure TFrmPrincipal.ListarNotas;
begin

  // Verifica o filtro desejado na exibi��o das notas fiscais
  case rgFiltro.ItemIndex of

    // Todas
    0: DMManifestador.ListarNotas(edDataInicial.Date, edDataFinal.Date, False, False);

    // Baixadas
    1: DMManifestador.ListarNotas(edDataInicial.Date, edDataFinal.Date, True, False);

    // Manifestadas
    2: DMManifestador.ListarNotas(edDataInicial.Date, edDataFinal.Date, False, True);

  end;

end;

procedure TfrmPrincipal.ExibirEmpresas;
begin

  // Exibe o di�logo de cadastro de empresas

  try

    frmEmpresas := TfrmEmpresas.Create(Self);

    if (frmEmpresas.ShowModal = mrOk) then
      AtualizarComboBoxEmpresas;

    ActionObterNotas.Enabled := DMManifestador.ZQueryEMPRESA.RecordCount > 0;

  finally

    FreeAndNil(frmEmpresas);

  end;

end;

procedure TFrmPrincipal.AtualizarComboBoxEmpresas;
var
  ItemIndexAnterior: Integer;
begin

  if DMManifestador.ZQueryEmpresa.IsEmpty then
    Exit;

  // Memoriza em qual empresa o usu�rio estava trabalhando
  ItemIndexAnterior := ComboBoxEmpresa.ItemIndex;
  // Limpa a lista de empresas
  ComboBoxEmpresa.Items.Clear;

  // Percorre o cadastro de empresas adicionando os nomes na combobox
  with DMManifestador.ZQueryEMPRESA do
  begin

    First;

    while not Eof do
    begin

      ComboBoxEmpresa.Items.Add(DMManifestador.ZQueryEMPRESANOME.AsString);
      Next;

    end;

    First;

  end;

  // Posicionando a combobox na empresa selecionada anteriormente
  if (ComboBoxEmpresa.Items.Count > 0)  then
  begin

    // No primeiro acesso n�o tem ItemIndexAnterior ent�o posiciona na primeira empresa
    if (ItemIndexAnterior= -1) then
      ComboBoxEmpresa.ItemIndex := 0
    else
      ComboBoxEmpresa.ItemIndex := ItemIndexAnterior;

    // For�a evento Change do combobox para sincronizar com a ZQueryEmpresa
    ComboBoxEmpresaChange(ComboBoxEmpresa)

  end;

end;

procedure TfrmPrincipal.ComboBoxEmpresaChange(Sender: TObject);
begin

  // Ao selecionar a empresa que usu�rio deseja trabalhar, posiciona o ponteiro da
  // ZQuery para a empresa selecionada no combobox
  DMManifestador.ZQueryEMPRESA.Locate('NOME', ComboBoxEmpresa.Text, []);
  // Carrega as configura��es do Acbr para a empresa selecionada
  DMManifestador.ConfigurarAcbr(DMManifestador.ACBrNFe);
  // Atualiza a lista de notas
  ListarNotas;

end;

procedure TfrmPrincipal.Manifestar;
begin

  // Exibe o di�logo com as op��es de manifesta��o
  try

    FrmOpcoesManifestar := TFrmOpcoesManifestar.Create(Self);

    // Se usu�rio escolher Ok no di�logo ent�o dispara a rotina de manifesto
    if (FrmOpcoesManifestar.ShowModal = mrOk) then
      DMManifestador.Manifestar(DMManifestador.ZQueryNFCODIGO.AsInteger,
                                FrmOpcoesManifestar.RadioGroup1.ItemIndex,
                                DMManifestador.ZQueryNFCHAVE.AsString,
                                True,
                                FrmOpcoesManifestar.edMotivo.Text);

  finally

    FrmOpcoesManifestar.Free;

  end;

end;

procedure TfrmPrincipal.StatusBarUpdadte;
begin

  if (DMManifestador.ACBRNFe.Configuracoes.WebServices.Ambiente = taProducao) then
    StatusBar1.Panels[0].Text := 'Ambiente: Produ��o'
  else
    StatusBar1.Panels[0].Text := 'Ambiente: Homologa��o';

end;

procedure TfrmPrincipal.ActionEmpresasExecute(Sender: TObject);
begin

  // Exibe o di�logo das configura��es do App
  ExibirEmpresas;

end;

procedure TfrmPrincipal.ActionEnviarContabilidadeExecute(Sender: TObject);
begin

  // Exibe o formul�rio de envio de xml para a contabilidade
  frmEnviarXMLContabilidade := TfrmEnviarXMLContabilidade.Create(Self);

  try

    frmEnviarXMLContabilidade.ShowModal;

  finally

    FreeAndNil(frmEnviarXMLContabilidade);

  end;

end;

procedure TfrmPrincipal.ActionImportarExecute(Sender: TObject);
var
 PathDownload: String;
begin

  {$REGION ' Desabilitado '}
  {
    if (DMManifestador.Importar(DMManifestador.ZQueryNFCODIGO.AsInteger, DMManifestador.ACBrNFe.Configuracoes.Arquivos.DownloadDFe.PathDownload + '\' + DMManifestador.ZQueryNFCHAVE.AsString + '-nfe.xml')) then
      ShowMessage('Dados da nota fiscal importados com sucesso!');
  }
  {$ENDREGION}

  PathDownload :=
  GetPathDFe(
              TConfNFe,TPathXMLRecebidos,TCreateDefaultPath,TCustonPathAfter,
              FormatDateTimeToString(DMManifestador.ZQueryNFEMISSAO.AsDateTime, 'YYYYMM'),
              DMManifestador.ZQueryEmpresaNOME.AsString + ' - ' + OnlyNumbers(DMManifestador.ZQueryEmpresaCNPJ.AsString)
            );

  if (DMManifestador.Importar(DMManifestador.ZQueryNFCODIGO.AsInteger, PathDownload + DMManifestador.ZQueryNFCHAVE.AsString + '-nfe.xml')) then
    ShowMessage('Dados da nota fiscal importados com sucesso!');

end;

procedure TfrmPrincipal.ActionConfigExecute(Sender: TObject);
begin

  // Exibe formul�rio de configura��es
  frmConfig := TfrmConfig.Create(Self);

  try

    if (frmConfig.ShowModal = mrOk) then
      DMManifestador.ConfigurarTimer;

  finally

    FreeAndNil(frmConfig);

  end;

end;

procedure TfrmPrincipal.ActionDownloadExecute(Sender: TObject);
begin

  // Efetua o download da nota fiscal atual
  DMManifestador.Download(DMManifestador.ZQueryNFCODIGO.AsInteger,
                          DMManifestador.ZQueryNFCHAVE.AsString,
                          True,
                          DMManifestador.ZQueryNFNSU.AsString);

end;

procedure TfrmPrincipal.ActionManifestarExecute(Sender: TObject);
begin

  // Exibe o dialog de manifesta��o
  Manifestar;

end;

procedure TfrmPrincipal.ActionObterNotasExecute(Sender: TObject);
begin
  //DMManifestador.ObterNotas;

  TThread.CreateAnonymousThread(
    procedure
    begin

      //DMManifestador.ObterNotas;

      TThread.Synchronize(TThread.CurrentThread,
        procedure
        begin

          // Verifica no webservice se existem novas notas fiscais dispon�veis
          DMManifestador.ObterNotas;

        end);

    end).Start;

end;

procedure TfrmPrincipal.ActionPDFExecute(Sender: TObject);
begin

  // Gera PDF do Danfe da NFe
  DMManifestador.Visualizar(True);

end;

procedure TfrmPrincipal.ActionVisualizarExecute(Sender: TObject);
begin

  // Exibe visualiza��o da impress�o da NFe
  DMManifestador.Visualizar(False);

end;

procedure TfrmPrincipal.DBGrid1DblClick(Sender: TObject);
begin

  // Visualiza o danfe do xml caso esteja dispon�vel
  DMManifestador.Visualizar(False);

end;

procedure TfrmPrincipal.acConfDBExecute(Sender: TObject);
begin
  FWKConnectionClass.RunConfiguraDB;
end;

procedure TfrmPrincipal.ActionArquivoSairExecute(Sender: TObject);
begin

  // Termina a aplica��o
  // Application.Terminate;
  FWKConnectionClass.ForceEndApplication;

end;

end.
