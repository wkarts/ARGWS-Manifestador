unit UFrmOpcoesManifestar;

interface

uses
  Winapi.Windows, Winapi.Messages, System.SysUtils, System.Variants, System.Classes, Vcl.Graphics,
  Vcl.Controls, Vcl.Forms, Vcl.Dialogs, Vcl.StdCtrls, Vcl.ExtCtrls;

type
  TFrmOpcoesManifestar = class(TForm)
    RadioGroup1: TRadioGroup;
    Button1: TButton;
    Button2: TButton;
    gbxMotivo: TGroupBox;
    edMotivo: TEdit;
    procedure RadioGroup1Click(Sender: TObject);
    procedure FormClose(Sender: TObject; var Action: TCloseAction);
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  FrmOpcoesManifestar: TFrmOpcoesManifestar;

implementation

{$R *.dfm}

procedure TFrmOpcoesManifestar.RadioGroup1Click(Sender: TObject);
begin

  gbxMotivo.Visible := RadioGroup1.ItemIndex = 2;

  if (not gbxMotivo.Visible) then
    edMotivo.Clear;

end;

procedure TFrmOpcoesManifestar.FormClose(Sender: TObject; var Action: TCloseAction);
begin

  if (Self.ModalResult = MrOk) then
  begin

    if (gbxMotivo.Visible) and (Length(edMotivo.Text) <= 14) then
    begin

      ShowMessage('O motivo deve ter pelo menos 15 caracteres!');
      edMotivo.SetFocus;
      Action := caNone;

    end;

  end;

end;

end.
