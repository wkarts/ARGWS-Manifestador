unit RMServices;

interface

uses
  SysUtils, RM;

type
  TRMServices = class

  public

    function Incluir(RM: TRM; IdManifestador: Integer; ExibirDialogo: Boolean): Boolean;
    function Existe(Chave: String): Boolean;
    function ExisteItems(Chave: String): Boolean;
    function ObterCodigoFornecedor(Empresa: Integer; CNPJ: String): Integer;
    function ObterCodigoTransportadora(Empresa: Integer; CNPJ: String): Integer;
    procedure AtualizarDestinada(Chave, Integrado: String);
    procedure Excluir(Chave: String; NSU: String); overload;
    procedure Excluir(IdRM: Integer); overload;
    procedure ExcluirRMF(IdRM: Integer);
    function ImportarXMLNFe(CNJDestinatario, ArqXML: String): Boolean;
    function ObterId(ChaveNFe: String): Integer;
    function ExtrairChaveAcessoXML(ArquivoXML: String): String;

  end;

implementation

uses RMRepository, UDMXMLNFE;

{ TRMServices }


function TRMServices.Incluir(RM: TRM; IdManifestador: Integer; ExibirDialogo: Boolean): Boolean;
begin

  Result := False;

  try

    //Servicos.Firebird.StartTransaction();
    RM.Id := TRMRepository.ObterGenerator;
    TRMRepository.Incluir(RM);
    
    if (IdManifestador > 0) then
      TManifestadorRepository.GerarEvento(IdManifestador, 0, 0, 'Integra��o efetuada');
      
    Servicos.Firebird.CommitTransaction();
    Result := True;

  except

    on E:Exception do
    begin

      Servicos.Firebird.RollbackTransaction();
      raise Exception.Create('TRMServices.Incluir -> ' + E.Message);

    end;

  end;

end;

procedure TRMServices.Excluir(Chave, NSU: String);
begin

  try

    TRMRepository.Delete(Chave, NSU);

  except

    on E:Exception do
    begin

      raise Exception.Create('TRMServices.Excluir -> ' + E.Message);

    end;

  end;

end;

procedure TRMServices.ExcluirRMF(IdRM: Integer);
begin

  TRMRepository.ExcluirRMF(IdRM);

end;

procedure TRMServices.Excluir(IdRM: Integer);
begin

  try

    TRMRepository.Delete(IdRM);

  except

    on E:Exception do
    begin

      raise Exception.Create('TRMServices.Excluir -> ' + E.Message);

    end;

  end;

end;

function TRMServices.ImportarXMLNFe(CNJDestinatario, ArqXML: String): Boolean;
var
  Chave: String;
begin

  DMXMLNFE := TDMXMLNFE.Create(nil);

  try

    DMXMLNFE.CNPJDestinado := CNJDestinatario;

    try


      DMXMLNFE.NomeArquivoXML := ArqXML;
      DMXMLNFE.NSU := '';
      DMXMLNFE.IdManifestador := 0;
      Result := DMXMLNFE.Importar;

    except

      on E:Exception do
      begin

        Servicos.Dialogos.Erro('TRMServices.ImportarXMLNFe -> ' + E.Message);

      end;

    end;

  finally

    FreeAndNil(DMXMLNFE);

  end;

end;

function TRMServices.ObterId(ChaveNFe: String): Integer;
begin

  try

    Result := TRMRepository.SelectIdByChaveNfe(ChaveNFe);

  except

    on E:Exception do
    begin

      raise Exception.Create('TRMServices.Excluir -> ' + E.Message);

    end;

  end;

end;

function TRMServices.ExtrairChaveAcessoXML(ArquivoXML: String): String;
begin

  DMXMLNFE := TDMXMLNFE.Create(nil);

  try

    try

      DMXMLNFE.ACBrNFe1.NotasFiscais.LoadFromFile(ArquivoXML);
      Result := Copy(DMXMLNFE.ACBrNFe1.NotasFiscais.Items[0].NFe.infNFe.ID, 4, 44);

    except

      on E:Exception do
      begin

        Servicos.Dialogos.Erro('TRMServices.ExtrairChaveAcessoXML -> ' + E.Message);

      end;

    end;

  finally

    FreeAndNil(DMXMLNFE);

  end;

end;

end.
