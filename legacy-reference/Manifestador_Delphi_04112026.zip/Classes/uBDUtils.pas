unit uBDUtils;

interface
uses
  db, controls, dbClient;

type
  TBdUtTransIsolationLevel = (tilREADCOMMITTED, tilREPEATABLEREAD, tilDIRTYREAD, tilCUSTOM);

  TDynamicClientDataSet = class(TClientDataSet)
  public
    function AddField( const FieldName: String; DataType: TFieldType;
      Size: Integer = 0; Required: Boolean = FALSE) : TDynamicClientDataSet;
  end;


  TBDUtilsType = (bdutDBExpress, bdutIBX);

  TBDUtils = class(TObject)
  private
    FSQLCommand: String;
    procedure SetConexao(const Value: TCustomConnection);
    procedure SetSQLCommand(const Value: String);
  protected
    FConexao: TCustomConnection;
  public
    function CriarQuery (Query: String; Parametros: array of variant) : TDataSet; virtual; abstract;
    function CriarStoredProcedure (NomeStoredProcedure: String; Parametros: array of variant): TDataSet; virtual; abstract;
    function ExecutarSQL (Query: String; Parametros: array of variant; lancarExcecao : Boolean = FALSE): Integer; virtual; abstract;
    function CriarClientDataSet : TDynamicClientDataSet;
    function ObterValorCampo (ExprSQL: String; ValorDefault : String) : String;  overload; virtual; abstract;
    function ObterValorCampo (ExprSQL: String; ValorDefault : Integer) : Integer; overload; virtual; abstract;
    function ObterValorCampo (ExprSQL: String; ValorDefault : Double) : Double; overload; virtual; abstract;
    function ObterValorCampo (ExprSQL: String; ValorDefault : Boolean) : Boolean; overload; virtual; abstract;
    function ObterValorCampoData (ExprSQL: String; ValorDefault : TDate) : TDate; virtual; abstract;
    function ObterValorGenerator(NomeGenerator: string; Incremento: integer = 1): integer; virtual; abstract;
    procedure IniciarTransacao(IDTransacao: integer = 1;  NivelIsolamento: TBdUtTransIsolationLevel = tilREADCOMMITTED); virtual; abstract;
    procedure ConfirmarTransacao(IDTransacao : Integer = 1); virtual; abstract;
    procedure CancelarTransacao(IDTransacao : Integer = 1); virtual; abstract;
    function EmTransacao(IDTransacao: Integer = 1): boolean; virtual; abstract;
    property Conexao : TCustomConnection read FConexao write SetConexao;
    property SQLCommand: String read FSQLCommand write SetSQLCommand;
  end;
var
  bdUtils : TBDUtils;

implementation



{ TBDUtils }
function TBDUtils.CriarClientDataSet : TDynamicClientDataSet;
begin
  Result := TDynamicClientDataSet.Create(nil);
end;


procedure TBDUtils.SetConexao(const Value: TCustomConnection);
begin
  FConexao := Value;
end;


procedure TBDUtils.SetSQLCommand(const Value: String);
begin
  FSQLCommand := Value;
end;

{ TDynamicClientDataSet }
function TDynamicClientDataSet.AddField(const FieldName: String;
  DataType: TFieldType; Size: Integer;
  Required: Boolean): TDynamicClientDataSet;
begin
  Self.FieldDefs.Add(FieldName, DataType, Size, Required);
  Result := Self;
end;

end.
