﻿{$HINTS OFF}
unit uWKConnectionParams;


interface

uses

    UDMManifestador,
    uConfiguraDB,

  {$REGION ' Unit''s SimpleORM '}

    SimpleDS,
    SimpleInterface,
    SimpleAttributes,
    SimpleQueryFiredac,
    SimpleQueryUnidac,
    SimpleQueryRestDW,
    SimpleDAO,
    Simple.Provider,
    SimpleTypes,

  {$ENDREGION}

  ActiveX,

  dxAlertWindow,

  Data.DB,
  FireDAC.Comp.Client,
  FireDAC.Phys.FB,
  Uni,
  IBX.IBDatabase,
  IBX.IBQuery,
  InterBaseUniProvider,

  IdHashMessageDigest,

  LocalCache4D,

  JclDebug,

  System.Classes,
  System.Variants,
  System.StrUtils,
  System.SysUtils,
  System.Win.Registry,
  System.Generics.Collections,
  System.ImageList,
  System.IOUtils,
  System.UITypes,
  System.Types,
  System.Net.HttpClient,
  System.Net.URLClient,
  System.Net.Mime,
  System.JSON,
  System.DateUtils,
  System.Math,
  System.NetEncoding,
  System.Hash,
  System.Win.ComObj,
  System.TypInfo,
  System.SyncObjs,

  IdHMAC,
  IdHMACSHA1,
  IdGlobal,
  IdHTTP,
  IdSSLOpenSSL,

  EncdDecd,
  DelphiZXIngQRCode,

  Winapi.TlHelp32,
  Winapi.ShellAPI,
  Winapi.Windows,
  ACBr_WinCrypt,

  Vcl.AppEvnts,
  Vcl.Dialogs,
  Vcl.Forms,
  VcL.Graphics,
  Vcl.Imaging.jpeg,
  Vcl.OleCtrls,
  Vcl.Clipbrd,
  Vcl.ComCtrls,
  Vcl.Controls,
  Vcl.ExtCtrls,
  Vcl.StdCtrls,

  GoogleOTP,

  SuperObject,

  REST.Response.Adapter,

  SHDocVw,
  MSHTML;

 {$REGION ' TUCCriptografia '}

type
  TUCCriptografia = (cPadrao, cMD5);

 {$ENDREGION}

 {$REGION ' TExceptionInfo '}

 type
  TExceptionType = (ACViolation, ACExcept);

 type
  TExceptionInfo = record
    NomeForm             : string;
    NomeComponente       : string;
    ClasseErro           : string;
    MensagemErro         : string;
    StackTrace           : string;
    USE_DYNAMIC_LOG_NAME : Boolean;
    USU_DYNAMIC_TILE     : Boolean;
    public
    function  FormatInfo(TTYPE: TExceptionType): string;
  end;

 {$ENDREGION}

 {$REGION ' TParamsOptions '}

 type
  TParamsOptions = record
  	SERVER              : string;
    PORT                : string;
    LIBCON              : string;
    PROTOCOL            : string;
    CHARSET             : string;
    MAINDB              : string;
    IMGDB               : string;
    PASSWDDB            : string;
    LOGINDB             : string;
    COMPANY             : string;
    RAZAO               : string;
    COMPANYID           : string;
    USUARIO             : string;
    USUARIOID           : string;
    USUARIOPASSWD       : string;
    MULTIEMP            : Boolean;
    FORCEKILL           : Integer;
    VERSION             : string;
    FULLSCREENPDV       : Boolean;
    AUTOBACKUP          : Boolean;
    NOCHECKLIC          : Boolean;
    MODEDEV             : Boolean;
    HOMOLOGATION        : Boolean;
    MCINSTANCE          : Boolean;
    EXPANDELOGONFE      : Boolean;
    EXPANDELOGONFCE     : Boolean;
    COMPUTERNAME        : string;
    INSTANCE_CACHE_NAME : string;
    ROOT_DIRECTORY      : string;
    UUID_EXECUTE_REMOTE : string;
    public
    function  ParamStrArray: TArray<string>;
    procedure ParseOptions(var Options: TParamsOptions; const Args: TArray<string>);
    procedure GetParamsOptions;
  end;

  {$ENDREGION}

 {$REGION ' TIdDescricao '}

  type
    TIdDescricao=class
      ID: Integer;
      Descricao: String;
    end;

  {$ENDREGION}

 {$REGION ' TWSClientInfo '}

  type
    TWSClientInfo = record
      IDCLIENTE: Integer;
      DATACAD: TDateTime;
      CNPJ: string;
      EMP_INSCESTRG: string;
      EMP_INSCMUNICIPAL: string;
      EMP_NOMEFANTASIA: string;
      RAZAOSOCIAL: string;
      EMP_ENDERECO: string;
      EMP_NUMERO: string;
      EMP_BAIRRO: string;
      EMP_CIDADE: string;
      EMP_UF: string;
      EMP_CEP: string;
      EMP_COMPLEMENTO: string;
      TELEFONE1: string;
      EMP_EMAIL: string;
      EMP_WEBSITE: string;
      EMP_RESPONSAVEL: string;
      EMP_CNAE: Integer;
      EMP_SERIE: string;
      IDREPRESENTANTE: string;
      BLOQUEIO_ADMIN: string;
      BLOQUEADO: string;
      ATIVO: string;
      dia_venc_mensalidade: Integer;
      forma_pagamento: string;
      emp_obs: string;
      n_maquinas: Integer;
    end;

  {$ENDREGION}

 {$REGION ' TWSDeviceInfo '}

  type
    TWSDeviceInfo = record
      IDMAQUINA: Integer;
      CNPJ: string;
      CHAVE: string;
      NOME: string;
      BLOQUEADO: string;
      modulos: string;
      nome_compu: string;
      Prog_acesso: string;
      Cod_ace_Remoto: string;
      versao_bd: string;
      versaoexe: string;
      sistema_operacional: string;
      memoria_ram: string;
      tipo: string;
      observacao: string;
      tecnico_instalacao: string;
    end;

  {$ENDREGION}

 {$REGION ' TWSDeviceInfo '}

   type
    TGetSerialDetail = record
      CNPJ:       String;
      IE:         String;
      Razao:      String;
      QTerminais: Integer;
    end;
 {$ENDREGION}

 {$REGION ' TLogToHTMLConverter '}

 type
  TLogToHTMLConverter = class
  public
    class function ConvertToHTML(title, subTitle, company, cnpj, dateTime, logText: string): string;
  end;

 {$ENDREGION}

 {$REGION ' Manipulator Types '}

  type
    TSearchLocation = (slStart, slEnd, slAnywhere);
    TInsertLocation = (ilStart, ilEnd, ilIgnore);
    TDuplicationCheckLocation = (dclSearchLocation, dclAnywhere);

  type
    TDayType = (dtNow, dtStart, dtEnd);

  type
    TIdDescricaoList=class(TObjectList<TIdDescricao>);

  type
    TWSTypeInclude = (WSClient, WSDevice);

  type
    TTypeAction = (TGeneration, TValidation);

  type
    TiCaptcha = (iCapImage, iCapText);

  type
    TActionCrypto = (crEncriptar, crDecriptar);

  type
    TQueryType  = (TTIB, TTFD, TTUni);

 {$ENDREGION}

 {$REGION ' TTelegramBot '}

 type
  TTelegramBot = class
  private
    const
      TELEGRAM_API_BASE_URL = 'https://api.telegram.org';
      TELEGRAM_API_METHOD = '/bot%s/%s'; // Usar o método como parâmetro
    var
      FToken: string;
      FHttpClient: THTTPClient;
      FChatId: string;
      FUserAgent: string;
    function SendRequest(const method: string; formData: TMultipartFormData): TJSONObject;
  public
    constructor Create(const token: string; const chatId: string);
    function SendMessage(const text: string): Boolean;
    function SendDocument(const documentPath, caption: string): Boolean;
    function SendCustomMethod(const methodName: string; formData: TMultipartFormData): TJSONObject;
  end;

 {$ENDREGION}

 {$REGION ' TWKConnDataAccess '}

type
  TWKConnDataAccess = class
  private

  public
    FConnection     : TUniConnection;
    FTransaction    : TUniTransaction;
    FProvider       : TInterBaseUniProvider;
    FSpecificOptions: TSpecificOptionsList;
    FQuery:       iSimpleQuery;
    FDAO:         iSimpleDAO<TObject>;

    constructor Create;
    destructor Destroy; override;

    function ConnectToDatabase(
      //aTransaction: TUniTransaction;
      aServer      : string = '';
      aDatabase    : string = '';
      aUsername    : string = '';
      aPassword    : string = '';
      aPort        : string = '';
      aLibraryName : string = '';
      aProtocol    : string = '';
      aProviderName: string = ''
    ): Boolean;

    function DisconnectFromDatabase: Boolean;
    function ExecuteQuery(const SQL: string): Boolean;
    function GetDataSet: TDataSet;

    function InsertEntity(Entity: TObject): Boolean;
    function DeleteEntity(Entity: TObject): Boolean;
    function UpdateEntity(Entity: TObject): Boolean;

  end;

 {$ENDREGION}

 {$REGION ' TWKConnectionClass '}

 type
  TWKConnectionClass = class

const

  {$REGION ' CONSTANTES DEFAULT '}

  {$IFDEF WWSOFTWARES}

  {$REGION ' Constantes Globais do Sistema '}

  NOMEDOSISTEMA                          =   'ARGWS'  ;
  SUBTITULO                              =   'ERP' ;
  SUBTITULO2                             =   'Sistemas';
  SOFTHOUSE                              =   'WWSoftware''s'  ;
  SLOGAN                                 =   'Sistemas e Tecnologias' ;
  CNPJ                                   =   '36518327000105' ;
  EMAIL                                  =   'suporte@wwsoftwares.com.br' ;
  TELEFONE1                              =   '(75)98333-4153'  ;
  CELULAR2                               =   '(75)98333-4153'  ;
  MASTER_SENHA                           =   'Wk180184#';
  SYS_PASSWD_KEY                         =   '@7E%#@!DF34#4SKL';

  CONTATO                                =   SOFTHOUSE ;
  CHAVEREG                               =   'ARGWS'; //'WWSoftware''s';
  CHAVEBANCO                             =   'Configuracao';
  CHAVECRYPT                             =   18018;
  LEVELCRYPT                             =   cMD5;

  OTP_SECRET       		                   =   '{4154AFCB-F6E3-4639-90BC-1BB0EA32119F}';

  UUID_EXECUTE                           = '2CB32387-8221-4344-893A-BB59ABF5A78E';

  SITE                     			      	 =   'https://wwsoftwares.com.br/' ;
  DOWNLOAD_URL_GERASYS_TI_DRH 			     =   'servidor.wwsoftwares.com.br/';
  DOWNLOAD_URL_GERASYS_TI_DRH_UPGRADE    =   DOWNLOAD_URL_GERASYS_TI_DRH + 'update/';
  LINK_TREINAMENTO         				       =   SITE + 'treinamento' ;
  LINK_IBPT                				       =   'https://ibpt.wwsoftwares.com.br/tabela/ibpt/' ;


  FslStart                               = TSearchLocation.slStart;
  FslEnd                                 = TSearchLocation.slEnd;
  FslAnywhere                            = TSearchLocation.slAnywhere;
  FilStart                               = TInsertLocation.ilStart;
  FilEnd                                 = TInsertLocation.ilEnd;
  FdclSearchLocation                     = TDuplicationCheckLocation.dclSearchLocation;
  FdclAnywhere                           = TDuplicationCheckLocation.dclAnywhere;

  EMPRESA_SISTEMA                        =   SOFTHOUSE + sLineBreak + sLineBreak + NOMEDOSISTEMA + ' | ' + SUBTITULO ;
  CONTATO_SUPORTE_TI                     =   'Contato: ' + CONTATO + sLineBreak + 'Email: ' + EMAIL + sLineBreak + 'Celular: ' + TELEFONE1 + ' | WhatsApp' + CELULAR2;
  URL_WS_LICENSA                         =  SITE + '/gestor20/wsclientes/api/return/';
  URL_ENDPOINT                           = '/wsclientes/api/return/';

  Codes64 = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz+/';
  PreTextSeguranca = 'ARGWS-ERP-';

  {$REGION ' API TELEGRAM '}

   {$IFDEF DEBUG}

      {$REGION ' API TELEGRAM DEV Wallace Kleiton [OBS: apenas ativado em modo DEBUG para Testes com a API] em Homologação do Sistema '}

        API_TELEGRAM       =  'https://api.telegram.org/bot';
        API_TEKEGRAM_FAQ   =  'https://core.telegram.org/bots/api';
        TOKEN_TELEGRAM     =  '6860203942:AAHxBNlBVWkybArwUrxi0OHau6IubjExgFg';
        IDCHANNEL_TELEGRAM =  '-1002024035757';
        API_AGENT_TELEGRAM =  NOMEDOSISTEMA + ' - ' + SUBTITULO + ' | ' + SOFTHOUSE + ' | wwsoftwares_bot_for_automation';

      {$ENDREGION}

   {$ENDIF}

   {$IFDEF RELEASE}

      {$REGION ' API TELEGRAM DEV Wallace Kleiton [OBS: apenas ativado em modo RELEASE] em modo PRODUÇÃO '}

        API_TELEGRAM       =  'https://api.telegram.org/bot';
        API_TEKEGRAM_FAQ   =  'https://core.telegram.org/bots/api';
        TOKEN_TELEGRAM     =  '6860203942:AAHxBNlBVWkybArwUrxi0OHau6IubjExgFg';
        IDCHANNEL_TELEGRAM =  '-1002024035757';
        API_AGENT_TELEGRAM =  NOMEDOSISTEMA + ' - ' + SUBTITULO + ' | ' + SOFTHOUSE + ' | wwsoftwares_bot_for_automation';

      {$ENDREGION}

   {$ENDIF}

  {$ENDREGION}

  {$REGION ' API WHATSAPP ARGWS '}

    API_WHATSAPP_WWSOFTWARES       =  'https://api.wwsoftwares.com.br/api/messages/send';
    TOKEN_WHATSAPP_WWSOFTWARES     =  'fBL8SYDx7bLjOybRxc2OzQ4mQQLcHQMZwd80tlEEXTSrjQ9iytgwRMoA2WUvYrHf';

  {$ENDREGION}

  {$ENDREGION}

  {$ENDIF}

   {$IFDEF WWSOFTWARES_OLD}

   {$REGION ' Dados da Software House '}

    NOMEDOSISTEMA                          =   'ARGWS'  ;
    SUBTITULO                              =   'ERP' ;
    SUBTITULO2                             =   'Sistemas';
    SOFTHOUSE                              =   'WWSoftware''s'  ;
    SLOGAN                                 =   'Sistemas e Tecnologias' ;
    CNPJ                                   =   '000000000000' ;
    EMAIL                                  =   'contato@wwsoftwares.com.br' ;
    TELEFONE1                              =   '(75)98844-9231'  ;
    CELULAR2                               =   '(75)98844-9231'  ;
    MASTER_SENHA                           =   'Wk180184#';
    SYS_PASSWD_KEY                         =   '@7E%#@!DF34#4SKL';

    CONTATO                                =   'Wallace Kleiton' ;
    CHAVEREG                               =   NOMEDOSISTEMA;
    CHAVEBANCO                             =   'Configuracao';
    UUID_EXECUTE                           = '2CB32387-8221-4344-893A-BB59ABF5A78E';
    OTP_SECRET       		                   =   '{4154AFCB-F6E3-4639-90BC-1BB0EA32119F}';

    SITE                     			      	 =   'https://wwsoftwares.com.br/' ;
    DOWNLOAD_URL_GERASYS_TI_DRH 			     =   'servidor.wwsoftwares.com.br/';
    DOWNLOAD_URL_GERASYS_TI_DRH_UPGRADE    =   DOWNLOAD_URL_GERASYS_TI_DRH + 'update/';

   {$ENDREGION}

   {$REGION ' API TELEGRAM '}

    API_TELEGRAM                           =  'https://api.telegram.org/bot';
    API_TEKEGRAM_FAQ                       =  'https://core.telegram.org/bots/api';
    TOKEN_TELEGRAM                         =  '';
    IDCHANNEL_TELEGRAM                     =  '';
    NAME_BOT_TELEGRAM                      =  'wwsoftwares_bot_for_automation';
    API_AGENT_TELEGRAM                     =  NOMEDOSISTEMA + ' - ' + SUBTITULO + ' | ' + SOFTHOUSE + ' | ' + NAME_BOT_TELEGRAM;

    URL_WS_LICENSA                         =  SITE + 'wslic/wsclientes/api/return/';
    URL_ENDPOINT                           = '/wsclientes/api/return/';

    Codes64 = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz+/';
    PreTextSeguranca = 'ARGWS-ERP-';

   {$ENDREGION}

   {$ENDIF}

   {$REGION ' Criptografia '}

    kCh = 'jçljaçsfiajrlkwqeru43980487-12jk2j8789uçkfj987a9fu1k41';
    CHAVE: String = '2@/-1RTMP20F1II';

   {$ENDREGION}

  {$ENDREGION}

  protected

  private

  public

  constructor Create;
  destructor  Destroy; override;

  function Crypt(aAcao: TActionCrypto; aFonte, aKey: string): string;
  function Connect(Conn, Transact, Driver: TObject) : Boolean;
  function WRInRegedit(ValueName, Information, AccessType, SubKey: Variant; ValueType: Integer):Variant;
  function GetBuildInfo(Prog: string): string;
  function ShellExecuteAndWait(Operation, FileName, Parameter, Directory: String; Show: Word; bWait: Boolean): Longint;
  function GetComputer:string;
  function FormatarDocumento(const Documento: string): string;
  function GenerateUUID: string;
  function MD5String(const Value: string): string;
  function MD5Arquivo(const Value: string): string;
  function GetBiosCheckSum: string;
  function GetMotherBoardCheckSum: string;
  function SerialValidacaoSistema: String;
  function CheckUUIDParam: Boolean;
  function AlertMsgDlg(Msg: string; AType: TMsgDlgType; AButtons: TMsgDlgButtons; IndiceHelp: Longint; DefButton: TModalResult = mrNone; Portugues: Boolean = True; IconIndex: Integer = -1; ImageList: TImageList = nil; Title: string = ''; GravarLog: Boolean = False): Word;
  function AlertMsgDlgCheck(Msg: string; AType: TMsgDlgType; AButtons: TMsgDlgButtons; IndiceHelp: Longint; DefButton: TModalResult; Portugues: Boolean; Checar: Boolean; MsgCheck: string; Funcao: TProcedure; IconIndex: Integer = -1; ImageList: TImageList = nil; Title: string = ''; GravarLog: Boolean = False): Word;
  function WriteClientDevice(const ClientInfo: TWSClientInfo; const DeviceInfo: TWSDeviceInfo; const UrlWs: string; const TypeInclude: TWSTypeInclude): Boolean;
  function SerializeClientInfo(const ClientInfo: TWSClientInfo): ISuperObject;
  function SerializeDeviceInfo(const DeviceInfo: TWSDeviceInfo): ISuperObject;
  function CheckLic: Boolean;
  function ButtonsContainAll(const Buttons: TMsgDlgButtons; const CheckButtons: TMsgDlgButtons): Boolean;
  function VerificaTableMSG(var MSG, AUTOR: String): Boolean;
  function getContadorOffline: Integer;
  function getSignContador: String;
  function getEncriptContador(Contador: string): String;
  function getKeyValid: String;
  function getDataKeyValid(Key: String): TDate;
  function GerarChaveDesbloqueio(Validade: TDate): String;
  function LerRegistroMaquina: Boolean;
  function IncContOff(Arquivo: String): String;
  function ValidarDataCodDesbloqueio(Key: String): Boolean;
  function DesbloquearMaquina(Key: String): Boolean;
  function LerRegistro(xArquivo, xSection, xIdent: String): String;
  function Modulo11(Valor: string; Base: Integer = 9; Resto: Boolean = False): string;
  function ChaveLiberacaoValidade(data: TDate): string;
  function Encode64(S: string): string;
  function Decode64(S: string): string;


  procedure ForceEndApplication(SourceApplication: String);overload;
  procedure ForceEndApplication;overload;
  procedure AutoConnectClass;
  Procedure RunConfiguraDB;
  procedure RunDBConfig;
  procedure GetEmployerDevice(IDEMPRESA: Integer);
  procedure SenderTelegramMOD(const TOKEN, CHATID, MSG, DOCUMENT, DOCUMENT_TITLE: string);
  procedure SaveToLog(ExInfo: TExceptionInfo);
  procedure TrataException(Sender: TObject; E: Exception);
  procedure StartProgressWithParameters(Min, Max, Interval, Width, Height: Integer; const Message: string; Position: Integer);
  procedure setKeyValid(Key: String; Vazio: Boolean = False);
  procedure setSignContador(Contador: string);
  procedure RegistrarMaquina;
  procedure IncrementaContadorOffline;
  procedure ZeraContadorOffline;
  procedure GravarChaveSeguranca(Key: String);
  procedure GravarRegistro(xArquivo, xSection, xIdent, xValue: String);
  procedure ValidaManipulacaoContador;
  procedure QueryBuilder(var Query: TObject; var Conn: TObject; const QueryType: TQueryType);

 end;

  {$ENDREGION}

 {$REGION ' TTokenGenerator '}

 type
  TTokenGenerator = class

  private
    FKey: string;
    class procedure LabelClick(Sender: TObject);
    class procedure OnKeyDownEvent(Sender: TObject; var Key: Word; Shift: TShiftState);
  public
    class function Base32Encode(const Data: TBytes): string;
    class function GenerateSecretKey: string;
    class function GenerateQRCodeURL(const Secret: string; AccountName: string; AppName: string = ''): string;
    class function GenerateQRCodeBitmap(const Key: string): TBitmap;
    class function GenerateRandomBytes(const ByteCount: Integer): TBytes;
    class procedure ImagesPreviewer(Imagem: TImage; const Key: string);
    class procedure ShowQRCode;
    class procedure ValidateTokenWithDialog(const Secret: string);
    class procedure GenerateTokenWithDialog(const Secret: string);
  end;

 {$ENDREGION}

 {$REGION ' TProgressBarUpdater '}

  type
    TProgressBarUpdater = class
    private
      FPreviewForm: TForm;
      FProgressBar: TProgressBar;
      FLabelMessage: TLabel;
      FAutoClose: Boolean;
      FProcessThread: TThread;
      FTerminateEvent: TEvent;

      procedure UpdateProgress(Position: Integer; const Message: string);
      procedure CloseForm(Sender: TObject);
      procedure FormCloseQuery(Sender: TObject; var CanClose: Boolean);
      procedure ProcessThreadExecute;

    public
      constructor Create;
      destructor Destroy; override;

      procedure StartProgressBar(Min, Max, Interval, Width, Height: Integer; AutoClose: Boolean = False);
      procedure UpdateProgressBar(Position: Integer; const Message: string);
      procedure CloseProgressBar;
    end;

 {$ENDREGION}

 {$REGION ' TWriteBaseAuth '}

  type
    TWriteBaseAuth = class
    private
      IdHTTP: TIdHTTP;
      FUrlWS: String;
      procedure SetUrlWS(const Value: String);
    public
      constructor Create(UrlWs: String); virtual;
      property UrlWs: String read FUrlWS write SetUrlWS;
    end;

 {$ENDREGION}

 {$REGION ' TWriteClientsAuth '}

    TWriteClientsAuth = class(TWriteBaseAuth)
    public
      function InsertClient(const ClientJson: string): Boolean;
    end;

  {$ENDREGION}

 {$REGION ' TWriteDevicesAuth '}

    TWriteDevicesAuth = class(TWriteBaseAuth)
    public
      function InsertDevice(const DeviceJson: string): Boolean;
    end;

 {$ENDREGION}

 {$REGION ' TReadClientesAutorizados '}

  type
    TReadClientesAutorizados = class
    private
      IdHTTP: TIdHTTP;
      FUrlWS: String;
      FWS_COMPUTADORES: string;
      FWS_CNPJ: string;
      FWS_RETORNO: Boolean;
      FWS_ATIVO: string;
      FWS_MESSAGE: string;
      FWS_BLOQUEADO: string;
      FWS_STATUS: Integer;
      FComputadores_arrayJson: TJSONArray;
      FComputerAutorizados: TDataSet;
      FWs_Maquina_Cadastrada: Boolean;
      FWs_Maquina_Bloqueada: Boolean;
      FWS_DIAVENC: Integer;
      procedure SetUrlWS(const Value: String);
      procedure SetWS_ATIVO(const Value: string);
      procedure SetWS_BLOQUEADO(const Value: string);
      procedure SetWS_CNPJ(const Value: string);
      procedure SetWS_COMPUTADORES(const Value: string);
      procedure SetWS_MESSAGE(const Value: string);
      procedure SetWS_RETORNO(const Value: Boolean);
      procedure SetWS_STATUS(const Value: Integer);
      procedure SetComputadores_arrayJson(const Value: TJSONArray);
      procedure SetComputerAutorizados(const Value: TDataSet);
      procedure SetWs_Maquina_Bloqueada(const Value: Boolean);
      procedure SetWs_Maquina_Cadastrada(const Value: Boolean);
      procedure SetWS_DIAVENC(const Value: Integer);
      { Private declarations }
      property Computadores_arrayJson: TJSONArray read FComputadores_arrayJson
        write SetComputadores_arrayJson;
      function getJSONLicensas(Const CNPJ: String): String;
      procedure SetRetornoWS(JSON_Retorno: String);
      procedure JsonToDataset(aDataset: TDataSet; aJSON: TJSONArray);
      procedure verificarURLWs;
    public
      { Public declarations }
      constructor Create(UrlWs: String); overload;
      property UrlWs: String read FUrlWS write SetUrlWS;
      property WS_RETORNO: Boolean read FWS_RETORNO write SetWS_RETORNO;
      property WS_STATUS: Integer read FWS_STATUS write SetWS_STATUS;
      property WS_MESSAGE: string read FWS_MESSAGE write SetWS_MESSAGE;
      property WS_BLOQUEADO: string read FWS_BLOQUEADO write SetWS_BLOQUEADO;
      property WS_CNPJ: string read FWS_CNPJ write SetWS_CNPJ;
      property WS_ATIVO: string read FWS_ATIVO write SetWS_ATIVO;
      property WS_DIAVENC: Integer read FWS_DIAVENC write SetWS_DIAVENC;
      property ComputerAutorizados: TDataSet read FComputerAutorizados
        write SetComputerAutorizados;
      property Ws_Maquina_Bloqueada: Boolean read FWs_Maquina_Bloqueada
        write SetWs_Maquina_Bloqueada;
      property Ws_Maquina_Cadastrada: Boolean read FWs_Maquina_Cadastrada
        write SetWs_Maquina_Cadastrada;
      procedure ConsultaWS(const CNPJ: String; aDataset: TDataSet);
      // Data set para retorno das maquinas para verificar se a mesma está liberada.
      function ConsultaMaquinaAutorizada(const Chave: string): Boolean;
    end;

 {$ENDREGION}

var
  FWKConnectionClass  : TWKConnectionClass;
  FWKConnDataAccess   : TWKConnDataAccess;
  FExceptionInfo      : TExceptionInfo;
  FParamsOptions      : TParamsOptions;
  FWSClientInfo       : TWSClientInfo;
  FWSDeviceInfo       : TWSDeviceInfo;
  FGetSerialDetail    : TGetSerialDetail;
  FTokenGenerator     : TTokenGenerator;
  FProgressBarUpdater : TProgressBarUpdater;
  FMemComputer        : TFDMemTable;
  FAlert              : TdxAlertWindowManager;
  FFConn              : TObject;

  {$REGION ' Variáveis DB Connection '}

    M_SERVIDOR          : string;
    M_NCOMPANY          : string;
    M_USUARIO_DB        : string;
    M_SENHA_DB          : string;
    M_LIBCON            : string;
    M_PROTOCOL          : string;
    M_DATABASE          : string;
    M_DATABASEREP       : string;
    M_PORTA             : string;
    M_CHARSET           : string;
    M_RAZAO             : string;
    INSTANCE_CACHE_NAME : string;

  {$ENDREGION}

implementation

    {$REGION ' Instruções de Uso ' }


    {$ENDREGION}

    { TWKConnectionClass }

    {$REGION ' TWKConnectionClass '}

      constructor TWKConnectionClass.Create;
      begin

        inherited Create;

        Application.onException := TrataException;

        AutoConnectClass;

        if not(FParamsOptions.COMPANYID.IsEmpty) then
          GetEmployerDevice(FParamsOptions.COMPANYID.ToInteger);

        FTokenGenerator := TTokenGenerator.Create;
        FMemComputer    := TFDMemTable.Create(nil);
        FAlert          := TdxAlertWindowManager.Create(nil);
        //FProgressBarUpdater := TProgressBarUpdater.Create;

        {$REGION ' Diretiva "EXECUTE_WITH_ID" | Utilizado Quando o Executável de Ser Chamado Através do Binário Principal '}

          {$IFDEF EXECUTE_WITH_ID}

            CheckUUIDParam;

          {$ENDIF}

        {$ENDREGION}

      end;

      destructor TWKConnectionClass.Destroy;
      begin

        inherited Destroy;
        FMemComputer.Destroy;
        FAlert.Destroy;

      end;

      procedure TWKConnectionClass.AutoConnectClass;
      var
        Driver: TObject;
      begin

        {$REGION ' CHECAGEM DE PARAMETROS '}

          FParamsOptions.GetParamsOptions;

        {$ENDREGION}

        {$REGION ' CONECTA BANCO DE DADOS '}

          if not(Assigned(DMManifestador)) then
            Application.CreateForm(TDMManifestador, DMManifestador);

          if Connect(
                       DMManifestador.FDConnection1,
                       DMManifestador.Transaction,
                       DMManifestador.Firebird
                     )
          then
          begin

            try

              DMManifestador.FDConnection1.Connected := True;

              {
              if DMManifestador.FDConnection1.Connected then
                DMManifestador.MainLoaderSystem;
              }

            except

              RunDBConfig;

            end;

          end
          else
          begin

            RunDBConfig;

          end;

        {$ENDREGION}

      end;

      procedure TWKConnectionClass.GetEmployerDevice(IDEMPRESA: Integer );
      var
        ConnDataAccess: TWKConnDataAccess;
        SQL: string;
      begin

        ConnDataAccess := TWKConnDataAccess.Create;

        SQL := Format('select * from tbempresa WHERE EMP_IDEMPRESA=%d', [IDEMPRESA]);

        if ConnDataAccess.ConnectToDatabase then
        begin

          if ConnDataAccess.ExecuteQuery(SQL) then
          begin

            with ConnDataAccess.GetDataSet do
            begin

              FWSClientInfo.DATACAD               := Now;
              FWSClientInfo.CNPJ                  := FieldBYName('EMP_CNPJCPF').AsString;
              FWSClientInfo.EMP_INSCESTRG         := FieldBYName('EMP_INSCESTRG').AsString;
              FWSClientInfo.EMP_INSCMUNICIPAL     := FieldBYName('EMP_INSCMUNICIPAL').AsString;
              FWSClientInfo.RAZAOSOCIAL           := FieldBYName('EMP_RAZAOSOCIAL').AsString;
              FWSClientInfo.EMP_NOMEFANTASIA      := FieldBYName('EMP_NOMEFANTASIA').AsString;
              FWSClientInfo.EMP_ENDERECO          := FieldBYName('EMP_ENDERECO').AsString;
              FWSClientInfo.EMP_NUMERO            := FieldBYName('EMP_NUMERO').AsString;
              FWSClientInfo.EMP_BAIRRO            := FieldBYName('EMP_BAIRRO').AsString;
              FWSClientInfo.EMP_CIDADE            := FieldBYName('EMP_CIDADE').AsString;
              FWSClientInfo.EMP_UF                := FieldBYName('EMP_UF').AsString;
              FWSClientInfo.EMP_CEP               := FieldBYName('EMP_CEP').AsString;
              FWSClientInfo.EMP_COMPLEMENTO       := FieldBYName('EMP_COMPLEMENTO').AsString;
              FWSClientInfo.TELEFONE1             := FieldBYName('EMP_FONE').AsString;
              FWSClientInfo.EMP_EMAIL             := FieldBYName('EMP_EMAIL').AsString;
              FWSClientInfo.EMP_WEBSITE           := FieldBYName('EMP_WEBSITE').AsString;
              FWSClientInfo.EMP_CNAE              := FieldBYName('EMP_CNAE').AsInteger;
              FWSClientInfo.EMP_SERIE             := FieldBYName('EMP_SERIE').AsString;
              FWSClientInfo.IDREPRESENTANTE       := '#1252019Soft';
              FWSClientInfo.BLOQUEIO_ADMIN        := 'S';
              FWSClientInfo.BLOQUEADO             := 'S';
              FWSClientInfo.ATIVO                 := 'S';
              FWSClientInfo.dia_venc_mensalidade  := 5;
              FWSClientInfo.forma_pagamento       := '';
              FWSClientInfo.n_maquinas            := 1;
              FWSClientInfo.emp_obs               := 'Cliente Cadastrado Automaticamente via ' + NOMEDOSISTEMA + SUBTITULO + sLineBreak +
                                                     ' ' + sLineBreak +
                                                     ' ' + sLineBreak +
                                                     'Informações da Licença: ' + sLineBreak +
                                                     ' ' + sLineBreak +
                                                     'Serial: '  + FWSClientInfo.EMP_SERIE   + sLineBreak +
                                                     'Empresa: ' + FWSClientInfo.RAZAOSOCIAL + sLineBreak +
                                                     'CNPJ: '    + FormatarDocumento(FWSClientInfo.CNPJ) + sLineBreak +
                                                     'UUID: '    + SerialValidacaoSistema;


              FWSDeviceInfo.CNPJ                  := FWSClientInfo.CNPJ;
              FWSDeviceInfo.CHAVE                 := SerialValidacaoSistema;
              FWSDeviceInfo.NOME                  := GetComputer;
              FWSDeviceInfo.BLOQUEADO             := 'N';
              FWSDeviceInfo.modulos               := '';
              FWSDeviceInfo.nome_compu            := GetComputer;
              FWSDeviceInfo.Prog_acesso           := 'Verificar ';
              FWSDeviceInfo.Cod_ace_Remoto        := 'Verificar ';
              FWSDeviceInfo.versao_bd             := '';
              FWSDeviceInfo.versaoexe             := GetBuildInfo(Application.ExeName);
              FWSDeviceInfo.sistema_operacional   := TOSVersion.Name;
              FWSDeviceInfo.memoria_ram           := '';
              FWSDeviceInfo.tecnico_instalacao    := 'Computador Cadastrado Automaticamente via ' + NOMEDOSISTEMA + SUBTITULO;
              FWSDeviceInfo.observacao            := 'Sistema Operacional: ' + TOSVersion.Name + ' | ' + 'Build: ' + TOSVersion.Build.ToString + sLineBreak +
                                                     'Computador Cadastrado Automaticamente via ' + NOMEDOSISTEMA + SUBTITULO + slinebreak +
                                                     ' ' + sLineBreak +
                                                     ' ' + sLineBreak +
                                                     'Informações da Licença: ' + sLineBreak +
                                                     ' ' + sLineBreak +
                                                     'Serial: '  + FWSClientInfo.EMP_SERIE   + sLineBreak +
                                                     'Empresa: ' + FWSClientInfo.RAZAOSOCIAL + sLineBreak +
                                                     'CNPJ: '    + FormatarDocumento(FWSClientInfo.CNPJ) + sLineBreak +
                                                     'UUID: '    + SerialValidacaoSistema;
            end;

          end;

        end;

      end;

      function TWKConnectionClass.CheckUUIDParam: Boolean;
        function StackInfoListToString(AList: TJclStackInfoList): string;
        var
          I: Integer;
          Strings: TStringList;
        begin
          Result := '';
          if Assigned(AList) then
          begin
            Strings := TStringList.Create;
            try
              for I := 0 to AList.Count - 1 do
              begin
                Strings.Add(AList[I].ToString);
              end;
              Result := Strings.Text;
            finally
              Strings.Free;
            end;
          end;
        end;
      var
        ExInfo: TExceptionInfo;
      begin
        //Parâmetro de inicialização: @T + UUID
        //@T2CB32387-8221-4344-893A-BB59ABF5A78E

        Result := (FParamsOptions.UUID_EXECUTE_REMOTE = UUID_EXECUTE);

        if not( Result ) then
        begin

          if not(FParamsOptions.MODEDEV) then
          begin

            ExInfo.USE_DYNAMIC_LOG_NAME := True;
            ExInfo.USU_DYNAMIC_TILE     := True;

            ExInfo.NomeForm := '  ' + SOFTHOUSE + ' ' + sLineBreak + sLineBreak +
                               '   Cel: '   + TELEFONE1 + sLineBreak +
                               '   Email: ' + EMAIL + sLineBreak + sLineBreak +
                               '   Nome do Sistema: ' + sLineBreak + '    ' + Application.Title + sLineBreak ;

            ExInfo.NomeComponente := ' ' + sLineBreak + '   UUID Detected: ' + slineBreak + '    ' + FParamsOptions.UUID_EXECUTE_REMOTE + slineBreak + slineBreak;

            ExInfo.ClasseErro   := ' ' + sLineBreak + '   UUID Incorrect Open Application' + slineBreak + slineBreak;

            ExInfo.MensagemErro := ' ' + slineBreak +
                                   '   Este aplicativo só pode ser inicializado através do módulo retaguarda.'  + slineBreak +
                                   '   Entre em contato com o suporte para obter mais informações.' + slineBreak + slineBreak ;

            ExInfo.StackTrace := ' ' + slineBreak + '   Tentativa de Incialização Inadequada da Aplicação:' + sLineBreak + '   ' + Application.ExeName;

            SaveToLog(ExInfo);

            //MessageDlg(StringReplace(ExInfo.FormatInfo(ACViolation), '|', '', [rfReplaceAll]),mtError,[mbOK],0);
            //MessageDlg( ExInfo.MensagemErro, mtError, [mbOK], 0);

            AlertMsgDlg(
                        StringReplace(ExInfo.FormatInfo(ACViolation), '|', '', [rfReplaceAll]),
                        mtWarning,//mtCustom,
                        [mbOK],
                        0,
                        mrOk,
                        True,
                        0,
                        nil,
                        ' Atenção '
                       );


            FWKConnectionClass.ForceEndApplication;

          end;

        end;

      end;

      function TWKConnectionClass.AlertMsgDlg(Msg: string; AType: TMsgDlgType; AButtons: TMsgDlgButtons;
        IndiceHelp: Longint; DefButton: TModalResult = mrNone;
        Portugues: Boolean = True; IconIndex: Integer = -1;
        ImageList: TImageList = nil; Title: string = '';
        GravarLog: Boolean = False): Word;
      var
        i: Integer;
        Mensagem: TForm;
        Icon: TImage;
        LogFileName: string;
        Button: TButton;
        ButtonWidth: Integer;
        ButtonLeft: Integer;
        RightAlignedButtons: set of TMsgDlgBtn;
        ModalResult: Integer;
      begin

      {$REGION ' Instruções de Uso '}
        {
          Utilização do método AlertMsgDlg:

          Msg: string - A mensagem a ser exibida na caixa de diálogo.

          AType: TMsgDlgType - O tipo de mensagem (mtConfirmation, mtWarning, mtError, mtInformation, mtCustom).

          AButtons: TMsgDlgButtons - Os botões que serão exibidos na caixa de diálogo (por exemplo, mbYesNo, mbOKCancel).

          A enumeração TMsgDlgButtons fornece diferentes conjuntos pré-definidos de
          botões que podem ser usados na exibição de caixas de diálogo.

          Aqui estão os tipos disponíveis:
          mbYes: Botão "Sim"
          mbNo: Botão "Não"
          mbOK: Botão "OK"
          mbCancel: Botão "Cancelar"
          mbAbort: Botão "Abortar"
          mbRetry: Botão "Repetir"
          mbIgnore: Botão "Ignorar"
          mbAll: Botão "Todos"
          mbNoToAll: Botão "Não para Todos"
          mbYesToAll: Botão "Sim para Todos"
          mbHelp: Botão "Ajuda"
          mbClose: Botão "Fechar"

          Esses são os tipos disponíveis na enumeração TMsgDlgButtons.
          Você pode combinar esses valores para definir quais botões
          serão exibidos na caixa de diálogo.
          Por exemplo, [mbYes, mbNo] exibirá os botões "Sim" e "Não",
          enquanto [mbOK, mbCancel] exibirá os botões "OK" e "Cancelar".

          IndiceHelp: LongInt - O contexto de ajuda associado à caixa de diálogo.

          1:
          O parâmetro IndiceHelp do tipo LongInt é usado para especificar
          o contexto de ajuda associado à caixa de diálogo.
          O valor específico a ser atribuído a esse parâmetro depende do
          sistema de ajuda utilizado em seu aplicativo. O IndiceHelp é
          usado para identificar a seção ou tópico relevante da documentação
          de ajuda relacionada à caixa de diálogo.

          2:
          Os valores específicos para IndiceHelp não são pré-definidos e
          variam dependendo da implementação do sistema de ajuda em seu
          aplicativo. Você deve consultar a documentação do sistema de
          ajuda que está usando para obter informações sobre os valores
          válidos a serem usados no IndiceHelp ou definir valores
          personalizados para corresponder à sua documentação de ajuda específica.


          DefButton: TModalResult - O botão padrão selecionado inicialmente.

          A enumeração TModalResult define os diferentes resultados possíveis
          de uma caixa de diálogo modal.
          Aqui estão os tipos disponíveis:
          mrNone: Nenhum resultado específico
          mrOk: Resultado "OK"
          mrCancel: Resultado "Cancelar"
          mrAbort: Resultado "Abortar"
          mrRetry: Resultado "Repetir"
          mrIgnore: Resultado "Ignorar"
          mrYes: Resultado "Sim"
          mrNo: Resultado "Não"
          mrClose: Resultado "Fechar"
          mrHelp: Resultado "Ajuda"
          mrTryAgain: Resultado "Tentar Novamente"
          mrContinue: Resultado "Continuar"
          mrYesToAll: Resultado "Sim para Todos"
          mrNoToAll: Resultado "Não para Todos"

          Esses são os tipos disponíveis na enumeração TModalResult.
          Você pode definir o resultado padrão desejado para a caixa de
          diálogo usando um dos valores acima.

          Portugues: Boolean - Indica se a caixa de diálogo deve ser exibida em português.

          IconIndex: Integer - O índice do ícone personalizado no TImageList.

          ImageList: TImageList - O TImageList que contém os ícones personalizados.

          Exemplo de uso:

          1 -  Exibição de mensagem de Confirmação com ícone de erro personalizado:
          AlertMsgDlg('Deseja continuar?', mtConfirmation, [mbYesNo], 0, mrYes, True, 0, MyImageList);

          2  - Exibição de mensagem de confirmação com botões "Sim" e "Não":
          AlertMsgDlg('Deseja continuar?', mtConfirmation, [mbYes, mbNo], 0, mrYes);

          3  - Exibição de mensagem de aviso com um único botão "OK":
          AlertMsgDlg('Aviso: Operação inválida!', mtWarning, [mbOK], 0, mrOK);

          4  - Exibição de mensagem de erro com botões "Abortar" e "Ignorar":
          AlertMsgDlg('Erro ao processar dados.', mtError, [mbAbort, mbIgnore], 0, mrAbort);

          5  - Exibição de mensagem informativa com botões "Sim", "Não" e "Cancelar":
          AlertMsgDlg('Deseja salvar as alterações?', mtInformation, [mbYes, mbNo, mbCancel], 0, mrYes);

          6  - Exibição de mensagem personalizada com um botão "Fechar":
          AlertMsgDlg('Bem-vindo!', mtCustom, [mbClose], 0, mrClose);

          7  - Exibição de mensagem de aviso com ícone de aviso personalizado:
          AlertMsgDlg('Aviso: Operação inválida!', mtWarning, [mbOK], 0, mrOK, True, 0, MyImageList);

          8  - Exibição de mensagem de erro com ícone de erro personalizado:
          AlertMsgDlg('Erro ao processar dados.', mtError, [mbAbort, mbIgnore], 0, mrAbort, True, 1, MyImageList);

          9  - Exibição de uma mensagem personalizada com ícone customizado e botão "OK":
          AlertMsgDlg('Esta é uma mensagem personalizada!', mtCustom, [mbOK], 0, mrOK, True, 0, MyImageList);

          10 - Exibição de uma mensagem personalizada com ícone customizado e botões "Sim" e "Não":
          AlertMsgDlg('Deseja continuar?', mtCustom, [mbYes, mbNo], 0, mrYes, True, 1, MyImageList);

          Neste exemplo, uma caixa de diálogo de confirmação será exibida em português, com os botões "Sim" e "Não".
          O botão padrão inicialmente selecionado será o "Sim". O ícone personalizado no índice 0 do MyImageList
          será exibido na caixa de diálogo.

          Lembre-se de ajustar os parâmetros conforme necessário, como o texto da mensagem, o tipo de mensagem (TMsgDlgType),
          os botões exibidos (TMsgDlgButtons), o botão padrão selecionado (DefButton) e o contexto de ajuda (IndiceHelp).

        }

      {$ENDREGION}

        Mensagem := CreateMessageDialog(Msg + sLineBreak, AType, AButtons);
        Mensagem.HelpContext := IndiceHelp;

        if (IconIndex <> -1) and (ImageList <> nil) then
        begin
          Icon := TImage.Create(nil);
          Icon.Parent := Mensagem;
          Icon.Left := 15;
          Icon.Top := 15;
          Icon.Width := ImageList.Width;
          Icon.Height := ImageList.Height;
          ImageList.GetBitmap(IconIndex, Icon.Picture.Bitmap);
          Icon.Visible := True;

          // Ajuste a posição da mensagem para evitar sobreposição com o ícone
          Mensagem.ClientWidth := Mensagem.ClientWidth + Icon.Width + 10;
          for i := 0 to Mensagem.ComponentCount - 1 do
          begin
            if Mensagem.Components[i] is TLabel then
              TLabel(Mensagem.Components[i]).Left := Icon.Width + 25;
          end;
        end;

        with Mensagem do
        begin
          for i := 0 to ComponentCount - 1 do
          begin
            if (Components[i] is TButton) then
            begin
              if (TButton(Components[i]).ModalResult = DefButton) then
              begin
                ActiveControl := TWincontrol(Components[i]);
              end;
            end;
          end;
          if Portugues then
          begin
            if AType = mtConfirmation then
              Caption := 'Confirmação'
            else if AType = mtWarning then
              Caption := 'Aviso'
            else if AType = mtError then
              Caption := 'Erro'
            else if AType = mtInformation then
              Caption := 'Informação';
          end;
        end;

        if Portugues then
        begin
          TButton(Mensagem.FindComponent('YES')).Caption := '&Sim';
          TButton(Mensagem.FindComponent('NO')).Caption := '&Não';
          TButton(Mensagem.FindComponent('CANCEL')).Caption := '&Cancelar';
          TButton(Mensagem.FindComponent('ABORT')).Caption := '&Abortar';
          TButton(Mensagem.FindComponent('RETRY')).Caption := '&Repetir';
          TButton(Mensagem.FindComponent('IGNORE')).Caption := '&Ignorar';
          TButton(Mensagem.FindComponent('ALL')).Caption := '&Todos';
          TButton(Mensagem.FindComponent('HELP')).Caption := 'A&juda';
        end;

        if not(Title.IsEmpty) then // if (AType = mtCustom) and (Title <> '') then
          Mensagem.Caption := Title;

        if GravarLog then
        begin
          if Title = '' then
            Title := 'Alert';

          // Compondo o nome do arquivo de log
          LogFileName := Format('%s_%s_%s.log',
            [Title, GetEnumName(TypeInfo(TMsgDlgType), Ord(AType)),
            FormatDateTime('YYYYMMDD_HHNNSS_Z', Now)]);

          // Verificando se o diretório de logs existe
          if not DirectoryExists(ExtractFilePath(Application.ExeName) + 'LOG\') then
            ForceDirectories(ExtractFilePath(Application.ExeName) + 'LOG\');

          // Gravando o log
          TFile.WriteAllText(ExtractFilePath(Application.ExeName) + 'LOG\' +
            LogFileName, Msg);
        end;

        // Alinhar os botões à direita
        RightAlignedButtons := [mbYes, mbYesToAll,  {mbOK,}  mbRetry, mbAll, mbHelp];
        // Definir os botões que serão alinhados à direita
        ButtonWidth := 75;
        ButtonLeft := Mensagem.ClientWidth - ButtonWidth - 10;
        for i := 0 to Mensagem.ComponentCount - 1 do
        begin
          if Mensagem.Components[i] is TButton then
          begin
            Button := TButton(Mensagem.Components[i]);
            ModalResult := Button.ModalResult;

            if ModalResult in [Integer(mbYes), Integer(mbYesToAll),  {Integer(mbOK),}
            Integer(mbRetry), Integer(mbAll), Integer(mbHelp)] then
            begin
              Button.Left := ButtonLeft;
              Button.Align := AlNone;
              Button.Anchors := [TAnchorKind.akTop, TAnchorKind.akRight];
              ButtonLeft := ButtonLeft - ButtonWidth - 10;
            end
            else
            begin
              // Alinhar os botões não especificados à esquerda
              Button.Left := 10;
              Button.Align := AlNone;
              Button.Anchors := [TAnchorKind.akTop, TAnchorKind.akLeft];
            end;
          end;
        end;

        // Definir cor de fundo
        // Mensagem.Color := $009A572B; // Substitua clYellow pela cor desejada
        Mensagem.Color := clWhite;

        // Definir cor da fonte
        for i := 0 to Mensagem.ComponentCount - 1 do
        begin

          if Mensagem.Components[i] is TLabel then
          begin
            // TLabel(Mensagem.Components[I]).Font.Color := clWhite; // Substitua clBlue pela cor desejada
            TLabel(Mensagem.Components[i]).Font.Color := $009A572B;
            // TLabel(Mensagem.Components[I]).Font.Style := [TFontStyle.fsBold];
          end;

        end;

        for i := 0 to Mensagem.ComponentCount - 1 do
        begin
          if Mensagem.Components[i] is TButton then
          begin
            if TButton(Mensagem.Components[i]).ModalResult = DefButton then
            begin
              Mensagem.ActiveControl := TWincontrol(Mensagem.Components[i]);
              Break;
            end;
          end;
        end;

        Result := Mensagem.ShowModal;
        Mensagem.Free;

      end;

      function TWKConnectionClass.AlertMsgDlgCheck(Msg: string; AType: TMsgDlgType;
        AButtons: TMsgDlgButtons; IndiceHelp: Longint; DefButton: TModalResult;
        Portugues: Boolean; Checar: Boolean; MsgCheck: string; Funcao: TProcedure;
        IconIndex: Integer = -1; ImageList: TImageList = nil; Title: string = '';
        GravarLog: Boolean = False): Word;
      var
        i: Integer;
        Mensagem: TForm;
        Check: TCheckBox;
        Icon: TImage;
        LogFileName: string;
        Button: TButton;
        ButtonWidth: Integer;
        ButtonLeft: Integer;
        RightAlignedButtons: set of TMsgDlgBtn;
        ModalResult: Integer;
      begin

      {$REGION ' Instruções de Uso '}
        {
          Utilização do método AlertMsgDlgCheck:

          Msg: string - A mensagem a ser exibida na caixa de diálogo.

          AType: TMsgDlgType - O tipo de mensagem (mtConfirmation, mtWarning, mtError, mtInformation, mtCustom).

          AButtons: TMsgDlgButtons - Os botões que serão exibidos na caixa de diálogo (por exemplo, mbYesNo, mbOKCancel).

          A enumeração TMsgDlgButtons fornece diferentes conjuntos pré-definidos de
          botões que podem ser usados na exibição de caixas de diálogo.

          Aqui estão os tipos disponíveis:
          mbYes: Botão "Sim"
          mbNo: Botão "Não"
          mbOK: Botão "OK"
          mbCancel: Botão "Cancelar"
          mbAbort: Botão "Abortar"
          mbRetry: Botão "Repetir"
          mbIgnore: Botão "Ignorar"
          mbAll: Botão "Todos"
          mbNoToAll: Botão "Não para Todos"
          mbYesToAll: Botão "Sim para Todos"
          mbHelp: Botão "Ajuda"
          mbClose: Botão "Fechar"

          Esses são os tipos disponíveis na enumeração TMsgDlgButtons.
          Você pode combinar esses valores para definir quais botões
          serão exibidos na caixa de diálogo.
          Por exemplo, [mbYes, mbNo] exibirá os botões "Sim" e "Não",
          enquanto [mbOK, mbCancel] exibirá os botões "OK" e "Cancelar".

          IndiceHelp: LongInt - O contexto de ajuda associado à caixa de diálogo.

          1:
          O parâmetro IndiceHelp do tipo LongInt é usado para especificar
          o contexto de ajuda associado à caixa de diálogo.
          O valor específico a ser atribuído a esse parâmetro depende do
          sistema de ajuda utilizado em seu aplicativo. O IndiceHelp é
          usado para identificar a seção ou tópico relevante da documentação
          de ajuda relacionada à caixa de diálogo.

          2:
          Os valores específicos para IndiceHelp não são pré-definidos e
          variam dependendo da implementação do sistema de ajuda em seu
          aplicativo. Você deve consultar a documentação do sistema de
          ajuda que está usando para obter informações sobre os valores
          válidos a serem usados no IndiceHelp ou definir valores
          personalizados para corresponder à sua documentação de ajuda específica.


          DefButton: TModalResult - O botão padrão selecionado inicialmente.

          A enumeração TModalResult define os diferentes resultados possíveis
          de uma caixa de diálogo modal.
          Aqui estão os tipos disponíveis:
          mrNone: Nenhum resultado específico
          mrOk: Resultado "OK"
          mrCancel: Resultado "Cancelar"
          mrAbort: Resultado "Abortar"
          mrRetry: Resultado "Repetir"
          mrIgnore: Resultado "Ignorar"
          mrYes: Resultado "Sim"
          mrNo: Resultado "Não"
          mrClose: Resultado "Fechar"
          mrHelp: Resultado "Ajuda"
          mrTryAgain: Resultado "Tentar Novamente"
          mrContinue: Resultado "Continuar"
          mrYesToAll: Resultado "Sim para Todos"
          mrNoToAll: Resultado "Não para Todos"

          Esses são os tipos disponíveis na enumeração TModalResult.
          Você pode definir o resultado padrão desejado para a caixa de
          diálogo usando um dos valores acima.

          Portugues: Boolean - Indica se a caixa de diálogo deve ser exibida em português.

          Checar: Boolean - Indica se um checkbox adicional deve ser exibido.

          MsgCheck: string - A mensagem a ser exibida ao lado do checkbox.

          Funcao: TProcedure - Uma função a ser executada se o checkbox estiver marcado.

          Funcao: TProcedure, Funcao é um parâmetro da função AlertMsgDlgCheck que
          espera receber uma função/procedimento para ser executada quando o checkbox
          estiver marcado na caixa de diálogo exibida.

          Em Delphi, TProcedure é um tipo de dado que representa um procedimento sem
          parâmetros e sem valor de retorno. É um tipo usado para declarar variáveis,
          parâmetros ou propriedades que referenciam procedimentos/funções que não
          recebem argumentos e não retornam nenhum valor.

          Ao passar uma função ou procedimento como argumento para o parâmetro Funcao,
          você pode definir uma ação personalizada a ser executada quando o usuário marca
          o checkbox na caixa de diálogo. Essa função ou procedimento será chamada dentro
          do método AlertMsgDlgCheck após a confirmação de que o checkbox está marcado.

          Por exemplo, suponha que você tenha a seguinte função chamada ExecutarAcao:

          procedure ExecutarAcao;
          begin
          // Código da ação a ser executada quando o checkbox estiver marcado
          // por exemplo: exibir uma mensagem ou realizar uma operação específica
          ShowMessage('Ação executada!');
          end;

          Você pode passar essa função como argumento para o parâmetro
          Funcao da seguinte forma:

          1 - Exibição de uma mensagem informativa com checkbox e botão "OK", e Executando um Método:
          AlertMsgDlgCheck('Mensagem de exemplo', mtInformation, [mbOK], 0, mrOK, True, True, 'Não mostrar novamente', ExecutarAcao);

          2 -Exibição de uma mensagem de confirmação com checkbox e botões "Sim" e "Não", Executando um Método, e exibindo um ícone personalizado:
          AlertMsgDlgCheck('Deseja continuar?', mtConfirmation, [mbYes, mbNo], 0, mrYes, True, True, 'Não mostrar novamente', MinhaFuncao, 0, MyImageList);

          Dessa forma, quando o usuário marcar o checkbox na caixa de diálogo,
          a função ExecutarAcao será chamada e o código dentro dela será executado,
          realizando a ação desejada. No exemplo acima, a função exibirá uma
          mensagem "Ação executada!" quando o checkbox estiver marcado.

          IconIndex: Integer - O índice do ícone personalizado no TImageList.

          ImageList: TImageList - O TImageList que contém os ícones personalizados.

          Exemplo de uso:

          1  - Exibição de uma mensagem de confirmação com checkbox e botões "Sim" e "Não" com ícone customizado:
          AlertMsgDlgCheck('Deseja continuar?', mtConfirmation, [mbYesNo], 0, mrYes, True, True, 'Não mostrar novamente', MinhaFuncao, 0, MyImageList);

          2  - Exibição de uma mensagem de confirmação com checkbox e botões "Sim" e "Não":
          AlertMsgDlgCheck('Deseja continuar?', mtConfirmation, [mbYes, mbNo], 0, mrYes, True, True, 'Não mostrar novamente', MinhaFuncao);

          3  - Exibição de uma mensagem de aviso com checkbox e um único botão "OK":
          AlertMsgDlgCheck('Aviso: Operação inválida!', mtWarning, [mbOK], 0, mrOK, True, True, 'Não mostrar novamente', MinhaFuncao);

          4  - Exibição de uma mensagem de erro com checkbox e botões "Abortar" e "Ignorar":
          AlertMsgDlgCheck('Erro ao processar dados.', mtError, [mbAbort, mbIgnore], 0, mrAbort, True, True, 'Não mostrar novamente', MinhaFuncao);

          5  - Exibição de uma mensagem informativa com checkbox e botões "Sim", "Não" e "Cancelar":
          AlertMsgDlgCheck('Deseja salvar as alterações?', mtInformation, [mbYes, mbNo, mbCancel], 0, mrYes, True, True, 'Não perguntar novamente', MinhaFuncao);

          6  - Exibição de uma mensagem de confirmação com ícone personalizado, checkbox e botões "Sim" e "Não":
          AlertMsgDlgCheck('Deseja continuar?', mtConfirmation, [mbYes, mbNo], 0, mrYes, True, True, 'Não mostrar novamente', MinhaFuncao, 0, MyImageList);

          7  - Exibição de uma mensagem de aviso com ícone personalizado, checkbox e um único botão "OK":
          AlertMsgDlgCheck('Aviso: Operação inválida!', mtWarning, [mbOK], 0, mrOK, True, True, 'Não mostrar novamente', MinhaFuncao, 1, MyImageList);

          8  - Exibição de uma mensagem personalizada com ícone customizado, checkbox e botão "OK":
          AlertMsgDlgCheck('Esta é uma mensagem personalizada!', mtCustom, [mbOK], 0, mrOK, True, True, 'Não mostrar novamente', MinhaFuncao, 0, MyImageList);

          9  - Exibição de uma mensagem personalizada com ícone customizado, checkbox e botões "Sim" e "Não":
          AlertMsgDlgCheck('Deseja continuar?', mtCustom, [mbYes, mbNo], 0, mrYes, True, True, 'Não mostrar novamente', MinhaFuncao, 1, MyImageList);


          Neste exemplo, uma caixa de diálogo de confirmação será exibida em português, com os botões "Sim" e "Não".
          Um checkbox adicional será exibido com a mensagem "Não mostrar novamente". Se o checkbox estiver marcado,
          a função "MinhaFuncao" será executada. O ícone personalizado no índice 0 do MyImageList será exibido na caixa de diálogo.

          Lembre-se de ajustar os parâmetros conforme necessário, como o texto da mensagem, o tipo de mensagem (TMsgDlgType),
          os botões exibidos (TMsgDlgButtons), o botão padrão selecionado (DefButton), a mensagem do checkbox adicional e a
          função a ser executada se o checkbox estiver marcado.

        }

      {$ENDREGION}

        Check := nil;
        Mensagem := CreateMessageDialog(Msg + sLineBreak, AType, AButtons);
        Mensagem.HelpContext := IndiceHelp;

        if (IconIndex <> -1) and (ImageList <> nil) then
        begin

          Icon := TImage.Create(nil);
          Icon.Parent := Mensagem;
          Icon.Left := 15;
          Icon.Top := 15;
          Icon.Width := ImageList.Width;
          Icon.Height := ImageList.Height;
          ImageList.GetBitmap(IconIndex, Icon.Picture.Bitmap);
          Icon.Visible := True;

          // Ajuste a posição da mensagem para evitar sobreposição com o ícone
          Mensagem.ClientWidth := Mensagem.ClientWidth + Icon.Width + 10;
          for i := 0 to Mensagem.ComponentCount - 1 do
          begin

            if Mensagem.Components[i] is TLabel then
              TLabel(Mensagem.Components[i]).Left := Icon.Width + 25;

          end;

        end;

        with Mensagem do
        begin
          for i := 0 to ComponentCount - 1 do
          begin
            if (Components[i] is TButton) then
            begin
              if (TButton(Components[i]).ModalResult = DefButton) then
              begin
                ActiveControl := TWincontrol(Components[i]);
              end;
            end;
          end;
          if Portugues then
          begin
            if AType = mtConfirmation then
              Caption := 'Confirmação'
            else if AType = mtWarning then
              Caption := 'Aviso'
            else if AType = mtError then
              Caption := 'Erro'
            else if AType = mtInformation then
              Caption := 'Informação';
          end;
        end;

        if Portugues then
        begin
          TButton(Mensagem.FindComponent('YES')).Caption := '&Sim';
          TButton(Mensagem.FindComponent('NO')).Caption := '&Não';
          TButton(Mensagem.FindComponent('CANCEL')).Caption := '&Cancelar';
          TButton(Mensagem.FindComponent('ABORT')).Caption := '&Abortar';
          TButton(Mensagem.FindComponent('RETRY')).Caption := '&Repetir';
          TButton(Mensagem.FindComponent('IGNORE')).Caption := '&Ignorar';
          TButton(Mensagem.FindComponent('ALL')).Caption := '&Todos';
          TButton(Mensagem.FindComponent('HELP')).Caption := 'A&juda';
        end;

        if not(Title.IsEmpty) then // if (AType = mtCustom) and (Title <> '') then
          Mensagem.Caption := Title;

        if GravarLog then
        begin
          if Title = '' then
            Title := 'Alert';

          // Compondo o nome do arquivo de log
          LogFileName := Format('%s_%s_%s.log',
            [Title, GetEnumName(TypeInfo(TMsgDlgType), Ord(AType)),
            FormatDateTime('YYYYMMDD_HHNNSS_Z', Now)]);

          // Verificando se o diretório de logs existe
          if not DirectoryExists(ExtractFilePath(Application.ExeName) + 'LOG\') then
            ForceDirectories(ExtractFilePath(Application.ExeName) + 'LOG\');

          // Gravando o log
          TFile.WriteAllText(ExtractFilePath(Application.ExeName) + 'LOG\' +
            LogFileName, Msg);
        end;

        // Alinhar os botões à direita
        RightAlignedButtons := [mbYes, mbYesToAll, { mbOK, } mbRetry, mbAll, mbHelp];
        // Definir os botões que serão alinhados à direita
        ButtonWidth := 75;
        ButtonLeft := Mensagem.ClientWidth - ButtonWidth - 10;

        for i := 0 to Mensagem.ComponentCount - 1 do
        begin
          if Mensagem.Components[i] is TButton then
          begin
            Button := TButton(Mensagem.Components[i]);
            ModalResult := Button.ModalResult;

            if ModalResult in [Integer(mbYes), Integer(mbYesToAll), { Integer(mbOK), }
            Integer(mbRetry), Integer(mbAll), Integer(mbHelp)] then
            begin
              Button.Left := ButtonLeft;
              Button.Align := AlNone;
              Button.Anchors := [TAnchorKind.akTop, TAnchorKind.akRight];
              ButtonLeft := ButtonLeft - ButtonWidth - 10;
            end
            else
            begin
              // Alinhar os botões não especificados à esquerda
              Button.Left := 10;
              Button.Align := AlNone;
              Button.Anchors := [TAnchorKind.akTop, TAnchorKind.akLeft];
            end;
          end;

        end;

        // Definir cor de fundo
        // Mensagem.Color := $009A572B; // Substitua clYellow pela cor desejada
        Mensagem.Color := clWhite;

        // Definir cor da fonte
        for i := 0 to Mensagem.ComponentCount - 1 do
        begin

          if Mensagem.Components[i] is TLabel then
          begin
            // TLabel(Mensagem.Components[I]).Font.Color := clWhite; // Substitua clBlue pela cor desejada
            TLabel(Mensagem.Components[i]).Font.Color := $009A572B;
            // TLabel(Mensagem.Components[I]).Font.Style := [TFontStyle.fsBold]; // Substitua clBlue pela cor desejada
          end;

        end;

        for i := 0 to Mensagem.ComponentCount - 1 do
        begin
          if Mensagem.Components[i] is TButton then
          begin
            if TButton(Mensagem.Components[i]).ModalResult = DefButton then
            begin
              Mensagem.ActiveControl := TWincontrol(Mensagem.Components[i]);
              Break;
            end;
          end;
        end;

        if Checar then
        begin
          Mensagem.ClientHeight := Mensagem.ClientHeight + 20;
          Check := TCheckBox.Create(Mensagem);
          Check.Parent := Mensagem;
          Check.Left := 15;
          Check.Top := Mensagem.ClientHeight - 20;
          Check.Visible := True;
          Check.Caption := MsgCheck;
          Check.Width := Mensagem.ClientWidth - 10;
        end;

        Result := Mensagem.ShowModal;

        if Check.Checked then
          Funcao;

        Mensagem.Free;

      end;

      function TWKConnectionClass.WriteClientDevice(const ClientInfo: TWSClientInfo; const DeviceInfo: TWSDeviceInfo; const UrlWs: string; const TypeInclude: TWSTypeInclude): Boolean;
      var
        WriteClientsAuth: TWriteClientsAuth;
        WriteDevicesAuth: TWriteDevicesAuth;
        ClientJson, DeviceJson: ISuperObject;
      begin
        Result := False;

        try

          if (TypeInclude <> WSClient) and (TypeInclude <> WSDevice) then
            raise Exception.Create('TypeInclude inválido');

          if TypeInclude = WSClient then
          begin
            if ClientInfo.CNPJ = '' then
              raise Exception.Create('CNPJ não pode ser vazio');

            // Serializando os dados do cliente
            ClientJson := SerializeClientInfo(ClientInfo);

            WriteClientsAuth := TWriteClientsAuth.Create(UrlWs);
            try
              if not WriteClientsAuth.InsertClient(ClientJson.AsJSON) then
                Exit;
            finally
              WriteClientsAuth.Free;
            end;

            Result := True;
          end;

          if TypeInclude = WSDevice then
          begin
            if DeviceInfo.CNPJ = '' then
              raise Exception.Create('CNPJ não pode ser vazio');

            // Serializando os dados do dispositivo
            DeviceJson := SerializeDeviceInfo(DeviceInfo);

            WriteDevicesAuth := TWriteDevicesAuth.Create(UrlWs);
            try
              if not WriteDevicesAuth.InsertDevice(DeviceJson.AsJSON) then
                Exit;
            finally
              WriteDevicesAuth.Free;
            end;

            Result := True;
          end;

        except

          on E: Exception do
          begin
            // Log ou mostrar o erro
            ShowMessage(E.Message);
          end;

        end;

      end;

      function TWKConnectionClass.SerializeClientInfo(const ClientInfo: TWSClientInfo): ISuperObject;
      begin

          Result:= SO;
          Result.V['DATACAD']               := ClientInfo.DATACAD;
          Result.S['CNPJ']                  := ClientInfo.CNPJ;
          Result.S['EMP_INSCESTRG']         := ClientInfo.EMP_INSCESTRG;
          Result.S['EMP_INSCMUNICIPAL']     := ClientInfo.EMP_INSCMUNICIPAL;
          Result.S['EMP_NOMEFANTASIA']      := ClientInfo.EMP_NOMEFANTASIA;
          Result.S['RAZAOSOCIAL']           := ClientInfo.RAZAOSOCIAL;
          Result.S['EMP_ENDERECO']          := ClientInfo.EMP_ENDERECO;
          Result.S['EMP_NUMERO']            := ClientInfo.EMP_NUMERO;
          Result.S['EMP_BAIRRO']            := ClientInfo.EMP_BAIRRO;
          Result.S['EMP_CIDADE']            := ClientInfo.EMP_CIDADE;
          Result.S['EMP_UF']                := ClientInfo.EMP_UF;
          Result.S['EMP_CEP']               := ClientInfo.EMP_CEP;
          Result.S['EMP_COMPLEMENTO']       := ClientInfo.EMP_COMPLEMENTO;
          Result.S['TELEFONE1']             := ClientInfo.TELEFONE1;
          Result.S['EMP_EMAIL']             := ClientInfo.EMP_EMAIL;
          Result.S['EMP_WEBSITE']           := ClientInfo.EMP_WEBSITE;
          Result.S['EMP_RESPONSAVEL']       := ClientInfo.EMP_RESPONSAVEL;
          Result.I['EMP_CNAE']              := ClientInfo.EMP_CNAE;
          Result.S['EMP_SERIE']             := ClientInfo.EMP_SERIE;
          Result.S['IDREPRESENTANTE']       := ClientInfo.IDREPRESENTANTE;
          Result.S['BLOQUEIO_ADMIN']        := ClientInfo.BLOQUEIO_ADMIN;
          Result.S['BLOQUEADO']             := ClientInfo.BLOQUEADO;
          Result.S['ATIVO']                 := ClientInfo.ATIVO;
          Result.I['dia_venc_mensalidade']  := ClientInfo.dia_venc_mensalidade;
          Result.S['forma_pagamento']       := ClientInfo.forma_pagamento;
          Result.S['emp_obs']               := ClientInfo.emp_obs;
          Result.I['n_maquinas']            := ClientInfo.n_maquinas;

      end;

      function TWKConnectionClass.SerializeDeviceInfo(const DeviceInfo: TWSDeviceInfo): ISuperObject;
      begin

          Result := SO;

          Result.S['CNPJ']                  := DeviceInfo.CNPJ;
          Result.S['CHAVE']                 := DeviceInfo.CHAVE;
          Result.S['NOME']                  := DeviceInfo.NOME;
          Result.S['BLOQUEADO']             := DeviceInfo.BLOQUEADO;
          Result.S['modulos']               := DeviceInfo.modulos;
          Result.S['nome_compu']            := DeviceInfo.nome_compu;
          Result.S['Prog_acesso']           := DeviceInfo.Prog_acesso;
          Result.S['Cod_ace_Remoto']        := DeviceInfo.Cod_ace_Remoto;
          Result.S['versao_bd']             := DeviceInfo.versao_bd;
          Result.S['versaoexe']             := DeviceInfo.versaoexe;
          Result.S['sistema_operacional']   := DeviceInfo.sistema_operacional;
          Result.S['memoria_ram']           := DeviceInfo.memoria_ram;
          Result.S['tipo']                  := DeviceInfo.tipo;
          Result.S['observacao']            := DeviceInfo.observacao;
          Result.S['tecnico_instalacao']    := DeviceInfo.tecnico_instalacao;

      end;

      function TWKConnectionClass.CheckLic: Boolean;
      var
        ClientesLicensas: TReadClientesAutorizados;
        DiaVencimento, i: Integer;
        Botoes: TStringList;
        DataKeyValid: TDate;
        KeyValid, URLBase_Bin, LincenseInfo: string;
      begin

        {$REGION ' Tratamento da Licença '}

        Result := True;

        if not(FParamsOptions.NOCHECKLIC) then
        begin

          URLBase_Bin := URL_WS_LICENSA; //Crypt(crDecriptar, ConfigINI.URLBase, kCh);

          // ValidaURLBASE

          if URLBase_Bin.IsEmpty then
          begin

            AlertMsgDlg('A url base não foi informada, e deve ser corrigida', mtCustom, [mbOK], 0, mrOK, True, 3, nil, 'Erro - Contate o Suporte');
            Result := False;
            Exit;

          end
          else
          begin

            if not URLBase_Bin.EndsWith(URL_ENDPOINT) then
            begin

              AlertMsgDlg('A url base não é valida, e deve ser corrigida', mtCustom, [mbOK], 0, mrOK, True, 3, nil, 'Erro - Contate o Suporte');
              Result := False;
              Exit;

            end;

          end;

          ClientesLicensas := TReadClientesAutorizados.Create(URLBase_Bin);

          LincenseInfo :=' ' + sLineBreak +
                         ' ' + sLineBreak +
                         'Informações da Licença: ' + sLineBreak +
                         ' ' + sLineBreak +
                         'Serial: '  + FWSClientInfo.EMP_SERIE   + sLineBreak +
                         'Empresa: ' + FWSClientInfo.RAZAOSOCIAL + sLineBreak +
                         'CNPJ: '    + FormatarDocumento(FWSClientInfo.CNPJ) + sLineBreak +
                         'UUID: '    + SerialValidacaoSistema;

          try

            begin

              ClientesLicensas.ConsultaWS(FWSClientInfo.CNPJ, FMemComputer);

              if (not ClientesLicensas.WS_RETORNO) then
                IncrementaContadorOffline;

              // Se teve retorno e o cliente não está cadastrado.
              if (ClientesLicensas.WS_RETORNO) and (ClientesLicensas.WS_STATUS = 0)
              then
              begin

                AlertMsgDlg(
                              'Cliente não cadastrado no WS de Licenças. Entre em contato com suporte.' + LincenseInfo + sLineBreak + sLineBreak +
                              'Será realizada uma Tentativa de Inclusão do Cliente no WebService de Licenciamento.' + sLineBreak + sLineBreak +
                              'Obs: Será necessário entrar em contato com o suporte para Liberarção de uso do Sistema!',
                                mtCustom,
                                [mbOK],
                                0,
                                mrOK,
                                True,
                                0,
                                nil,
                                'Erro - Contate o Suporte'
                           );
                if not WriteClientDevice(FWSClientInfo, FWSDeviceInfo, Crypt(crDecriptar, URL_WS_LICENSA, kCh), WSClient) then
                begin
                  AlertMsgDlg(
                                'Erro ao gravar informações do cliente. Entre em contato com o suporte.' + sLineBreak + CONTATO_SUPORTE_TI,
                                mtCustom,
                                [mbOK],
                                0,
                                mrOK,
                                True,
                                0,
                                nil,
                                'Erro - Contate o Suporte'
                             );
                  exit(False);
                end else
                begin

                    AlertMsgDlg(
                                  'Cliente cadastrado com sucesso no WS de Licenças' + LincenseInfo + sLineBreak + SlineBreak +
                                  'Entre em contato com o suporte para Liberarção de uso do Sistema! ',
                                  mtCustom,
                                  [mbOK],
                                  0,
                                  mrOK,
                                  True,
                                  0,
                                  nil,
                                  'Aviso - Contate o Suporte'
                               );

                  exit(False);
                end;

              end;

              // Consulta se teve retorno e o cliente está cadastrado
              // WS_STATUS (1 - Autorizado, 2 - Não Autorizado)
              if (ClientesLicensas.WS_RETORNO) and (ClientesLicensas.WS_STATUS = 1)
              then
              begin

                ZeraContadorOffline;

                // seta uma chave vazia, pois o cliente não está bloquado e não há
                // necessidade de verificação por chave de desbloqueio, assim a verificação por chave
                // devolve uma data atual que necessitará de uma nova chave de desbloquio se houver necessidade.
                // Comentado - Estava zerando a chave do Registro e não gravava de volta.
                // setKeyValid('',True);
                // Retorna o dia de Vencimento para alerta o cliente do vencimento.

                DiaVencimento := ClientesLicensas.WS_DIAVENC;

                // VERIFICA SE A EMPRESA ESTA BLOQUEADA
                if (ClientesLicensas.WS_BLOQUEADO = 'S') then
                begin

                    AlertMsgDlg(
                                  'Este CNPJ encontra-se inativo no WebServices de Licenças, entre em contato com suporte.' + LincenseInfo + sLineBreak + sLineBreak +
                                  'Se por acaso se trata de uma implantação recente e o seu cadastro '+ slinebreak +
                                  'foi efetuado dinamicamente, entre em contato com o suporte para' + sLineBreak +
                                  'prosseguir com a ativação.' + sLineBreak + sLineBreak + CONTATO_SUPORTE_TI,
                                  mtCustom,
                                  [mbOK],
                                  0,
                                  mrOK,
                                  True,
                                  0,
                                  nil,
                                  'Erro - Contate o Suporte'
                               );
                  Result := False;
                  Exit;

                end;

                // VERIFICA SE A MAQUINA ESTA AUTORIZADA...
                IF not ClientesLicensas.ConsultaMaquinaAutorizada
                  (SerialValidacaoSistema) THEN
                begin

                  AlertMsgDlg(
                                 'Este computador não está cadastrado na WebServices de Licenças, entre em contato com suporte.' + LincenseInfo + sLineBreak + SlineBreak +
                                 'Será realizada uma Tentativa de Inclusão deste dispositivo no WebService de Licenciamento!',
                                 mtCustom,
                                 [mbOK],
                                 0,
                                 mrOK,
                                 True,
                                 0,
                                 nil,
                                 'Erro - Contate o Suporte'
                             );

                  if not WriteClientDevice(FWSClientInfo, FWSDeviceInfo, URLBase_Bin, WSDevice) then
                  begin

                    AlertMsgDlg(
                                  'Erro ao inserir informações desse dispositivo. Entre em contato com o suporte.' + LincenseInfo  + sLineBreak + CONTATO_SUPORTE_TI,
                                  mtCustom,
                                  [mbOK],
                                  0,
                                  mrOK,
                                  True,
                                  0,
                                  nil,
                                  'Erro - Contate o Suporte'
                               );
                    exit(False);

                  end else
                  begin

                    AlertMsgDlg(
                                  'Equipamento cadastrado com sucesso do WebService de Licenças' + LincenseInfo + sLineBreak + SlineBreak +
                                  'Entre em contato com o suporte para efetuar as parametrizações necessárias para o uso do sistema!       ' + sLineBreak + CONTATO_SUPORTE_TI,
                                  mtCustom,
                                  [mbOK],
                                  0,
                                  mrOK,
                                  True,
                                  0,
                                  nil,
                                  'Aviso - Contate o Suporte'
                               );
                    exit(False);
                  end;

                end;

                // VERIFICA SE A MAQUIA ESTA BLOQUEADA
                IF ClientesLicensas.Ws_Maquina_Bloqueada THEN
                begin

                  AlertMsgDlg(
                                'Este computador está bloqueado no WebServices de Licenças, entre em contato com suporte.' + LincenseInfo + sLineBreak + CONTATO_SUPORTE_TI,
                                mtCustom,
                                [mbOK],
                                0,
                                mrOK,
                                True,
                                0,
                                nil,
                                'Erro - Contate o Suporte'
                             );
                  Result := False;
                  Exit;

                end;

                // /######adicionar comentario
                // verifica se exite uma chave de desbloquio local setada, mesmo o cliente esta (bloqueado ou offline)
                // bloqueia caso a chave esta vencida menor que data atual
                // verifica se a data esta igual e bloquaia pois não tem data definida por uma chave
                // /######adicionar comentario

              end;


            end;

            {$REGION ' Desabilitado '}
                  {
                    KeyValid := getKeyValid;
                    DataKeyValid := getDataKeyValid(KeyValid);
                    if (DataKeyValid <= Date) then
                    begin
                    frmaviso_bloqueio := Tfrmaviso_bloqueio.Create(Self);
                    frmaviso_bloqueio.showmodal;
                    if not frmaviso_bloqueio.desbloqueio then
                    Application.Terminate;
                    end;
                  }
            {$ENDREGION}

          finally

            ClientesLicensas.Free;

          end;

          // Alerta o cliente sobre vencimento faltando 3,2,1 dia(s)
          if (DiaVencimento > 0) and ((DiaVencimento - DayOfTheMonth(Now))
            in [1, 2, 3]) then
            FAlert.Show('Alerta',
              'Atenção! Caro cliente sua mensalidade vence dia ' +
              DiaVencimento.ToString + '. Mantenha sua mensalidade em dias.', 0);

        end;

          {$ENDREGION}

      end;

      function TWKConnectionClass.ButtonsContainAll(const Buttons: TMsgDlgButtons; const CheckButtons: TMsgDlgButtons): Boolean;
      var
        Button: TMsgDlgBtn;
      begin
        for Button := Low(TMsgDlgBtn) to High(TMsgDlgBtn) do
        begin
          if (Button in Buttons) and not (Button in CheckButtons) then
          begin
            Result := False;
            Exit;
          end;
        end;
        Result := True;
      end;

      function TWKConnectionClass.VerificaTableMSG(var Msg, AUTOR: String): Boolean;
      var
        mQuery: TObject;
      begin

        Result := False;

        QueryBuilder(mQuery, FFConn, TTFD);

        With (mQuery as TFDQuery) do
        Begin

          Close;
          Sql.Clear;
          Sql.Add(' SELECT COUNT(*) QTDE ');
          Sql.Add(' FROM RDB$RELATIONS ');
          Sql.Add(' WHERE RDB$FLAGS=1 and RDB$RELATION_NAME=''MENSAGEM'' ');
          Open;

          if (FieldByName('QTDE').AsInteger = 0) then
          begin

            {$REGION ' CRIA A TABELA PADRÃO '}

                  Sql.Clear;
                  Sql.Add(' CREATE TABLE MENSAGEM ( ');
                  Sql.Add(' NMAUTOR    VARCHAR(50) NOT NULL, ');
                  Sql.Add(' CDDITADO   INTEGER DEFAULT 0 NOT NULL, ');
                  Sql.Add(' DCDITADO   BLOB SUB_TYPE 1 SEGMENT SIZE 80, ');
                  Sql.Add(' FLEXIBIDO  CHAR(1) NOT NULL ');
                  Sql.Add('  );');
                  ExecSQL;

                  // ****                           Primary Keys                            ****/
                  Sql.Clear;
                  Sql.Add(' ALTER TABLE MENSAGEM ADD CONSTRAINT PK_MENSAGEM PRIMARY KEY (CDDITADO); ');
                  ExecSQL;

            {$ENDREGION}

          end
          else
          begin

            {$REGION ' CRIA AS MENSAGENS PADRÃO '}

              Close;
              SQL.Clear;
              SQL.Add( ' SELECT * FROM MENSAGEM ' );
              Open;
              if IsEmpty then
              begin

                      // ****                           Insert Default Rows                     ****/
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES (''Provérbio Popular'', 1, ''"Um grama de exemplos vale mais do que uma tonelada de conselhos. "'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 2, ''"Aprende-se mais no trato do que nos tratados."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Ditado Americano'', 3, ''"O Poder está com quem sabe." '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 4, ''"Todos aqueles que encontramos profundamente, formam-nos, modificam-nos e constroem-nos."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Maomé'', 5, ''"Uma boa ação é aquela que faz aparecer um sorriso no rosto do outro."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Earl Wilson'', 6, ''"O sucesso nos negócios é apenas uma questão de sorte. Pergunte a qualquer fracassado."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Francisco Pereira'', 7, ''"Como se pode construir um mundo sem maldade, se cada um de nós contribui com a sua quota de maldade. Felizmente que também contribui-mos com a nossa bondade."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Bruce Peters'', 8, ''"Proper Planning Prevents Poor Performance (Planejamento Adequado Evita Resultados Fracos)."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Walt Whitman'', 9, ''"Camarada, isto não é um livro, quem o toca, toca num homem."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Provérbio Chinês'', 10, ''"Jamais se desespere em meio às sombrias aflições de sua vida, pois das nuvens mais negras cai água límpida e fecunda."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Carl Rowan'', 11, ''"A biblioteca é o templo do saber, e este tem libertado mais pessoas do que todas as guerras da história."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Jackson Brown'', 12, ''"No jogo da vida, nem mesmo um camarote me interessa. Eu vim para jogar"  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Provérbio Chinês'', 13, ''"Não se faz uma bolsa de seda com orelha de burro."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Shakespeare'', 14, ''"Há quedas que provocam ascensões maiores."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Menny Ford'', 15, ''"Os dias prósperos não vêm por acaso; nascem de muita fadiga e muita persistência."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Thoreau'', 16, ''"Este mundo não é senão um circo para as nossas imaginações."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Ella Wilcox'', 17, ''"Ri... e o mundo rirá contigo; chora... e tu chorarás sozinho."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 18, ''"Saudades é melhor do que caminhar sozinho."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Charron'', 19, ''"Quem recebe um benefício, não deve esquecê-lo; quem o faz, não deve lembrá-lo."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 20, ''"Amar é como voar. É sentir a sensação de estar no alto, é ter medo de cair. É fazer dos pesadelos sonhos, é sentir-se pequenino perto de quem ama; é sentir-se grande, ao saber ser amado."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Mário Lúcio de Oliveira'', 21, ''"O que não é medido não é gerenciado."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''B. Frank Brown'', 22, ''"Há duas maneira de chegar ao alto de um carvalho: podemos subir nele, ou sentar em cima de uma semente."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 23, ''"Escale alto, escale longe... sua meta é o céu, seu alvo as estrelas."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Millôr'', 24, ''"Tem gente que se acha honesta só porque não sabia nada."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Robert Heller'', 25, ''"Dobrando a carga de trabalho, não se dobra o trabalho."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Samuel Johnson'', 26, ''"Quem elogia a todos não elogia ninguém."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Paul Valéry'', 27, ''"Às vezes penso, as vezes sou."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Quetin Crisp'', 28, ''"Minha função na vida era esclarecer o que já era visível cegamente."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Inge'', 29, ''"Quem come da árvore do conhecimento sempre acaba expulso de algum paraíso."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 30, ''"Depois do fracasso em distinguir pensamentos e coisas, deixamos de distinguir palavras e pensamentos. Achamos que basta rotular uma coisa para entendê-la." '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Agnes Demille'', 31, ''"A expressão mais genuína de um povo reside na dança e na música. Os corpos nunca mentem."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 32, ''"Ao sobrevir a minha morte, quero que todos os que me conheceram possam dizer: sempre arrancou um espinho onde pôde, e plantou uma flor onde ela pudesse crescer."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 33, ''"Evitar a felicidade com medo que ela acabe; é o melhor meio de ser infeliz."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Disraeli'', 34, ''"Conscientizar-se da própria ignorância é um grande passo para aprender."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Tsai Chih Chung'', 35, ''"O aperfeiçoamento pessoal se refere a todas as atividades diárias, que devem ser realizadas com cuidado e honestidade. Assim cada pequena tarefa refletirá a verdade."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Deepak Chopra'', 36, ''"Quanto menos acrires o coração aos outros, mais o farás sofrer."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 37, ''"A rotina é a base da insatisfação. Aja sempre com criatividade."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Roger Du Gard'', 38, ''"O pensamento só começa com a dúvida."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Flávio Conti'', 39, ''"Jamais confunda mau marketing com culpa do governo."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Philip Crosby'', 40, ''"A qualidade é grátis. Não é presente, mas é grátis. O que custa dinheiro são coisas sem qualidade."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Chico Anísio'', 41, ''"Na boca de quem não presta, quem é bom não tem valia." '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Sócrates'', 42, ''"A vida que não passamos em revista não vale a pena viver."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 43, ''"Dedique-se com esmero mesmo nas pequenas tarefas."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Carl Sandburg'', 44, ''"Sou um idealista. Não sei aonde vou, mas já estou a caminho."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Livro dos Provérbios'', 45, ''"A misericórdia e a verdade guardam ao rei, e o seu trono se firma com a clemência."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 46, ''"O que é maleável não se quebra. Viva sempre com sentimento flexível."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Livro dos Provérbios'', 47, ''"A alma farta pisará o favo do mel, e a alma faminta até o amargo tomará por doce."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Warren G. Bennis'', 48, ''"A fábrica do futuro tem apenas 2 empregados: um homem e um cachorro. O homem estará lá para alimentar o cachorro, e o cachorro, para impedir que o homem toque no computador."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Gregory Nathan'', 49, ''"Quando a realidade e a percepção se enfrentam, a realidade sempre perde."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Bob Galvin'', 50, ''"Acredito que, em última análise, a função do líder é espalhar esperança."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Emily Dickinson'', 51, ''"A sorte não é um acaso, é trabalho árduo. O sorriso valioso da sorte é conquistado."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 52, ''"Execute com fé tudo o que decidiu."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 53, ''"Nós crescemos na proporção que amamos."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''John W. Gardner'', 54, ''"Os executivos ganham subordinados... Mas precisam de seguidores."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Alexandre Brito'', 55, ''"Sempre corri de mim como uma criança, atrás de um balão levado pelo vento. Eu era o vento e não sabia."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Arthur Schopenhauer'', 56, ''"Existe em nós alguma coisa mais sábia que a nossa cabeça."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Finley Dunne'', 57, ''"O passado sempre parece melhor do que realmente foi."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Alexandre Graham Bell'', 58, ''"Nunca ande pelo caminho traçado, pois ele conduz até onde os outros foram."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Serge Kpangni Malan'', 59, ''"Quando há sofrimento em algum lugar, esse sofrimento na verdade afeta a todos e não apenas a alguns em particular."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Eclesiástes'', 61, ''"Para tudo existe uma época, e uma hora para cada propósito abaixo do céu."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Simone Weil'', 62, ''"Nada no mundo pode impedir o homem de se sentir nascido para a liberdade. Jamais, aconteça o que acontecer, ele pode aceitar a escravidão pois ele pensa."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 63, ''"Antes de falar, esforce-se em ouvir os outros."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Frei Leonardo Boff'', 64, ''"Todo ser é completo por si."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Rousseau'', 65, ''"As injúrias são as razões dos que não têm razão."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Ib Araripe Soares'', 66, ''"O caráter é o espelho da consciência."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Raphael De Cara'', 67, ''"A situação anda tão negra que representante de fábrica de biscoitos está comendo o mostruário, para garantir o almoço."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Conrad Hilton'', 68, ''"O sucesso parece estar diretamente vinculado à ação."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Helena P. Blavatsk'', 69, ''"Sê humilde se queres adquirir sabedoria; sê mais humilde ainda, quando a tiveres adquirido."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Livro dos Provérbios'', 70, ''"Melhores são as feridas feitas pelo que ama, do que os ósculos fraudulentos do que quer mal."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 71, ''"Dê vida aos objetos e ao dinheiro utilizando-os para o bem da sociedade."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Voltaire'', 72, ''"A história dos grandes acontecimentos do mundo não é mais do que a história dos seus crimes."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''José de Paiva Netto'', 73, ''"Se há noite escura, também existe manhã radiante."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Eleanor Roosevelt'', 74, ''"O futuro pertence aqueles que acreditam na beleza dos seus sonhos."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Machado de Assis'', 75, ''"Não levante a espada sobre a cabeça de quem te pediu perdão."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''André Gilde'', 76, ''"Tudo já foi dito uma vez, mas como ninguém escuta é preciso dizer de novo."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Arthur Riedel'', 77, ''"Uma atitude vitoriosa é meio caminho andado para o sucesso."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Tobias'', 78, ''"Tome cuidado para nunca fazer a outro o que não gostaria que fizessem a você."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Ney Matogrosso'', 79, ''"É preciso ir se aprimorando para ter cada vez mais consciência do que deve ser feito aqui."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Ib Araripe Soares'', 80, ''"Assim como são úteis para a vida, as pequenas doses de veneno; assim são nossas pequenas quedas na escalada para a perfeição."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Eclesiástes'', 81, ''"As palavras dos sábios são ouvidas em silêncio, mais do que o clamor do príncipe entre os insensatos."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Bern Williams'', 82, ''"Que mundo estranho seria este se todos tivéssemos o mesmo senso de humor..."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Marshal McLuhan'', 83, ''"Só os novos segredos necessitam de proteção. As grandes descobertas são protegidas pela incredulidade pública." '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Livro dos Provérbios'', 84, ''"Mais vale o bom nome do que muitas riquezas: a amizade é mais estimável do que a prata e o ouro."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 85, ''"Com o meu conhecimento posso escrever um livro, e com o que desconheço pode-se escrever uma biblioteca."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 86, ''"A conversação enriquece a compreensão; mas a solidão é a escola do gênio."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 87, ''"Dois homens olharam através das grades da prisão, um viu a lama o outro as estrelas."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Provérbio Indiano'', 88, ''"A alma não está onde há vida, mas onde há Amor."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 89, ''"A dificuldade é um sinal de que você esta vivo. Supere-a com alegria e gratidão."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Oscar Wilde'', 90, ''"O que é a mente senão o movimento na esfera intelectual?"  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Robert Half'', 91, ''"Ninguém pode estar certo o tempo todo, mas estar certo a maior parte do tempo ajuda."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Khalil Gibran'', 92, ''"O trabalho é o amor tornado visível."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Tom Cruise'', 93, ''"O otimismo é um sentimento revolucionário quando induz à consciência do ambiente e à consciência do que se é, pois assim se pode tanto avaliar o que está ocorrendo quanto crescer."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Livro dos Provérbios'', 94, ''"Os bens que se ajuntam muito depressa, diminuir-se-ão: mas os que se colhem à mão pouco a pouco, multiplicar-se-ão."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Oscar Lorenzo Fernandez'', 95, ''"O futuro é hoje e, se não corrermos, terá sido ontem."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Nívea Motta'', 96, ''"O Sorriso é algo muito precioso para ficar oculto em seu rosto."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 97, ''"Expresse o seu sentimento de gratidão de forma clara e concreta."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Júlio Ribeiro'', 98, ''"Todas as respostas que tínhamos decorado tornaram-se inúteis porque as perguntas mudaram."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Martin L. King'', 99, ''"Nossa geração não lamenta tanto os crimes dos perversos quanto o estarrecedor silêncio dos bondosos."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 100, ''"Desafie a novidade, sem temer o fracasso."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Albert Einstein'', 101, ''"Uma coisa só é impossível até que alguém duvida e acaba provando o contrário."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Bery Markham'', 102, ''"Se um homem tiver alguma grandeza dentro de si, ela aparecerá não em um momento espetacular, mas no registro do seu dia-a-dia."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''John Kenneth Galbraith'', 103, ''"Se tudo mais falhar, algum erro espetacular poderá garantir a imortalidade."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 104, ''"Não acredite em nada que lhe disserem. Se sua mãe disser que o ama, verifique."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Bob Levy'', 105, ''"Com a velocidade atual de mudança na tecnologia, até o futuro já esta obsoleto."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Duque de François Poitou La Rochefoucauld'', 106, ''"O primeiro dos bens, depois da saúde, é a paz interior."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Beethoven'', 107, ''"Ainda não se levantaram as barreiras que digam ao gênio: Daqui não passarás."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 108, ''"Amigos não são aqueles que passam pela sua vida e se tornam um fato, mas sim aqueles que permanecem eternamente."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 109, ''"O homem quando ia nascer pediu a Deus: Dê-me um par de galochas, um guarda-chuvas e uma capa. O homem nasceu, veio a tempestade e ele disse: Senhor ajuda-me. O senhor respondeu: use aquilo que eu lhe dei."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 110, ''"Eu sei que você crê que entende aquilo que você pensa que eu digo. Mas eu não tenho certeza se você percebe que o que você ouve não é aquilo que eu quero dizer."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Victor Hugo'', 111, ''"A prudência é a filha mais velha da sabedoria."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Vouvenhargues'', 112, ''"Os nossos protetores mais seguros são os nossos méritos." '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Confúcio'', 113, ''"De nada vale tentar ajudar aqueles que não se ajudam a si mesmos."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''George Eliot'', 114, ''"Nada é tão bom como parece à primeira vista."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Samuel Goldwin'', 115, ''"Não de atenção aos seus críticos. Mas também não os ignore."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Sabedoria Judaica'', 116, ''"O homem que fala mal de ausentes em tua presença, falará mal de ti em tua ausência. Afasta-te dele."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Ib Araripe Soares'', 117, ''"O corpo é a janela da alma, pelo qual vislumbra e sente o Universo exterior, o espelho por onde toma consciência de sua existência."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Elmer Letterman'', 118, ''"Sorte é o que acontece quando a preparação encontra a oportunidade."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''José de Paiva Netto'', 119, ''"É nos momentos de crise que se forjam os grandes caráteres e surgem as mais poderosas nações."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Bud Hadfield'', 120, ''"Não venda algo que você mesmo não compraria."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 121, ''"É imprescindível aperfeiçoar nosso modo de ver e de sentir, a fim de avançarmos no rumo da vida superior."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Eric Hoffer'', 122, ''"A procura pela felicidade é um dos fatores básicos para a infelicidade."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Rui Barbosa'', 123, ''"A justiça atrasada não é justiça, senão injustiça qualificada e manifesta."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''J. Camargo'', 124, ''"O mentiroso faz dois esforços: mentir e segurar a mentira."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 125, ''"Jamais tire a esperança de alguém. Pode ser a única coisa que ainda lhe resta."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Provérbio Chinês'', 126, ''"Uma árvore leva dez anos para amadurecer; um homem leva cem anos para se formar."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Tom Lambert'', 127, ''"Consultoria, ou é uma profissão, ou não é nada."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Eclesiástes'', 128, ''"Melhor é ser repreendido pelo sábio, do que ser enganado pela adulação dos insensatos."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Voltaire'', 129, ''"Não concordo com o que dizes, mas defendo até a morte o direito de o dizeres."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Guerra Junqueiro'', 130, ''"Para educar as crianças é preciso amá-las."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Bob Hope'', 131, ''"Banco é um lugar onde lhe emprestam dinheiro se você conseguir provar que não precisa dele."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''José de Paiva Netto'', 132, ''"O milagre que Deus espera dos homens é que aprendam a amar-se."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Marjorie Blanchard'', 133, ''"Tenha uma meta. Uma meta é apenas um sonho com um prazo para acontecer."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Waylon Jennings'', 134, ''"A honestidade é algo que não se esgota."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Celso Furtado'', 135, ''"Só um economista imagina que um problema de economia é estritamente econômico."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Carl Sandburg'', 136, ''"Permita-se guardar uma alegria. Estenda as mãos e apanhe-a quando ela passar."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Bud Hadfield'', 137, ''"Vencer é um hábito. Infelizmente, perder também é."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Marcelo Cherto'', 138, ''"O que nos diferencia de nossos concorrentes não é tanto o que fazemos. É como fazemos."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Machado de Assis'', 139, ''"Não levantes a espada sobre a cabeça de quem te pediu perdão."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Ib Araripe Soares'', 140, ''"As respostas não estão veladas ao entendimento, as pessoas é que estão."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 141, ''"A luz vem do interior, da paz interna de cada ser e brilha a medida que permitamos que ela flua, '
                        + 'que não sejamos como a rocha, mas sim que tenhamos a capacidade de nos erguer sobre as tempestades e ver o sol que está lá nos esperando."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Epicuro'', 142, ''"O prazer é o primeiro dos bens. É a ausência de dor no corpo e de inquietação na alma."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Raul Seixas'', 143, ''"Eu não preciso ler jornais, mentir sozinho eu sou capaz."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Krishnamurti'', 144, ''"Se realmente entendemos o problema, a solução virá dele. Porque a solução não está separada do problema."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 145, ''"A covardia é o medo aceito, a coragem o medo vencido."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Alfred Strieglitz'', 146, ''"Todo o tipo de arte, assim como todo o tipo de amor, está enraizado no sofrimento."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Shakespeare'', 147, ''"Tu não tens a metade do poder de ferir-me, como eu tenho de ser ferido."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Pope'', 148, ''"Aquele que diz uma mentira não sabe a tarefa que assumiu, porque está obrigado a inventar vinte vezes mais para sustentar a certeza da primeira."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 149, ''"Transforme as pedras que você tropeça, nas pedras da sua escada."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 150, ''"Saboreie a alegria da perseverança."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 151, ''"Cada dia que surge constitui uma nova vida para quem sabe viver."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Louise Leber'', 152, ''"Sempre existe espaço para melhorar. Aliás, é o lugar mais espaçoso da casa."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Saul Bellow'', 153, ''"Todos precisam de recordações. Elas afastam o horror da insignificância."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Provérbio Árabe'', 154, ''"O sábio que não diz o que sabe é como a nuvem que passa e não traz chuva."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Betty Smith'', 155, ''"O Perdão é uma dádiva altamente valiosa. Seu custo, no entanto, é nulo."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Micheel D. Eisner'', 156, ''"Refazer-se de um fracasso muitas vezes é mais fácil do que construir a partir do sucesso."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Marquês de Maricá'', 157, ''"Ler sem refletir é comer sem digerir."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Talmude'', 158, ''"Não vemos as coisas como elas são, e sim como nos parecem."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 159, ''"Envide maior esforço no sentido da sua renovação interior. Dissipe as sombras. Busque a luz."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Edmond Rostand'', 160, ''"Todas as nossas almas estão escritas nos nossos olhos."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Quintiliano'', 161, ''"Antes perder a vida do que a esperança."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Joe Louis'', 162, ''"Todo mundo quer ir para o Céu, mas ninguém quer morrer."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Alexandre Bergamo'', 163, ''"O cliente compra pelas razões dele, não pelas nossas."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Saint-Exupéry'', 164, ''"O verdadeiro amor nunca se desgasta. Quanto mais se dá mais se tem."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 165, ''"O desequilíbrio emocional prejudica a saúde. Viva sempre com naturalidade." '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 166, ''"Eu costumava ficar chateado, agora acho só engraçado."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Henry David Thoreau'', 167, ''"Se você construiu castelos no ar, não terá desperdiçado seu trabalho, pois no alto é onde devem estar. Agora coloque fundações embaixo deles."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''La Rochefoucauld'', 168, ''"Não há homem que tenha menos razão do que aquele que não tolera a idéia de não ter razão."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Karl Marx'', 169, ''"Um problema só surge quando estão presentes todas as condições para solucioná-lo."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''José Martí'', 170, ''"Quem vai em busca de montes, não se detém a recolher as pedras do caminho."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Adlai Stevenson'', 171, ''"Aqueles que corrompem a opinião pública são tão funestos como aqueles que roubam as finanças públicas."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Jackson Brown'', 172, ''"Não vemos as coisas como elas são, mas como nós somos."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Sheneur Zalman'', 173, ''"As palavras são a pena do coração, mas a música é a pena da alma."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Henry Ford, atualizado por Júlio Lobos'', 174, ''"Não é o Empregador quem paga os salários. Ele só os entrega. Quem paga os salários é o Cliente."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Bill Gates'', 175, ''"Trabalhamos com o objetivo de tornar nossos produtos obsoletos, antes que os concorrentes o façam."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 176, ''"O verdadeiro órgão da visão não são os olhos, mas o conhecimento."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 177, ''"Recordações, vire o rosto em direção à Lua, deixe-se levar pelas recordações. Abra, entre! Se você descobrir o que é a felicidade uma nova vida vai começar."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Ib Araripe Soares'', 178, ''"A vida é uma escola de formação humana, que nos obriga repeti-la ao não aprendermos a lição."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Bertrand Russell'', 179, ''"Para que repetir os erros antigos, quando há tantos erros novos a cometer?"  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Ib Araripe Soares'', 180, ''"O grande vencedor se conhece não pelas vitórias que alcança, mas pelas derrotas que assimila."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Ron Nesen'', 181, ''"Ninguém acredita no porta-voz oficial, mas todos dão crédito a uma fonte não identificada."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Luís Amaral'', 182, ''"O melhor meio de ser bem servido é servir bem."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Sigmund Freud'', 183, ''"É impossível ter uma compreensão satisfatória do distúrbio neuropsicótico se não se puder fazer conexões com o processo mental normal."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Moses Ibn Ezra'', 184, ''"Qualquer um que persista em bater a porta, terá sucesso em entrar."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 185, ''"A verdade irá liberta-lo, mas antes irá deixa-lo louco."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 186, ''"Uma visão sem ação é um sonho. Ação sem visão é passatempo. Mas se aliarmos nossas visões a nossas ações faremos diferença no Universo."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Will Rogers'', 187, ''"Não podemos dizer que a civilização não progride: em cada guerra, matam-nos de maneira nova."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Magee'', 188, ''"Só não erra nunca o que nunca faz nada."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Henry Ward Beecher'', 189, ''"As flores são as coisas mais lindas que Deus fez - e esqueceu-se de dar-lhes alma."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Oswaldo Cruz'', 190, ''"Pelos erros dos outros, o homem sensato corrige os seus."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Bernard Berenson'', 191, ''"Ser coerente significa ser tão ignorante hoje quanto se era um ano atrás."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Ralph Waldo Emerson'', 192, ''"Com a ingenuidade do menino, a esperança retrata os anseios do adulto."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Gregory Nathan'', 193, ''"Marketing é tudo aquilo que você faz para levar alguém a comprar o que você tem para vender."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Néocles Costa Carvalho'', 194, ''"Caro é aquilo que custa pouco dinheiro, mas não produz o resultado esperado."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Tsai Chih Chung'', 195, ''"Todos os opostos - bem e mal, ter ou não ter, ganhar e perder, eu e os outros - dividem a mente. Ao aceitá-los nos afastamos de nossa mente original e sucumbimos a esse dualismo."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Carlos Lacerda'', 196, ''"O futuro não é o que se teme. O futuro é o que se ousa."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 197, ''"Destino não é uma questão de chance; é uma questão de escolha."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''C. Fiessinger'', 198, ''"Pede tudo a ti mesmo; evita, o mais possível, pedir aos outros."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Grant Tinker'', 199, ''"Primeiro seremos os melhores, depois os primeiros."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 200, ''"Não pense desnecessariamente. Aja."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Livro dos Provérbios'', 201, ''"Cada um será cheio de bens conforme for o fruto da sua boca, e ser-lhe-á dada a retribuição conforme forem obras das suas mãos."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Lema dos Tupamaros'', 202, ''"Palavras nos separam, ações nos unem."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Eclesiástes'', 203, ''"O amigo fiel é um medicamento de vida, e de imortalidade."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Livro dos Provérbios'', 204, ''"Até o insensato passará por sábio, se estiver calado: e por inteligente, se cerrar os seus lábios."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Muhammed Ali'', 205, ''"Aquele que vê o mundo aos 50 anos da mesma forma que o via aos 20 desperdiçou 30 anos de sua vida."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''C. Parkinson'', 206, ''"O trabalho se expande até preencher todo o tempo disponível."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Charles B. Wang'', 207, ''"A data de vencimento das reclamações foi ontem."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 208, ''"Seja autêntico consigo mesmo. Viva com dignidade."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Francisco Pereira'', 209, ''"Uma imagem é apenas um conjunto de pontos, como o mar é um conjunto de gotas. Assim o que vale mais uma gota ou um ponto."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Louis Pasteur'', 210, ''"Vou lhes contar o segredo que me conduziu à vitórias. Minha força reside na minha tenacidade."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Marcelo Rubens Paiva'', 211, ''"Alienado é o poder, não o jovem."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Fred Adler'', 212, ''"Um fluxo de caixa positivo é o único rio que conduz à felicidade."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Ronald Reagan'', 213, ''"O Contribuinte é o único cidadão que trabalha para o Governo sem ter que prestar concurso."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Han Yu'', 214, ''"Quem se senta no fundo de um poço para contemplar o céu, há de achá-lo pequeno."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Leo Baeck'', 215, ''"Através da fé, o homem conhece o significado do mundo, através da ação ele faz ter significado."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''S. Brown'', 216, ''"Não há muito que possamos fazer quanto à nossa vida de aparência, mas temos o controle total sobre o tipo de pessoa que nos tornamos."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Napoleão'', 217, ''"Em política, a estupidez não é uma desvantagem."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Charles Dubois'', 218, ''"O importante é termos a capacidade de sacrificar aquilo que somos para ser aquilo que podemos ser."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''J. G. Olanda'', 219, ''"O coração é mais sábio que o intelecto."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 220, ''"Faça as coisas o mais simples que você puder, porém não as mais simples."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''David Lloyd George'', 221, ''"Não se pode saltar sobre um abismo com dois pulos pequenos."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Heráclito'', 222, ''"Nada é permanente. A não ser a mudança."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Francisco Meirelles'', 223, ''"No encontro entre um sábio e um idiota, o sábio tira mais proveito."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Gibran Gibrail'', 224, ''"Tudo o que vês é miragem. Procura a essência que não se vê."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Moliére'', 225, ''"As dúvidas são mais cruéis do que as duras verdades."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Lao-Tsé'', 226, ''"Uma longa viagem começa com um único passo."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''George Bernard Shaw'', 227, ''"Os jornais, ao que parece, são incapazes de distinguir um acidente de bicicleta do colapso da civilização."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Friedrich Von Schiller'', 228, ''"É a vontade que faz um homem grande ou pequeno."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Albert Einstein'', 229, ''"A coisa mais incompreensível do universo é que ele é compreensível."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Otto Lara Resende'', 230, ''"Não sou homem de ter uma opinião no bolso e outra na lapela."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Livro dos Provérbios'', 231, ''"Aquele que semeia a iniquidade, segará males e será ferido pela vara da sua ira."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 232, ''"Não acredites que possas evoluir sem problemas ou que consigas aperfeiçoar-te sem sacrifícios."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Salomão'', 233, ''"Assim como é uma cidade toda aberta, e que não está cercada de muros, assim é o homem, que quando fala não pode conter seu espírito."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Atribuído a Jorge Luis Borges'', 234, ''"Se pudesse viver minha vida outra vez, trataria de cometer mais erros."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''G. Shaw'', 235, ''"O poder da observação cuidadosa é chamado cinismo por aqueles que não o possuem."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Jean Paul Richter'', 236, ''"Para que o sono, a fortuna e a saúde sejam realmente apreciados, devem ser interrompidos."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Lubienska de Lenval'', 237, ''"A lição do silêncio tem grande valor educativo: conduz a um verdadeiro domínio de si."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Jonathan Kozol'', 238, ''"Escolha batalhas grandes a ponto de preocupa-lo, mas pequenas a ponto de vence-las."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''A. Bartlett Giamatti'', 239, ''"Da vitória emana feliz e discreta pureza, impossível de substituir."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Waine W. Dyer'', 240, ''"O que você é se encontra no reino imensurável a que chamamos pensamento."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Richard Grant'', 241, ''"Quando você contrata pessoas mais inteligentes do que você, prova que é mais inteligente do que elas."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Baden Powell'', 242, ''"A melhor maneira de ser feliz é contribuir para a felicidade dos outros."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 243, ''"A determinação de hoje, resulta no sucesso amanhã."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Pantini'', 244, ''"As boas ações nos purificam e nos dão sonhos felizes."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Charles B. Wang'', 245, ''"Um gerente, num buraco de 3 metros de profundidade,'
                        + ' não é bem auxiliado por um chefe que lhe estende uma corda de 2 metros e depois não entende por que o gerente ainda esta descontente. Afinal, ele cumpriu mais da metade da sua tarefa."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 246, ''"Não temos em nossas mãos a solução para todos os problemas do mundo; mas, diante dos problemas do mundo, temos nossas mãos."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Robert Frost'', 247, ''"Eu posso estar dizendo isso com um suspiro, em algum lugar anos e anos daqui: duas estradas divergem numa floresta, e eu escolho a menos usada, e isso tem feito toda a diferença."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''P. Ciro'', 248, ''"O juiz é condenado quando o criminoso é absolvido."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''José Hernandez'', 249, ''"A oportunidade é como ferro: devemos batê-lo enquanto estiver quente."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Aldous Huxley'', 250, ''"Experiência não é o que acontece a você. É o que você faz com o que acontece a você."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''S. Brown'', 251, ''"Se você quer mudar tudo, basta mudar a sua atitude."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Faye Dunaway'', 252, ''"O fato de se poder fazer o que está na mente, de certa forma dita o rumo dos acontecimentos. Assim, quem nos guia em direção a uma vida saborosa é a pessoa que somos."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Émile de Girardin'', 253, ''"O instinto é o olfato do espirito."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 254, ''"Mesmo que vivas um século, nunca deixes de aprender."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 255, ''"Reconheça as suas falhas sem justificar-se. Seja responsável por seus atos."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 256, ''"Desapegue do resultado. Desfrute do processo."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Julio Lobos'', 257, ''"Se você não tem fracassos na vida, é porque deixou de assumir os riscos que devia."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''W. Deming'', 258, ''"Nenhum cliente pediu um automóvel. Temos cavalos: quer mais do que isso?"  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Thomas Edison'', 259, ''"Nunca trabalhei um dia na minha vida: foi sempre diversão."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 260, ''"Nós lhe demos um orçamento ilimitado e você já o ultrapassou."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''S. Brown'', 261, ''"Nunca subestime o seu poder de mudar a si mesmo, e nunca superestime o seu poder de mudar os outros."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Sêneca'', 262, ''"Nunca a fortuna põe um homem em tal altura que não precise de um amigo."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Provérbio Siciliano'', 263, ''"Mantenha os amigos por perto; quanto aos inimigos, mantenha-os mais perto ainda."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''David Riesman'', 264, ''"Estude as frases que parecem certas e coloque-as em dúvida."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Confúcio'', 265, ''"Até que o sol não brilhe, acendamos uma vela na escuridão."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Antoine Rivarol'', 266, ''"A esperança é um empréstimo que se faz em favor da felicidade."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Alba'', 267, ''"Quem deseja reformar o mundo deve começar por si próprio."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''São Cirilo de Alexandria'', 268, ''"Toda nossa vida é uma primavera, porque temos em nós a verdade que não envelhece, e essa verdade anima toda a caminhada."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Jesus Cristo'', 269, ''"O teu olho é a luz do teu corpo. Se o teu olho for simples, todo o teu corpo será lúcido: se porém for mau, também o teu corpo será tenebroso."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Provérbio Chinês'', 270, ''"Quando o dinheiro fala, a verdade cala."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 271, ''"Tudo que realmente é verdadeiro, é eterno! Como o amor, as palavras, os ensinamentos... E nossa alma. Se algo acabou em sua vida, é porque isto não é, e nunca foi algo verdadeiro."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Napoleon Hill'', 272, ''"A maioria das pessoas só aprende as lições da vida, depois que a mão dura do destino lhe toca nos ombros."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Doug Larson'', 273, ''"Há muita gente que confunde memória curta com consciência tranquila."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Ralph Waldo Emerson'', 274, ''"Nada pode te dar a paz além de você mesmo."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Mark Twain'', 275, ''"Coragem é resistência ao medo, domínio do medo, e não ausência de medo."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 276, ''"Culpar aos outros impedirá o seu progresso. Seja responsável por sua felicidade."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Tom Peters'', 277, ''"A maior parte dos programas de qualidade cai por uma de duas razões: eles têm sistemas sem paixão, ou paixão sem sistema. É preciso ter ambas."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 278, ''"Nada é mais simples que a grandeza. Na verdade, ser simples é ser grande."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Cervantes'', 279, ''"Mais vale grande esperança do que mísera conquista."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Henrique Meirelles'', 280, ''"Não aprenda com os próprios erros. Aprenda com os erros dos outros."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Segurs'', 281, ''"A dúvida é o começo da sabedoria."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Richard Bach'', 282, ''"Acreditamos em Deus: todos os outros devem apresentar fatos."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Bengurion'', 283, ''"O teste da democracia é a liberdade de crítica."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Livro dos Provérbios'', 284, ''"Ouve o conselho, e recebe a correção, para que sejas sábio no fim da tua vida."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 285, ''"Cultive sua fé religiosa, orando a Deus."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 286, ''"Hoje vou ser humilde o suficiente, para reconhecer que sou portador de alguns direitos, e reunindo as minhas forças, vou transformá-los em virtudes."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Tsai Chih Chung'', 287, ''"A mente da pessoa perfeita é como um espelho. Nada tira e nada recebe; reage, mas não armazena. Então quando for a hora de ser um general, seja um general, e quando for a hora de ser um monge; seja um monge."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Cássia Eller'', 288, ''"Faz do seu delito o vão que lhe permite ver o sol."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Goethe'', 289, ''"Cada novo dia nos repete: espera o impossível, faça o possível."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Schiller'', 290, ''"A falta de coragem é o pior dos perigos."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Lord Keynes'', 291, ''"Quando a realidade muda, minhas convicções também mudam."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Néocles Costa Carvalho'', 292, ''"A explicação nos afasta da solução."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Georgetta Raposo de Almeida'', 293, ''"O que arde cura. E o que aperta segura."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Provérbio Árabe'', 294, ''"Acredite em Alá, mas amarre o seu camelo."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Jonathan Coe, Jimmy Sterwart'', 295, ''"Não há nada que saia de moda mais depressa do que as tentativas de ontem de ser controverso."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Livro dos Provérbios'', 296, ''"A justiça exalta as nações: mas o pecado faz miseráveis os povos."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Herbert Von Karajan'', 297, ''"Quem decide pode errar. Quem não decide já errou."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Tom Lambert'', 298, ''"Não há nada mais perigoso do que acreditar que se detém a fórmula que vai continuar sempre conduzindo ao sucesso."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Tsai Chih Chung'', 299, ''"Exercite com capricho e amor todas as tarefas que recebe, embora pareçam insignificantes."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Charles B. Wang'', 300, ''"Conheço tudo que preciso conhecer... se eu me aposentar até as 15 horas de hoje."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Tolstoi'', 301, ''"Cada um pensa em mudar a humanidade, mas ninguém pensa em mudar-se a si mesmo."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Karen Horney'', 302, ''"A preocupação deveria levar-nos à ação e não à depressão."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 303, ''"Por maior que sejam nossos cansaços, sempre é pouco para um pai trazer um filho nos braços."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Benjamin Franklin'', 304, ''"Bem feito é melhor do que bem explicado."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 305, ''"Não ame o que você é, mas apenas o que pode tornar-se."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''José de Paiva Netto'', 306, ''"O Amor revela a Luz e a Luz espanta as trevas. Que mais quereremos nós?"  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Baden Powell'', 307, ''"Creio que se Deus nos colocou nesta terra de tantas belezas foi para que sejamos felizes."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Thomas Edison'', 308, ''"Mostre-me um homem 100% satisfeito e eu lhe mostrarei um fracassado."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Alberto Saraiva'', 309, ''"Infelizmente, há mais pessoas preocupadas em dar explicações do que em encontrar soluções."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Bertold Brecht'', 310, ''"Precisamos aprender a compreender a mudança que se dá em nós, quer dizer; precisamos desenvolver um sexto sentido para a história."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Robert C. Savage'', 311, ''"Poder-se avaliar um homem pela medida do que é preciso fazer para desencorajá-lo."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Pitágoras'', 312, ''"Eduquem-se as crianças... e não será preciso castigar os homens."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Charles Haddon Spurgeon'', 313, ''"Aprenda a dizer não. Será melhor para você do que aprender latim."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Marco Aurélio'', 314, ''"O homem comum é exigente com os outros; o homem superior é exigente consigo mesmo."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''James Russel Lowell'', 315, ''"Abençoados os que não têm nada a dizer e que não se deixam persuadir a dizê-lo."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''David Russell'', 316, ''"A coisa mais difícil na vida é distinguir as pontes que se devem cruzar das que devem ser queimadas."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Livro dos Provérbios'', 317, ''"O coração do homem eleva-se antes de ser quebrantado: e humilha-se antes de ser glorificado."   '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 318, ''"Deixei cair uma lágrima na poeira da vida: fiz da minha lágrima uma pérola de experiência para que jamais fizesse alguém verter uma lágrima sequer."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Milton Nascimento / Fernando Brant'', 319, ''"A hora do encontro é também despedida a plataforma desta estação, é a vida."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 320, ''"A felicidade está numa lágrima que se enxuga, num sorriso que se faz desapontar, num ancião que se consola."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Sêneca'', 321, ''"Quando não se sabe para que porto estamos indo, não existe vento a favor."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''J. L. Borges'', 322, ''"Certas derrotas tem mais dignidade que uma vitória."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Nizan Guanaes'', 323, ''"É melhor aproximadamente agora do que exatamente nunca."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Ib Araripe Soares'', 324, ''"A salvação não está na palavra, mas na atitude segundo o espírito da palavra."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Henry Stimson'', 325, ''"A única maneira de tornar fidedigno um homem é confiar nele."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Gerson Keila'', 326, ''"O brasileiro não planeja para não se sentir responsável pelas metas."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Rolim Adolfo Amaro'', 327, ''"O caminho para o sucesso não é fazer uma coisa 100% melhor. É fazer 100 coisas 1% melhor."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Albert Brooks'', 328, ''"É melhor ser conhecido por seis pessoas por algo de que você se orgulhe do que por 60 milhões por algo de que não se orgulhe."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''de Unamuno'', 329, ''"Há momentos em que silenciar é mentir."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Charles Chaplin'', 330, ''"Se um dia tudo lhe parecer perdido, lembre-se de que você nasceu sem nada, e que tudo que conseguiu foi através de esforços e os esforços nunca se perdem, somente dignificam as pessoas."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''H. G. Wells'', 331, ''"O pensamento estatístico um dia será tão necessário para o exercício eficiente da cidadania como ler e escrever."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Sêneca'', 332, ''"Aquele que não impede um crime o está encorajando."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 333, ''"As pessoas se sentem solitárias porque constróem muros, no lugar de pontes."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Iris Murdoch'', 334, ''"Um dos segredos de uma vida feliz é a sucessão de pequenos prazeres."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Emily Dickinson'', 335, ''"O cérebro é maior que o céu."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Beauchêne'', 336, ''"Querer tornar-se bom, já é ser bom."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 337, ''"Nos seus momentos de aflição, não se envergonhe de baixar a cabeça e chamar por Deus."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Livro dos Provérbios'', 338, ''"Aquele que tapa os seus ouvidos ao clamor do pobre, esse mesmo também clamará, e não será ouvido."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Sheryl Green'', 339, ''"Não comece um relacionamento pressupondo que as coisas vão melhorar."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Bud Hadfield'', 340, ''"Há dois tipos de funcionário que você deve evitar: o que não faz o que você manda e o que só faz o que você manda."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''David Lloyd George'', 341, ''"Não tema dar um grande passo, se isso for o mais indicado."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 342, ''"Na vida, é tudo passageiro. Menos o motorista e o cobrador."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Ib Araripe Soares'', 343, ''"Adormecido em nos existe um Deus vivo, cujo despertar deve ter por causa o badalar dos sinos da sabedoria e da virtude."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Fafá de Belém'', 344, ''"Maturidade é quando a ansiedade é menos ansiosa."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Aparício Torelly'', 345, ''"Tudo seria fácil, não fossem as dificuldades."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 346, ''"A felicidade não é um prêmio, e sim uma consequência, a solidão não é um castigo, e sim um resultado."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''James Clerck Maxwell'', 347, ''"As leis da matéria são aquelas que nossas mentes devem fabricar, e as leis da mente são aquelas fabricadas pela matéria."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Renato Lapa Claro'', 348, ''"A única defesa contra os baques da economia é o trabalho."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Richard Bach'', 349, ''"Valorize suas limitações, e, por certo, não se livrará delas." '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 350, ''"A juventude se torna muito importante por ser a fase das grandes opções da vida."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 351, ''"Quem ama não perdoa, pois não se magoa!."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 352, ''"Reclamei dos meus sapatos rotos até o dia em que encontrei um homem que não tinha pé."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Confúcio'', 353, ''"Há pessoas que choram por saber que as rosas têm espinhos; outras há, que gargalham de alegria por saber que os espinhos têm rosas."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''lema da Coca-Cola'', 354, ''"Pensar globalmente. Agir localmente."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Emil Zatopek'', 355, ''"Acredito que somente uma pessoa que nada aprendeu não modifica suas opiniões."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 356, ''"Eduque suas tendências optando por aquilo que traga alegria ao seu espírito."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Helen Keller'', 357, ''"Nenhum pessimista jamais descobriu os segredos da estrela, nem velejou a uma terra inexplorada, nem abriu um novo céu para o espírito humano."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 358, ''"Seja respeitoso e agradecido a seus pais e superiores."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Otto von Bismarck'', 359, ''"Nunca se mente tanto como antes das eleições, durante uma guerra e depois de uma caçada."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Adágio Popular'', 360, ''"Você constitui o total da soma de todas as suas escolhas."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''T. Kempis'', 361, ''"Quem reconhece os próprios erros prova que hoje já tem mais sabedoria que ontem."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Paderewsky'', 362, ''"Querer vencer significa já ter percorrido metade do caminho da vitória."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Sêneca'', 363, ''"Ninguém conserva por longo tempo o poder exercido com violência."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''John Kennedy'', 364, ''"O conformismo é o carcereiro da liberdade e o inimigo do crescimento."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Oscar Levant'', 365, ''"Felicidade não é aquilo que você vivência; é algo que você se lembra."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 366, ''"Expresse francamente o que deve dizer."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Sam Ewing'', 367, ''"O turista comum quer visitar locais onde não haja turista."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Armando Nogueira'', 368, ''"Copiar o bom é melhor do que inventar o ruim."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Livro dos Provérbios'', 369, ''"A resposta branda quebra a ira: a palavra dura suscita o furor."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Tsai Chih Chung'', 370, ''"A iluminação, o aperfeiçoamento pessoal e as atividades diárias são parte da mesma coisa. É essencial entender esse fato da iluminação, e manter essa atitude é o aperfeiçoamento pessoal."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Colbert'', 371, ''"A grandeza de um país não depende da extensão de seu território, mas do caráter de seu povo."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Voltaire'', 372, ''"O que é uma idéia? É uma imagem que se pinta em meu cérebro."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Antífanes'', 373, ''"O afã da riqueza obscurece a noção do justo e do injusto."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Pope'', 374, ''"Algumas pessoas nunca aprendem nada porque entendem tudo muito depressa."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Francisco Pereira'', 375, ''"100% de certezas, só se pode ter sobre o passado, mas não sobre 100% do passado. O futuro é sempre incerto."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Fedor Dostoievski'', 376, ''"O Homem gosta de contabilizar os problemas, mas não conta as alegrias."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 377, ''"Aqueles que pensam no próximo não sofrem de depressão."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Livro dos Provérbios'', 378, ''"O conselho é no coração do homem como água profunda: mas o homem sábio daí o tirará."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Bill Gates'', 379, ''"Toda empresa precisa ter gente que erra, não tem medo de errar e aprende com o erro."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Madre Clara Hale'', 380, ''"Se não puder abraçar as crianças, guarde-as em seu coração."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''São Francisco de Assis'', 381, ''"É morrendo que nascemos para a vida eterna."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Louis Nizer'', 382, ''"As palavras de conforto, bem administradas, são a mais antiga terapia que o homem conhece."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 383, ''"A felicidade e a infelicidade não comparecem espontaneamente; só quando são chamadas."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Louis LAmour'', 384, ''"O Caminho é o que importa, não o seu fim. Se viajar depressa demais, vai perder aquilo que o fez viajar."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Abraham Maslow'', 385, ''"Se a única ferramenta que você tem é um martelo, você tende a tratar tudo como se fosse um prego."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Chico Anísio'', 386, ''"A maioria dos brasileiros tem medo do futuro. A maioria dos políticos tem medo do passado..."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Bradley'', 387, ''"O melhor auto-conhecimento é conhecer a própria mente."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Walt Disney'', 388, ''"Se você pode sonhar, pode fazer."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''George Orwell'', 389, ''"Quem controla o passado, controla o futuro. Quem controla o presente, controla o passado."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Provérbio Judaico'', 390, ''"Dê aos filhos raízes. Mais tarde, asas."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Ralph Waldo Emerson'', 391, ''"Autoconfiança é o primeiro segredo do sucesso."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Charles B. Wang'', 392, ''"Por favor, arranje-me um chefe de um lado só, para não termos sempre que ouvir: ...Por outro lado..."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Albert Hirschman'', 393, ''"A economia moderna é como o pára-quedas: só funciona quando está aberta."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Eduardo Galeano'', 394, ''"Somos o que fazemos, mas somos, principalmente, o que fazemos para mudar o que somos."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Mark Twain'', 395, ''"Ele não cobrava nada por seus serviços. Era o que valiam."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 396, ''"O homem erra, o imbecil permanece no erro."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 397, ''"O homem só envelhece quando nele os lamentos substituem os sonhos."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''S. Brown'', 398, ''"Encare os problemas como oportunidades para o crescimento e o autodomínio."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Patrick J. Buchanan, em Right From the Beginning.'', 400, ''"VER a pobreza apenas como uma condição econômica a ser medida por estatísticas é simplista, ilustrio e falso; a pobreza é um estado de espírito, uma questão de horizontes."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''General George S. Patton, em War As I Knew It.'', 401, ''"NUNCA diga às pessoas como fazer algo. Diga-lhes o que fazer, e elas o surpreenderão com seu engenho."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Richard Lester, Canad'', 402, ''"ANTES da era do jato, meus amigos Colin e Isa reservaram uma passagem para seu '
                        + 'País natal, a Escócia. Em determinada altura, durante o longo vôo noturno, Isa voltou-se para o marido e perguntou:- Seá que esta barulheira vai continuar toda a noite?- Espero que sim! - respondeu Colin."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Madre Teresa'', 403, ''"AQUELE que transborda de alegria reza sem rezar."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Emmet Fox'', 404, ''"Se DESEJAMOS produzir harmonia e felicidade, devemos primeiramente controlar os pensamentos em direção à Harmonia e à Felicidade; e então as coisas exteriores se seguirão naturalmente."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Gary Apple, em Current Comedy.'', 406, ''"Dê um PEIXE a um homem e o alimentaá por um dia. Ensine um homem a pescar e se veá livre dele aos fins de semana."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Masaharu Taniguchi'', 407, ''"A GENTE acaba se tornando exatamente como pensa que é. Por isso, vamos pensar sempre em coisas boas e positivas."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''G. K. Chesterton'', 409, ''"UMA das grandes desvantagens da pressa é que nos faz perder tempo demais."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Buda'', 410, ''"POR mais que na batalha se vença um ou mais inimigos, a vitória sobre si mesmo é a maior de todas as vitórias."       '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Luis de Matos'', 411, ''"O DEVER que a cada um assiste, de quantos se encontram habitando este mundo, é o de dizer ao seu semelhante, o que sabe de certo e de bom sobre uma experiéncia ou um conhecimento que colheu."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Victor Hugo'', 412, ''"O ESPIRITO se enriquece com aquilo que recebe, o coração com aquilo que dé."                          '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''D. S.'', 413, ''" A BOA VONTADE  à conquistada é custa de muitos atos... mas pode perder-se com um só."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Alba'', 414, ''"Há em TODOS nós uma voz divina que só nos fala quando as outras se calam... só no silêncio nos entrega a sua mensagem."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Maria Townseand'', 415, ''"O REMÉDIO para as nossas preocupações, consiste em se estar inteiramente ocupado, realizando alguma coisa construtiva."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Ed Cunningham'', 416, ''"AMIGOS são aquelas raras pessoas que nos perguntam como estamos e que depois ficam à espera de ouvir a resposta."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''B. Brodie'', 417, ''"Não há NADA melhor do que ser útil: esta qualidade é o elo que nos prende aos nossos semelhantes, promove o aperfeiçoamento de nosso caráter e nos dá prestígio na sociedade."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Grit'', 419, ''"O CASAMENTO é um jogo muito especial: ou ganham os dois ou ambos perdem."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Alexis Carrel'', 420, ''"AQUELES que conservam a sua paz interior em meio ao tumulto da vida moderna, estão imunizados contra as doenças nervosas."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Horácio'', 421, ''"A VIDA se tornaria insuportável se não nos proporcionasse mudanças."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Camilo Castelo Branco'', 422, ''"O GOZO de ser rico deixa de o ser, quando o ouro não compra as alegrias puras da alma."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Doug Larson'', 423, ''"O MUNDO está cheio de pessoas que buscam a suprema felicidade, enquanto menosprezam a simples satisfação."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Sakarawa'', 424, ''"TUDO que nos acontece, nos dá alguma experiência ou desenvolve alguma qualidade em nosso caráter que estava escondida." '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''James Allen'', 425, ''"Em TODAS as atividades humanas existem esforços e resultados, e a intensidade do esforço é a medida do resultado. O acaso não existe. Dons, potencialidades, bens materiais, '
                        + 'intelectuais e espirituais são frutos do esforço; são pensamentos concluídos, alvos atingidos, visões realizadas."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''A. M.'', 426, ''"Se a UNICA ferramenta que você tiver for um martelo, sua tendência vai ser encarar todos os problemas como regos."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Goethe'', 427, ''"O TALENTO educa-se na calma; o Caráter, no tumulto da vida."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Louis LAmour'', 428, ''"MELHOR que tudo é aprender; o dinheiro pode ser perdido ou roubado, a saúde e a força podem faltar, mas aquilo que você coloca na sua mente, será para sempre seu."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Alberto A. Lohmann'', 429, ''"MUITAS pessoas multiplicam seus males porque vivem lamentando o passado, preocupando-se com o futuro, em vez de viver o presente."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Alberto A. Lohnmann'', 430, ''"A MEDIDA que nos aproximamos da Verdade,  encontramos muitas coisas que antes nos iludiam e que agora são simples ninharias, obrigando-nos a modificar  nossa escala de valores." '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Larry Wilson & Hersch Wilson, em Mudando o Jogo'', 431, ''"CLARO que há ocasiões em que é prudente agir devagar e com cautela. Mas hoje, e num futuro previsível, em que mudanças rápidas e estruturais ocorrem e ocorrerão,'
                        + ' pode ser perigoso mover-se muito devagar. Will Rogers disse: Mesmo que você esteja na linha certa, se se limitar a ficar sentado, vai ser atropelado."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Hermann Hesse'', 432, ''"Um SER HUMANO só cumpre seu mais nobre dever quando tenta aperfeiçoar os dotes que a natureza lhe deu." '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Provérbio de Salomão'', 433, ''"O SERENO de espírito é homem de inteligência."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''R. W. Trine'', 434, ''"A VIDA é uma evolução interminável, passo a passo, sem pulos, sem saltos."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Zalkind Piatigorsky'', 435, ''"TUDO que tenho recebi de Deus; - de que queres que me envaideça?"  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''H. M. Tomlinson'', 436, ''"VEMOS as coisas, não como são, mas sim como somos."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Hermann Hesse'', 437, ''"O SEGREDO de toda a verdadeira arte, está, talvez, àonde a razão e a magia se tornam uma coisa só."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''O. S. Marden'', 438, ''"Á VONTADE de DEUS que prosperemos e vivamos na abundáncia de tudo quanto é bom e desejável neste mundo."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Wladimir Lindemberg'', 439, ''"Ao HOMEM colocado entre o Céu e a Terra, foi dada a Razão, o Saber e a Força, a fim de que, pensando, agindo, distinguindo, pudesse mover-se em tal harmonia, educar-se e ser feliz."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Jack Odle, em Progressive Farmer.'', 440, ''"Os CAMPONESES não foram, decerto, abençoados com mais senso que as outras pessoas. Só que o utilizam com maior frequéncia."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Thomas Mann'', 441, ''"Não CREIO que alguém na vida possa evitar a política. O próprio fato de se recusar a levar a política em consideração ... É político. E, ao fazé-lo, você está praticando o tipo errado de política."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Cláobulo'', 442, ''"Ao SAIR de casa, pense no que vai fazer; ao voltar, examine o que fez."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Araujo Porto Alegre'', 443, ''"DEUS concede o progresso a passos lentos, porque a luz repentina ofusca a vista."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Carlos Fox'', 444, ''"Se Não és rico, alegra-te porque outrem o seja; e assombrar-te-ás da felicidade que te advém do teu contentamento."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Shakespeare'', 445, ''"Ter AMOR próprio não é um pecado tão abominável quanto ignorar a si mesmo."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Paulo Coelho, em O ALQUIMISTA.'', 446, ''"DESCOBRI no caminho coisas que jamais teria sonhado encontrar se não tivesse tido a coragem de tentar coisas impossíveis."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Rosa Rubra'', 447, ''"TODOS nós nascemos ricos. Feliz de quem compreende isso e procura aumentar a sua fortuna."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Síneca'', 448, ''"NINGUÉM conserva por longo tempo o poder exercido com violência."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''León Gieco'', 449, ''"Eu só peço a DEUS que a dor não me seja indiferente, que a morte não me encontre vazio e sozinho, sem ter feito o suficiente."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Cícero'', 450, ''"Um HOMEM não deve abster-se tanto, que chegue a esquecer-se de que é homem."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''John Leo, em U.S. News & World Report.'', 451, ''"Não se pode governar uma sociedade ou enfrentar seus problemas se as pessoas não forem responsáveis pelo que fazem."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Reverendo Jesse Jackson'', 452, ''"TANTO as lágrimas quanto o suor são líquidos e salgados, mas provocam resultados diferentes. As lágrimas atrairão solidariedade, mas o suor lhe traá progresso."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Dácio Valente'', 453, ''"Não FAÇAS nem digas o que não puderes repetir publicamente."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Horácio'', 454, ''"CADA dia que surge, constitui uma nova vida para quem sabe viver."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''F. B. C'', 455, ''"Se és RICO, agradece a DEUS os bens recebidos. Que seja a tua riqueza uma corrente de utilidade permanente de onde todos partilhem. Pede sempre a DEUS, sabedoria e discernimento para usar com proveito a fortuna que recebeste."  .'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Jesus'', 456, ''"PRESTAI atenção a vós mesmos, para que os vossos corações não fiquem sobrecarregados com as consequéncias do excesso de comer, da embriaguez, das ansiedades do mundo."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 457, ''"MUITOS creem que ter talento é uma questão de sorte; poucos pensam que a sorte pode ser uma questão de talento."  Jacinto Benavente'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Agenda do movimento SOMA.'', 458, ''"PODE ser que para o outro mundo eu possa levar o que sonhei. Mas, poderei eu levar para o outro mundo o que me esqueci de sonhar?"  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Bertrand Russel'', 459, ''"O MUNDO precisa de corações e de cérebros francos; não é mediante sistemas rígidos, quer sejam velhos ou novos, que isso pode ser conseguido."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Salvador de Madariaga'', 460, ''"A CONSCIENCIA não nos impede de cometer pecados, mas infelizmente, de desfrutar deles"  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Provérbio Chinés'', 461, ''"Se te SENTARES no caminho, senta-te de frente... embora tenhas de ficar de costas para o que jás percorrestes."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Claude McDonald, em The Christian Word.'', 462, ''"Não SABEMOS se funciona o que não experimentamos."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Arthur Koestler, em The Act of Creation'', 463, ''"A PRINCIPAL característica do gênio não é a perfeição, mas a originalidade, a abertura de novas fronteiras."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Sterne'', 464, ''"O CRITÉRIO é o porteiro da imaginação; a sua função consiste em não deixar entrar nem sair as idéias suspeitosas."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Austregésilo'', 465, ''"VIVER é cultivar os valores espirituais, para superar os embaraços materiais e morais; e chegar a conclusão de que, em última análise, dado o balanço geral, a vida é boa."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''O. S. Marden'', 466, ''"Os BENS do mundo não foram feitos para um restrito número de privilegiados; mas para todos os filhos de Deus." '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Provérbio ZEN'', 467, ''"SABER e não fazer ainda não é saber."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Oscar Wilde'', 468, ''"VIVER é a coisa mais rara do mundo. A maioria das pessoas apenas existe."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Paul Klee'', 469, ''"A ARTE não reproduz o que vemos. Ela nos faz ver."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Ben Baglay'', 470, ''"A VIDA é o que acontece conosco, enquanto fazemos outros planos."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Goethe'', 471, ''"O MERITO maior do homem consiste, sem dúvida, em dominar as circunstáncias o melhor possível e deixar-se dominar por elas o menos possível."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Mário Quintana'', 472, ''"NEM todos podem estar na flor da idade, mas cada um deve estar sempre na flor da sua idade."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''M. Velandia'', 473, ''"Em CADA um de nós há um artista, um amante, um guerreiro."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Willian Arthur Ward, em Reward Yourself'', 474, ''"Um SORRISO afável é a língua universal da amabilidade." '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Farmers Digest'', 475, ''"O MAIOR dos artistas um dia foi principiante."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Ortega y Gasset'', 476, ''Surpreender-se, assombrar-se, é começar a entender."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Machado de Assis'', 477, ''"Não LEVANTES a espada sobre a cabeça de quem te pediu perdão."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''André Luiz'', 478, ''"VIVER é lei da natureza, mas a vida pessoal é obra de cada um."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Grácia C. Matos'', 479, ''"A ESPERANÇA é necessária ao coração, como o sol é existência das flores."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''A. Dumas Filho'', 480, ''"De FERRAMENTA em punho, burile sua própria vida, da melhor maneira possível."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Napoleon Hill'', 481, ''"É GRANDE vantagem ser moço, porém muito maior vantagem é ser independente, quando se chega à meia idade."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''B. Russel'', 482, ''"Uma BOA VIDA é aquela inspirada pelo amor e guiada pela inteligência."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Alba'', 483, ''"QUEM deseja reformar o mundo deve começar por si próprio."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '('' C.G. Jung, em O Desenvolvimento da Personalidade.'', 484, ''"Não DEVEMOS mudar nada nas crianças sem primeiro verificar se não somos nós que precisamos de umas mudanças." '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''George T. Fegradoe'', 485, ''"SABE daquela do mecânico de carros que foi ao psiquiatra e se deitou debaixo do divã?"  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Coelho Neto'', 486, ''"As ANGUSTIAS mais cerradas deixam sempre uma clareira iluminada por uma rústia de esperança."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''A. Dumas Filho'', 487, ''"Só GOZAM a vida os que a empregam em coisas belas."  '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Madre Teresa de Calcutá'', 497, ''"Não tente mudar uma pessoa, tente apenas entendê-la e você verá como é fácil conviver com ela."'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Mahatma Gandhi'', 498, ''"Quando entendemos as razões que levam as pessoas a terem determinados comportamentos, fica muito mais fácil  conviver com elas"'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''John Kenneth Galbraith'', 499, ''"Nada estabelece limites tão rígidos à liberdade de uma pessoa quanto a falta de dinheiro" '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Graham Nash'', 500, ''"O dinheiro que você ganha vale o preço que você paga?"'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Jim Rohn'', 501, ''"Ninguém planeja fracassar, mas fracassa por não planejar" '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Erik Wiesel'', 502, ''" O oposto da vida não é a morte, é a indiferença."'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Juvenal'', 503, ''" O castigo mais importante do culpado é nunca ser absolvido pelo tribunal de sua própria consciência."'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 504, ''"Se tu choras por ter perdido o Sol, as lágrimas o impedirão de ver as estrelas."'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Beethoven'', 505, ''" A música é uma revelação superior à filosofia."'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Marina Colasanti'', 506, ''" O amor não é louco. Sabe muito bem o que faz, e nunca age sem motivo. Loucos somos nós, que insistimos em querer entendê-lo no plano da razão." '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Thomas Huxley'', 507, ''"O degrau de uma escada não serve simplesmente para que alguém permaneça em cima dele, destina-se a sustentar o pé de um homem o tempo suficiente para que ele coloque o outro um pouco mais alto."'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Provérbio Sioux'', 508, ''Disse um velho cacique, descrevendo seus conflitos internos:-Dentro de mim existe dois cachorros, um deles é cruel , o outro é muito bom. Os dois vivem brigando!'
                        + ' Alguém pergutou a ele, então, qual dos dois ganharia a brigaO cacique pensou um pouco e respondeu-Aquele que eu alimento!'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 509, ''"Quando agente acha que sabe todas as respostas, vem a vida e muda todas as perguntas..."'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 510, ''"Se é verdade que nada é perfeito, também é verdade que tudo pode ser melhorado."'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Henry David Thoreau.'', 511, ''Seja fiel ao seu trabalho, à sua palavra, ao seu amigo.'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Mark Twain.'', 512, ''Um inimigo é capaz de arruinar parcialmente uma pessoa. as vezes é preciso um amigo desastrado para completar o serviço.'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Jacques Delille'', 513, ''O destino faz os parentes, a escolha os amigos.'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''John Evelyn.'', 514, ''A amizade é o fio de outro que liga o coração ao mundo.'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Ditado latino.'', 515, ''Censura teus amigos na intimidade e elogia-os em público.'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Sidonie G. Colette.'', 516, ''Convém tratar a amizade como os vinhos, desconfiando das misturas.'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Elbert Hubbard.'', 517, ''Amigo é a pessoa que sabe tudo sobre você e ainda assim lhe quer bem.'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Vinicius de Moraes.'', 518, ''A gente não faz amigos, reconhece-os.'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Antonio Negri.'', 519, ''A teoria não pode ajudar a ninguém - só a prática, a solidariedade concreta, a amizade e o amor estendem a mão.'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''José Arthur Giannotti.'', 520, ''O indiferente não perde amigos porque não os têm de fato.'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Carmen Sylivia.'', 521, ''O amor exige. A amizade concede.'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Paulo Francis.'', 522, ''Até paranóicos têm inimigos de verdade.'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Plauto.'', 523, ''Sua riqueza encontra-se onde estão seus amigos.'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Sérgio Buarque de Hoanda'', 524, ''A inimizade pode ser tão cordial quanto a amizade.'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Rob Lewis..'', 525, ''Se quiser ter amigos, também vai ter de respeitar o que eles gostam de fazer.'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Charles Chincholle.'', 526, ''Desconfiamos dos amigos por seus defeitos e de nossos amigos por suas virtudes.'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Confúcio.'', 527, ''O silêncio é um amigo que jamais atraiçoa.'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Nicolas-Sébastien Chamfort.'', 528, ''Para reconhecer o que é uma amizade, precisamos já ter sentido amor anteriormente.'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Milan Kundera.'', 529, ''A amizade é indispensável para o bom funcionamento da memória e a integridade do próprio eu.'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Henny Youngman.'', 530, ''Meu melhor amigo fugiu com minha mulher. Sinto muita falta dele.'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Sun Tzu'', 531, ''Não pressione um inimigo encurralado.'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Charles Chincholle.'', 532, ''Desconfiamos dos amigos por seus defeitos e de nossos inimigos por suas virtudes.'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Samuel Butler'', 533, ''Amizade é como dinheiro: mais fácil de conseguir do que de manter'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 534, ''Faça amizade com a bondade das pessoas, nunca com seus bens!'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 535, ''Não creio que na amizade entre o homem e o cachorro fosse duradoura se a carne de cachorro fosse comestível.'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 536, ''Um amigo é alguém que gosta de você, apesar dos pesares.'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Vinicius de Moraes'', 537, ''O uisque é o melhor amigo do homem, ele é o cachorro engarrafado.'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Ralph Waldo Emerson'', 538, ''A única maneira de ter amigos é ser amigo.'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 539, ''Amigo é um irmão que a gente escolhe.'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 540, ''Amigo não é aquele que enxuga suas lágrimas, e sim aquele que não as deixa cair.'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Provérbio Chinês.'', 541, ''As más companhias são como um mercado de peixes, acaba-se acostumando com o mau cheiro.'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Voltaire.'', 542, ''Deus me defende dos amigos, que dos inimigos me defendo eu.'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Pitágoras.'', 543, ''Amigos dividem todas as coisas.'', ''0'')' +
                        ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 544, ''A amizade é o porto da vida.'', ''0'')' +
                        ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 545, ''Mas vale um verdadeiro amigo virtual, do que um amigo que não conhece o verdadeiro sentido da palavra amizade.'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Madonna'', 546, ''Há uma certa tristeza existencial em cada um de nós. Você pode encontrar alguém com quem dividir sua vida ou amigos que o compreendam. Mas, no fundo, está sozinho.'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Rui Barbosa.'', 547, ''Desconfiai dos rótulos que metem, meus amigos, e habilitai-vos a contratar a mercadoria com o critério vivo do vosso bem-senso.'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Júlio Ribeiro.'', 548, ''Há aparências de dureza que ocultam tesouras de sensibilidade e de afeto.'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''François Guizot.'', 549, ''Nada é tão nocivo para os povos do que darem-se por satisfeitos com meras palavras e aparências.'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Tsai Chih Chung.'', 550, ''Não nos prendendo às aparências e seguindo nossa natureza original, não podemos agir mal.'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Churton Collins.'', 551, ''Na prosperidade nossos amigos nos conhecem, mas na adversidade somos nós que os conhecemos.'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Lacordaire.'', 552, ''Três elementos são capazes de fazer feliz a uma pessoa: DEUS, um amigo e um livro.'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 553, ''O silencio é o único amigo que jamais nos traíra.'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Xuxa-Fernando Scherer Xuxa'', 554, ''Pratiquem esporte, mesmo que não competitivamente, pois é saudável e você faz boas amizades, que duram para o resto da vida.'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Elmer G. Letterman'', 555, ''Só existe uma coisa melhor do que fazer novos amigos: conservar os velhos.'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 556, ''Um tesouro nem sempre é um amigo, mas um amigo sempre é um tesouro'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Aristoteles.'', 557, ''Uma amizade verdadeira é como uma alma em dois corpos.'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 558, ''Sempre fica a fragância na mão daquele que estende uma rosa.'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 559, ''O importante da amizade, não é conhecer o amigo e sim saber o que há dentro deles.'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Abraham Lincoln'', 560, ''Não ter amigos no governo é regra fundamental para conseguir êxito.'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 561, ''A verdadeira amizade deixa marcas positivas que o tempo jamais poderá apagar.'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 562, ''Um livro aberto, é um cérebro que fala. fechado, um amigo que espera. esquecido, uma alma que perdoa. destruido, um coração que chora.'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 563, ''O medo faz com que a gente perca muitas coisas, até quem amamos.'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 564, ''Mais vale uma amizade sincera, do que um amor fingido.'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Jane Austen'', 565, ''Não quero que as pessoas sejam muito agradáveis comigo, assim me poupam o trabalho de ter que gostar muito delas.'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 566, ''Antes de tentar conhecer alguém, conheça a si mesmo, só se entende as diferenças quando se vê nelas.'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Antonio Porchia'', 567, ''A verdade tem poucos amigos e estes poucos são suicidas.'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Groucho Marx'', 568, ''Fora o cachorro, o livro é o melhor amigo do homem. Dentro do cachorro é muito escuro para ler.'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Salvador Dalí'', 569, ''Como posso querer que meus amigos entendam as coisas loucas que passam pela minha cabeça, se eu mesmo, não entendo?'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Caetano Veloso'', 570, ''Então tá combinado, é quase nada, é tudo somente sexo e amizade.'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Confúcio'', 571, ''O silêncio é um amigo que nunca trai.'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 572, ''A amizade duplica as alegrias e divide as tristezas.'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''William Blake.'', 573, ''Não revele aos amigos os seus segredos, porque você não sabe se algum se tornará seu inimigo. Não cause ao seu inimigo todo o mal que lhe possa fazer, porque você não sabe se ele se tornará um dia seu amigo.'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 574, ''Amigo é aquele que conhece todos os seus segredos e mesmo assim gosta de você !'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Érico Veríssimo'', 575, ''Felicidade é a certeza de que a nossa vida não está se passando inutilmente.'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''F. Alberoni'', 576, ''Amigo é aquele que, a cada vez, nos faz entrever a meta e que percorre conosco um trecho do caminho'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 577, ''Amigo sincero é aquele que mostra seus erros e ajuda a vencê-los. Não aquele que os esconde somente para satisfazê-lo permitindo que você viva em mundo de mentiras.'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 578, ''Quando  te vi não sei o que pensei... Olhando nos teus olhos uma amizade ...conquistei.'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 579, ''A amizade quando é sincera ....o esquecimento é impossível'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Zélia Gattai'', 580, ''Continuo achando graça nas coisas, gostando cada vez mais das pessoas, curiosa sobre tudo, imune ao vinagre, às amarguras, aos rancores.'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 581, ''...e como não existem lojas de amigos, os homens não têm mais amigos'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 582, ''Nunca se iluda por um Beijo pois foi através dele que Jesus foi traído...'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 583, ''Vida longa a seus inimigos para que possam ver a sua vitória.'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''La Bruyére'', 584, ''Não se pode ir longe na amizade sem se dispor a perdoar as pequenas faltas um do outro.'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 585, ''Se veres algum dia uma escuridão em seu caminho é por que existem luzes que não foram acessas... uma delas pode ser a fé, o amor, e a paixão!!!'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 586, ''Nunca tente ser igual a todo mundo, pois ser igual a todo mundo é fácil, difícil é ser original !!!'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 587, ''A esperança é um empréstimo pedido à felicidade.'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 588, ''Nenhum caminho é longo demais quando um amigo nos acompanha.'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 589, ''Nunca se explique. Seus amigos não precisam, e seus inimigos não vão acreditar.'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 590, ''Amigo não é aquele que diz vá em frente mas aquele que diz vou contigo'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 591, ''Amigos são como flores cada um tem o seu encanto por isso cultive-os.'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 592, ''Celebrar a vida é somar amigos, experiências e conquistas, dando-lhes sempre algum significado.'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 593, ''A glória da amizade não é a mão estendida, nem o sorriso carinhoso, nem mesmo a delicia da companhia. É a inspiração espiritual que vem quando você descobre que alguém acredita e confia em você.'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 594, ''A glória da amizade não é a mão estendida, nem o sorriso carinhoso, nem mesmo a delicia da companhia. É a inspiração espiritual que vem quando você descobre que alguém acredita e confia em você.'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 595, ''A amizade é um amor que nunca morre.'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''La Bruyére'', 596, ''Não poderemos ir longe na amizade se não estivermos dispostos a perdoar os pequenos defeitos dos amigos.'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 597, ''O que é um amigo? Uma única alma habitando dois corpos.'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 598, ''Só existe uma coisa melhor do que fazer novos amigos: conservar os velhos.'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 599, ''Sorria mesmo que seja um sorriso triste, porque mais triste que um sorriso triste é a tristeza de não saber sorrir.'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 600, ''Não seja como o lago que se satisfaz com seus limites, seja como o oceano que está sempre em busca de novos horizontes!'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 601, ''Amigo é aquele que nos faz sentir melhor e sobre tudo nos faz sentir amados.'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 602, ''Amigo de verdade é aquele que transforma um pequeno momento em um grande instante.'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 603, ''O medo faz com que a gente perca muitas coisas, até quem amamos.'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 604, ''Não abra mão das alegrias para acabar com as tristezas.'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 605, ''Amigo não é aquele que diz vá em frente, e sim vou contigo.'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Urteaga'', 606, ''Desabafa o teu coração com quem conhece a tua alma. Sê sincero, ainda que nesses momentos de intensa dor o falar te custe sangue.'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 607, ''Só recorre aos gritos, quem não conseguiu vencer com a razão.'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 608, ''A infelicidade tem isto de bom: faz-nos conhecer os verdadeiros amigos.'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 609, ''Que a amizade tome conta de tudo aquilo em que acreditamos, incorporando o sonho de descobrir em cada pessoa que a gente gosta, uma outra metade da gente mesmo.'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 610, ''O verdadeiro amigo não é aquele que só apoia sem discordar e sim aquele que aconselha mas nem sempre concorda.'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 611, ''Os piores amigos são aqueles que aplaudem sempre.'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 612, ''Cuidado com os pensamentos, pois eles são o ponto de partida para as nossas ações !'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 613, ''O importante da amizade, não é conhecer o amigo e sim saber o que há dentro deles.'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 614, ''A verdadeira amizade é aquela que não pede nada em troca, a não ser a própria amiga.'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 615, ''A verdadeira generosidade é fazer alguma coisa de bom por alguém que nunca vai descobrir.'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 616, ''A amizade duplica as alegrias e divide as tristezas.'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 617, ''Quem tem um amigo, mesmo que um só, não importa onde se encontre, jamais sofrerá de solidão, poderá morrer de saudades, mas não estará só.'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 618, ''Mais vale uma amizade sincera, do que um amor fingido.'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 619, ''O amigo não é aquele que nos faz algum bem, mas aquele que está sempre e em toda parte junto conosco.'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 620, ''Amizade é como música: duas cordas afinadas no mesmo tom, vibram juntas.'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 621, ''Um amigo é um outro nós.'', ''0'')' +
                        ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 622, ''Substituir o amor proprio pelo amor dos demais é trocar um tirano sofredor por um bom amigo.'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Marquês de Maricá.'', 623, ''Uma boa leitura dispensa com vantagem a companhia de pessoas frívolas.'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 624, ''Vale mais um inimigo sábio que um amigo ignorante.'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Oscar Wilde'', 625, ''A cada bela impressão que causamos, conquistamos um inimigo. Para ser popular é indispensável ser medíocre.'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Elbert Hubbard.'', 626, ''Um amigo é alguém que gosta de ti, apesar de teus sucessos.'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Ed Cunningham.'', 627, ''Amigos são aquelas raras pessoas que nos perguntam como estamos e que depois ficam à espera de ouvir a resposta.'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 628, ''Gastamos mais tempo falando de nossos inimigos do que elogiando nosso amigos.'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 629, ''Não fique em campo aberto quando o inimigo está oculto Provérbio Chinês.'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 630, ''El falso amigo es como la sombra que nos sigue mientras dura el sol.'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Jean Rostand.'', 631, ''Um amigo é a pessoa a quem mais se dá crédito quando fala mal de nós.'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 632, ''Amigo sincero é aquele que mostra seus erros e ajuda a vencê-los.Não aquele que os esconde somente para satifazê-lo permitindo que você viva em mundo de mentiras.'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Proverbio mongol'', 633, ''O vitorioso tem muitos amigos, mas o vencido tem bons amigos.'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Pv 29: 5'', 634, ''Quem bajula os seus amigos está armando uma armadilha para si mesmo.'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Platão.'', 635, ''Não deixes crescer a intriga no caminho da amizade.'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Provérbio Africano.'', 636, ''A amizade é um caminho que desaprece na areia , se não se pisa constantemente nele.'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Malba Tahan.'', 637, ''Se os meus amigos fugirem de mim, fugirão todos os tesouros.'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 638, ''Deus nos deu a lingua para que pudessemos dizer coisa amaveis a nossos amigos e duras verdades a nossos inimigos Heine'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Jean Cocteau.'', 639, ''O homem sozinho está sempre mal acompanhado.'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 640, ''Perdôo meus inimigos. Por eles sou perdoado. E não tenho mais inimigos na Terra.'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Machado de Assis.'', 641, ''Não é amigo aquele que alardeia a amizade: é traficante. a amizade sente-se, não se diz.'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 642, ''Elogie os amigos em público, critique em particular.'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Castro Alves'', 643, ''Ai! Que vale a vingança, pobre amigo.Se na vingança, a honra não se lava?'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 644, ''As pessoas entram em nossas vidas por acaso, mas não é por acaso que elas permanecem.'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Betinho'', 645, ''Não afirmo que o inimigo do Brasil é o capital estrangeiro, mas também não afirmo que por ser estrangeiro é melhor e mais amigo.'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 646, ''Diante de um obstáculo não cruzes os braços, pois o maior homem do mundo morreu de braços abertos.'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Kennedy'', 647, ''Cidadãos do mundo, meus amigos: não perguntem o que a América fará por vocês, mas o que juntos poderemos fazer pela liberdade do homem.'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 648, ''Muitas vezes o que jugamos não existir é o que há de mais verdadeiro.'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 649, ''Amigo não é aquele que chora na despedida e sim aquele que nunca diz adeus !'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 650, ''Amigo, não é aquele que te faz sorrir com as mentiras, mais sim aqueles que te faz chorar com as verdades!'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 651, ''Vale mais um inimigo sábio que um amigo ignorante.'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 652, ''Amigos são os que nas prosperidades aparecem se receberem convite, e nas adversidades aparecem sem serem chamados.'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 653, ''Um amigo é um presente que você dá a você mesmo.'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''George Herbet'', 654, ''O melhor espelho é um velho amigo .'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Francisco Cândido Xavier'', 655, ''Pensa nas ocasiões em que corações amigos te haverão desculpado as próprias faltas.'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 656, ''Nunca lamente uma ilusão perdida, pois não haveria fruto se a flor não caisse.'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Proverbio Portugues.'', 657, ''Se a força faz vencedores, a concordia há invencíveis.'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 658, ''A amizade aumenta a felicidade e reduz o infortunio, multiplicando a nossa alegria e dividindo a nossa dor.'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 659, ''O verdadeiro amigo é aquele que vem quando o resto do mundo está indo embora.'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Friedrich Nietzsche.'', 660, ''Haverá algum homem que não se sentirá terrivelmente ferido se vier a saber o que os seus mais fiéis amigos pensam dele no seu íntimo?'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 661, ''Nosso amor é como chuva fina que cai suave mas transborda o rio.'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 662, ''Puxando os outros para o alto, você irá se sentir em boa companhia e isso faz parte do universo da perfeição.'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Carlos Drummond de Andrade.'', 663, ''Certas amizades comprometem a idéia de amizade.'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 664, ''Não contabilize o que perdeu mas sim o que ficou.'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 665, ''Quem quiser colher rosas deve suportar os espinhos.'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Gore Vidal'', 666, ''Sempre que um amigo meu faz sucesso, alguma coisinha dentro de mim morre.'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 667, ''A amizade é um bem ao alcance de todos.Saiba investir nas pessoas à sua volta.Os amigos valem mais do que verdadeiras preciosidades'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Pv 24: 1,2'', 668, ''Não tenha inveja dos maus e nem procure ter amizade com eles. Só pensam em violências, e, quando falam, é para ferir alguém.'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Walter Winchell.'', 669, ''O verdadeiro amigo é aquele que vem quando o resto do mundo está indo embora.'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Joubert'', 670, ''É preciso ter sempre em nosso coração um canto aberto e livre para dar lugar às opiniões de nossos amigos.'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Martin Luther King.'', 671, ''Aprendemos a voar como pássaros e a nadar como peixes, mas não aprendermos a conviver como irmãos.'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Joseph Addison.'', 672, ''A amizade aumenta a felicidade e reduz o infortúnio multiplicando a nossa alegria e dividindo a nossa dor.'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Rui Barbosa.'', 673, ''Não poucas vezes, razão é lastimar o zelo dos amigos e agradecer a malevolência dos opositores. Estes nos salvam, quando aqueles nos extraviam.'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Provérbio Escocês.'', 674, ''Sua ausência é boa companhia.'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 675, ''Errar é humano, botar a culpa no computador é mais humano ainda.'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Lei de Murphy.'', 676, ''Quando se arquiva direito um papel, ele nunca será necessário.'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 677, ''Abençoados sejam os pessimistas, eles fizeram backups.'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Bill Clinton.'', 678, ''Informática e Telecomunicações serão para o século 21 o que rodovias e ferrovias foram para o século 20.'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Charles Chaplin.'', 679, ''Não sois máquinas!Homens é o que sois!'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''George Orwell.'', 680, ''O progresso é uma ilusão. Ele acontece, mas de forma lenta e , invariavelmente, termina nos desapontando.'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Erich Fromm.'', 681, ''O mal do passado foi os homens se tornarem escravos. O perigo do futuro é que eles se tornem robôs.'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Pedro Almodavar.'', 682, ''Hoje tudo vai contra a comunicação entre seres humanos. Sou a favor da tecnologia, mas devemos humanizá-la.'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Bill Gates.'', 683, ''Em informática, quando você percebe que tem problemas, já é tarde para escapar deles. Se não se mantiver aberto, você já era.'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Pablo Ruiz Picasso.'', 684, ''Computadores não prestam para nada. Eles só podem lhe dar respostas.'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Alberto Santos Dumont.'', 685, ''Como tudo, os inventos humanso, se têm vantagens, têm também seus inconvenientes.'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Frederick Skinner.'', 686, ''A verdadeira questão não é se a máquina pensa, mas se os homens pensam.'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Fernando Pessoa'', 687, ''"O valor das coisas não esta no tempo que elas duram, mas na itensidade com que acontece. Por isso existem momentos inesquecíveis, coisas inesplicáveis e pessoas incomparáveis"'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''GABRIEL GARCÍA MÁRQUEZ'', 688, ''"Quero-te não por quem és, mas por quem sou quando estou contigo."'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''GABRIEL GARCÍA MÁRQUEZ'', 689, ''"Ninguém merece as tuas lágrimas , e quem as merecer não te fará chorar."'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''GABRIEL GARCÍA MÁRQUEZ'', 690, ''"Só porque alguém não te ama como tu queres, não significa que não te ame com toda a sua alma."'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''GABRIEL GARCÍA MÁRQUEZ'', 691, ''"Um verdadeiro amigo é aquele que pega na tua mão e te toca o coração."'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''GABRIEL GARCÍA MÁRQUEZ'', 692, ''"A pior forma de se sentir a falta de uma pessoa é estar sentada ao seu lado e saber que nunca a vais poder ter."'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''GABRIEL GARCÍA MÁRQUEZ'', 693, ''"Nunca deixes de sorrir, nem sequer quando estás triste porque nunca sabes quem se poderá apaixonar pelo teu sorriso."'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''GABRIEL GARCÍA MÁRQUEZ'', 694, ''"Podes ser simplesmente uma pessoa para o mundo, mas para alguém o mundo és tu."'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''GABRIEL GARCÍA MÁRQUEZ'', 695, ''"Não passes o tempo com alguém que não esteja disposto a passá-lo contigo."'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''GABRIEL GARCÍA MÁRQUEZ'', 696, ''"Quem sabe Deus quer que conheças muita gente errada antes de conheceres a pessoa certa, para que quando a finalmente conheceres, saibas estar agradecido."'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''GABRIEL GARCÍA MÁRQUEZ'', 697, ''"Não chores porque acabou, sorri porque aconteceu."'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''GABRIEL GARCÍA MÁRQUEZ'', 698, ''"Haverá sempre quem te desiluda, assim o que tens de fazer é seguir confiando e só ser mais  cuidadoso em quem confias duas vezes."'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''GABRIEL GARCÍA MÁRQUEZ'', 699, ''"Não te esforces tanto, as melhores coisas acontecem quando menos as esperas."'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''GABRIEL GARCÍA MÁRQUEZ'', 700, ''"Tudo o que acontece, acontece por alguma razão."'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Thiago de Melo'', 701, ''"Não há caminho novo. O que há de novo é o jeito de caminhar"'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Bial'', 702, ''"Saúde e paz, o resto agente corre atraz"'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 703, ''"A vida é uma peça de teatro que não permite ensaios. Por isso, cante, chore, dance, ria e viva intensamente, antes que a cortina se feche e a peça termine sem aplausos"'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 704, ''"Covarde não é aquele que chora por um amor, mas é aquele que não ama por ter medo de chorar."'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''San Kenn'', 705, ''"Passamos a amar não quando encontramos uma pessoa perfeita, mas quando aprendemos a ver perfeitamente uma pesso imperfeita."'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Desconhecido'', 706, ''"O amor pergunta à amizade: -Mas para que é que tu serves? E a amizade responde: -Sirvo para limpar as lágrimas que tu deixas cair" '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''William Somerset Maugham'', 707, ''"A cada minuto que passamos com raiva, perdemos sessenta felizes segundos."'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Elmer G. Letterman'', 708, '' "Só existe uma coisa melhor do que fazer novos amigos: conservar os velhos." '', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Bob Marley'', 709, ''"Às vezes construímos pequenos sonhos em cima de grandes pessoas... O tempo passa e descobrimos que grandes eram os sonhos, e as pessoas pequenas demais para torná-los reais."'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''Dalai Lama'', 710, ''"Só existe dois dias em que nada pode ser feito. Um se chama ontem e o outro amanhã. Feliz Hoje"'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''João 8:32'', 711, ''"E conhecereis a verdade, e a verdade vos libertará."'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''João 6:35'', 712, ''"E Jesus lhes disse: Eu sou o pão da vida; aquele que vem a mim não terá fome, e quem crê em mim nunca terá sede."'', ''0'')'
                        + ' MATCHING (CDDITADO);');
                      ExecSQL;
                      Sql.Clear;
                      Sql.Add('UPDATE OR INSERT INTO MENSAGEM (NMAUTOR, CDDITADO, DCDITADO, FLEXIBIDO) VALUES '
                        + '(''João 6:39'', 713, ''"E a vontade do Pai que me enviou é esta: Que nenhum de todos aqueles que me deu se perca, mas que o ressuscite no último dia".'', ''0'')'
                        + ' MATCHING (CDDITADO);');;
                      ExecSQL;



              end;

            {$ENDREGION}

            {$REGION ' EXIBE A PRÓXIMA MENSAGEM '}

                  Close;
                  Sql.Clear;
                  Sql.Add(' SELECT * FROM MENSAGEM WHERE FLEXIBIDO=''0'';');
                  Open;
                  if RecordCount = 0 then
                  begin
                    Close;
                    Sql.Clear;
                    Sql.Add(' UPDATE MENSAGEM SET FLEXIBIDO = ''0'' WHERE FLEXIBIDO = ''1''; ');
                    ExecSQL;
                    Close;
                    Sql.Clear;
                    Sql.Add(' SELECT * FROM MENSAGEM WHERE FLEXIBIDO=''0'';');
                    Open;
                  end;
                  First;
                  Msg := Fields[2].AsString;
                  AUTOR := 'Autor: ' + Fields[0].AsString;
                  Edit;
                  Fields[3].AsString := '1';
                  Post;
                  Result := True;

            {$ENDREGION}

          end;

        end;

      end;

      function TWKConnectionClass.MD5String(const Value: string): string;
      var
        xMD5: TIdHashMessageDigest5;
      begin
        xMD5 := TIdHashMessageDigest5.Create;
        try
          Result := xMD5.HashStringAsHex(Value);
        finally
          xMD5.Free;
        end;
      end;

      function TWKConnectionClass.MD5Arquivo(const Value: string): string;
      var
        xMD5: TIdHashMessageDigest5;
        xArquivo: TFileStream;
      begin
        xMD5 := TIdHashMessageDigest5.Create;
        xArquivo := TFileStream.Create(Value, fmOpenRead OR fmShareDenyWrite);
        try
          Result := xMD5.HashStreamAsHex(xArquivo);
        finally
          xArquivo.Free;
          xMD5.Free;
        end;
      end;

      function TWKConnectionClass.GetBiosCheckSum: string;
      var
        S: Int64;
        i: longword;
        p: PChar;
      begin
        i := 0;
        S := 0;
        p := PChar($F0000);
        repeat
          inc(S, ord(^p) shl i);
          if i < 64 then
            inc(i)
          else
            i := 0;
          inc(p);
        until p > PChar($FFFFF);
        Result := IntToHex(S, 16);
      end;

      function TWKConnectionClass.GetMotherBoardCheckSum: string;
      var
        a, b, c, d: longword;
        CPUID: string;
      begin
        asm
          push EAX
          push EBX
          push ECX
          push EDX
          mov eax, 1
          db $0F, $A2
          mov a, EAX
          mov b, EBX
          mov c, ECX
          mov d, EDX
          pop EDX
          pop ECX
          pop EBX
          pop EAX
        end;
        CPUID := IntToHex(a, 8) + '-' + IntToHex(c, 8) + '-' + IntToHex(d, 8);
        Result := CPUID;
      end;

      function TWKConnectionClass.SerialValidacaoSistema: String;
      Var
        MD5: String;
      begin
        MD5 := GetBiosCheckSum + GetMotherBoardCheckSum;
        Result := MD5String(MD5);
      end;

      function TWKConnectionClass.GenerateUUID: string;
      var
        GUID: TGUID;
      begin
        // Cria um novo GUID
        CreateGUID(GUID);

        // Converte o GUID para uma string e remove as chaves {}
        Result := StringReplace(GUIDToString(GUID), '{', '', [rfReplaceAll]);
        Result := StringReplace(Result, '}', '', [rfReplaceAll]);
      end;

      function TWKConnectionClass.FormatarDocumento(const Documento: string): string;
      begin

        case Length(Documento) of

          11: // Formatar como CPF
            Result := Copy(Documento, 1, 3) + '.' + Copy(Documento, 4, 3) + '.' +
                      Copy(Documento, 7, 3) + '-' + Copy(Documento, 10, 2);

          14: // Formatar como CNPJ
            Result := Copy(Documento, 1, 2) + '.' + Copy(Documento, 3, 3) + '.' +
                      Copy(Documento, 6, 3) + '/' + Copy(Documento, 9, 4) + '-' +
                      Copy(Documento, 13, 2);
        else

          Result := 'CPF/CNPJ Não Informado';

        end;

      end;

      function TWKConnectionClass.Crypt(aAcao: TActionCrypto; aFonte, aKey: string): string;
      var
        Dest: string;
        Range: Integer;
        KeyLen: Integer;
        KeyPos: Integer;
        OffSet: Integer;
        SrcPos: Integer;
        SrcAsc: Integer;
        TmpSrcAsc: Integer;
      begin
        Result := '';
        if (aFonte = '') then
          Exit;
        try
          Dest := '';
          KeyLen := Length(aKey);
          KeyPos := 0;
          SrcPos := 0;
          SrcAsc := 0;
          Range := 256;
          case aAcao of
            crEncriptar:
              begin
                Randomize;
                OffSet := Random(Range);
                Dest := Format('%1.2x', [OffSet]);
                for SrcPos := 1 to Length(aFonte) do
                begin
                  SrcAsc := (Ord(aFonte[SrcPos]) + OffSet) mod 255;
                  if KeyPos < KeyLen then
                    KeyPos := KeyPos + 1
                  else
                    KeyPos := 1;
                  SrcAsc := SrcAsc xor Ord(aKey[KeyPos]);
                  Dest := Dest + Format('%1.2x', [SrcAsc]);
                  OffSet := SrcAsc;
                end;
              end;
            crDecriptar:
              begin
                OffSet := StrToInt('$' + copy(aFonte, 1, 2));
                SrcPos := 3;
                repeat
                  SrcAsc := StrToInt('$' + copy(aFonte, SrcPos, 2));
                  if (KeyPos < KeyLen) then
                    KeyPos := KeyPos + 1
                  else
                    KeyPos := 1;
                  TmpSrcAsc := SrcAsc xor Ord(aKey[KeyPos]);
                  if TmpSrcAsc <= OffSet then
                    TmpSrcAsc := 255 + TmpSrcAsc - OffSet
                  else
                    TmpSrcAsc := TmpSrcAsc - OffSet;
                  Dest := Dest + Chr(TmpSrcAsc);
                  OffSet := SrcAsc;
                  SrcPos := SrcPos + 2;
                until (SrcPos >= Length(aFonte));
              end;
          end;
          Result := Dest;
        except
        end;
      end;

      function TWKConnectionClass.Connect(Conn, Transact, Driver: TObject) : Boolean;
        procedure CleanConnection(Conn: TObject);
        begin

          if (Conn.ClassType = TFDConnection) then
          begin
            with (Conn as TFDConnection) do
            begin

              Close;
              Params.Clear;

            end;
          end;

          if (Conn.ClassType = TIBDatabase) then
          begin
            with (Conn as TIBDatabase) do
            begin

              CloseDataSets;
              Close;
              Params.Clear;

            end;
          end;

          if (Conn.ClassType = TUniConnection) then
          begin
            with (Conn as TUniConnection) do
            begin
              Close;
              ProviderName := 'InterBase';
              Server       := '127.0.0.1';
              Database     := 'database';
              Username     := 'username';
              Password     := 'password';
              Port         := 3050;
              SpecificOptions.Values['ClientLibrary'] := '.\fbclient.dll';
              SpecificOptions.Values['Protocol']      := 'TCP';
              LoginPrompt  := False;


              SpecificOptions.Clear;
              Server          := EmptyStr;
              Port            := 0;
              UserName        := EmptyStr;
              Password        := EmptyStr;
              Database        := EmptyStr;
              SpecificOptions.Add('Protocol=TCP');
              SpecificOptions.Add('ClientLibrary=.\fbclient.dll');

            end;
          end;

        end;
      begin

        Result := True;

        try

          if (Conn.ClassType = TFDConnection) then
          begin

            CleanConnection(Conn as TFDConnection);

            with (Conn as TFDConnection) do
            begin

              Params.Add('Database='      +  FParamsOptions.MAINDB);
              Params.Add('Server='        +  FParamsOptions.SERVER);
              Params.Add('Port='          +  FParamsOptions.PORT);
              Params.Add('User_Name='     +  Crypt(crDecriptar, FParamsOptions.LOGINDB, kCh));
              Params.Add('password='      +  Crypt(crDecriptar, FParamsOptions.PASSWDDB, kCh));
              Params.Add('Protocol='      +  FParamsOptions.PROTOCOL);
              Params.Add('CharacterSet='  +  FParamsOptions.CHARSET);
              Params.Add('OSAuthent=No');
              Params.Add('DriverID=FB');
              Params.Add('CharacterSet=ISO8859_1');
              Params.Add('Protocol=TCPIP');
              Transaction := (Transact as TFDTransaction);

              (Driver as TFDPhysFBDriverLink).VendorLib  := FParamsOptions.LIBCON;

            end;

            FFConn := (Conn as TFDConnection);

          end;


          if (Conn.ClassType = TIBDatabase) then
          begin

            CleanConnection(Conn as TIBDatabase);

            with (Transact as TIBTransaction) do
            begin
              Active := False;
              Params.Clear;
              Params.Add('read_committed');
              Params.Add('rec_version');
              Params.Add('nowait');
            end;

            with (Conn as TIBDatabase) do
            begin

              CloseDataSets;
              Close;
              Params.Clear;
              Params.Values['user_name'] := Crypt(crDecriptar, FParamsOptions.LOGINDB, kCh);
              Params.Values['password']  := Crypt(crDecriptar, FParamsOptions.PASSWDDB, kCh);
              Params.Values['lc_ctype']  := FParamsOptions.CHARSET;
              DefaultTransaction         := (Transact as TIBTransaction);
              LoginPrompt                := False;
              DatabaseName               := FParamsOptions.SERVER  + '/' +  FParamsOptions.PORT + ':' + FParamsOptions.MAINDB;

            end;

            FFConn := (Conn as TIBDatabase);
          end;

          if (Conn.ClassType = TUniConnection) then
          begin

            if ((Conn as TUniConnection).SpecificOptions = nil) then
              (Conn as TUniConnection).SpecificOptions := TSpecificOptionsList.Create(nil,nil);

            CleanConnection(Conn as TUniConnection);

            with (Conn as TUniConnection) do
            begin

              ProviderName    := 'InterBase';
              Server          := FParamsOptions.SERVER;
              Database        := FParamsOptions.MAINDB;
              UserName        := Crypt(crDecriptar, FParamsOptions.LOGINDB, kCh);
              Password        := Crypt(crDecriptar, FParamsOptions.PASSWDDB, kCh);

              try
                Port            := FParamsOptions.PORT.ToInteger;
              except
                Port            := 3050;
              end;

              SpecificOptions.Values['ClientLibrary'] := FParamsOptions.LIBCON;

              try
                SpecificOptions.Values['Protocol']      := FParamsOptions.PROTOCOL;
              except
                SpecificOptions.Values['Protocol']      := 'TCP';
              end;

              SpecificOptions.Values['Charset']       := FParamsOptions.CHARSET;
              LoginPrompt     := False;
              DefaultTransaction := (Transact as TUniTransaction);

            end;

            FFConn := (Conn as TUniConnection);

          end;

        except

          on E:Exception do
          begin
            Result := False;
            raise Exception.Create(E.Message);
          end;

        end;

      end;

      function TWKConnectionClass.WRInRegedit(ValueName, Information, AccessType, SubKey: Variant; ValueType: Integer):Variant;
      var
      REG     : TRegistry;
      begin

          {$REGION ' MODO DE USAR '}

            {

                          WRInRegedit(
                                      ValueName, //Nome da Key Value que vai receber o dado
                                      Information, //Dado que será armazenado na Key ValueName
                                      'W',    // Condição Leitura = R Escrita = W
                                      SubKey,  // Chave e ou Sub-chave que irá armazenar as informações
                                      0=String
                                      1=Inteiro
                                      2=Float
                                      3=Boleano
                                      4=Date
                                      5=DateTime
                                      6=Time
                                      7=ExpandString
                                      8=Currency
                                      uma das opções entre 0 e 8
                                     );
             }


          {$ENDREGION}

          Result      := EmptyStr;
          REG         := TRegistry.Create;

          try

            if (AccessType='R') then
            begin

              REG.Access  := KEY_READ;
              REG.RootKey := HKEY_CURRENT_USER;
              REG.OpenkeyReadOnly(SubKey);

              if not(REG.ValueExists(ValueName)) then
              begin

               if (ValueType=1) then
                Result := 0
               else
                Result := EmptyStr;

               Exit;

              end;

              case ValueType of

                0: Result := REG.ReadString(ValueName);
                1: Result := REG.ReadInteger(ValueName);
                2: Result := REG.ReadFloat(ValueName);
                3: Result := REG.ReadBool(ValueName);
                4: Result := REG.ReadDate(ValueName);
                5: Result := REG.ReadDateTime(ValueName);
                6: Result := REG.ReadTime(ValueName);
                7: Result := REG.ReadString(ValueName);
                8: Result := REG.ReadCurrency(ValueName);

              end;

              REG.closekey;
            end;

            if (AccessType='W') then
            begin
              REG.Access  := KEY_WRITE;
              REG.RootKey := HKEY_CURRENT_USER;
              REG.OpenKey(SubKey, True);
              case ValueType of
                0: REG.WriteString(ValueName, Information);
                1: REG.WriteInteger(ValueName, Information);
                2: REG.WriteFloat(ValueName, Information);
                3: REG.WriteBool(ValueName, Information);
                4: REG.WriteDate(ValueName, Information);
                5: REG.WriteDateTime(ValueName, Information);
                6: REG.WriteTime(ValueName, Information);
                7: REG.WriteExpandString(ValueName, Information);
                8: REG.WriteCurrency(ValueName, Information);
              end;
            end;

          finally
           REG.Free;
          end;

      end;

      function TWKConnectionClass.GetBuildInfo(Prog: string): string;
      var
        VerInfoSize   : DWord;
        VerInfo       : Pointer;
        VerValueSize  : DWord;
        VerValue      : PVSFixedFileInfo;
        Dummy         : DWord;
        V1, V2, V3, V4: word;
      begin
        try
          VerInfoSize := GetFileVersionInfoSize(PChar(Prog), Dummy);
          GetMem(VerInfo, VerInfoSize);
          GetFileVersionInfo(PChar(Prog), 0, VerInfoSize, VerInfo);
          VerQueryValue(VerInfo, '', Pointer(VerValue), VerValueSize);
          with (VerValue^) do
          begin
            V1 := dwFileVersionMS shr 16;
            V2 := dwFileVersionMS and $FFFF;
            V3 := dwFileVersionLS shr 16;
            V4 := dwFileVersionLS and $FFFF;
          end;
          FreeMem(VerInfo, VerInfoSize);
          Result := Format('%d.%d.%d.%d', [V1, V2, V3, V4]);
        except
          Result := '1.0.0';
        end;
      end;

      function TWKConnectionClass.ShellExecuteAndWait(Operation, FileName, Parameter, Directory: String; Show: Word; bWait: Boolean): Longint;
      var
        bOK: Boolean;
        Info: TShellExecuteInfo;
      begin
        FillChar(Info, SizeOf(Info), Chr(0));
        Info.cbSize := SizeOf(Info);
        Info.fMask := SEE_MASK_NOCLOSEPROCESS;
        Info.lpVerb := PChar(Operation);
        Info.lpFile := PChar(FileName);
        Info.lpParameters := PChar(Parameter);
        Info.lpDirectory := PChar(Directory);
        Info.nShow := Show;
        bOK := Boolean(ShellExecuteEx(@Info));
        if bOK then
        begin
          if bWait then
          begin
            while WaitForSingleObject(Info.hProcess, 100) = WAIT_TIMEOUT do
              Application.ProcessMessages;
            bOK := GetExitCodeProcess(Info.hProcess, DWORD(Result));
          end
          else
            Result := 0;
        end;
        if not bOK then
          Result := -1;
      end;

      function TWKConnectionClass.GetComputer:string;
      begin
        Result := GetEnvironmentVariable('COMPUTERNAME');
      end;

      procedure TWKConnectionClass.ForceEndApplication(SourceApplication: String);
        function KillTask(ExeFileName : String): Integer;
        const
          PROCESS_TERMINATE = $0001;
        var
          ContinueLoop    : BOOL;
          FSnapshotHandle : THandle;
          FProcessEntry32 : TProcessEntry32;
        begin
          Result := 0;
          try

            FSnapshotHandle        := CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
            FProcessEntry32.dwSize := SizeOf(FProcessEntry32);
            ContinueLoop           := Process32First(FSnapshotHandle, FProcessEntry32);

            while Integer(ContinueLoop) <> 0 do
            begin
              if ((UpperCase(ExtractFileName(FProcessEntry32.szExeFile)) = UpperCase(ExeFileName)) or
                (UpperCase(FProcessEntry32.szExeFile) = UpperCase(ExeFileName))) then
                Result := Integer(TerminateProcess(
                                  OpenProcess(PROCESS_TERMINATE,
                                              BOOL(0),
                                              FProcessEntry32.th32ProcessID),
                                              0));
               ContinueLoop := Process32Next(FSnapshotHandle, FProcessEntry32);
            end;

            CloseHandle(FSnapshotHandle);
          except
          end;
        end;
      var
        aProcesso : string;
      begin
        //SourceApplication.Terminate;
        aProcesso := SourceApplication;
        aProcesso := StringReplace(aProcesso, ExtractFilePath(aProcesso), '', [rfReplaceAll]);
        KillTask(aProcesso);
      end;

      procedure TWKConnectionClass.ForceEndApplication;
        function KillTask(ExeFileName : String): Integer;
        const
          PROCESS_TERMINATE = $0001;
        var
          ContinueLoop    : BOOL;
          FSnapshotHandle : THandle;
          FProcessEntry32 : TProcessEntry32;
        begin
          Result := 0;
          try

            FSnapshotHandle        := CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
            FProcessEntry32.dwSize := SizeOf(FProcessEntry32);
            ContinueLoop           := Process32First(FSnapshotHandle, FProcessEntry32);

            while Integer(ContinueLoop) <> 0 do
            begin
              if ((UpperCase(ExtractFileName(FProcessEntry32.szExeFile)) = UpperCase(ExeFileName)) or
                (UpperCase(FProcessEntry32.szExeFile) = UpperCase(ExeFileName))) then
                Result := Integer(TerminateProcess(
                                  OpenProcess(PROCESS_TERMINATE,
                                              BOOL(0),
                                              FProcessEntry32.th32ProcessID),
                                              0));
               ContinueLoop := Process32Next(FSnapshotHandle, FProcessEntry32);
            end;

            CloseHandle(FSnapshotHandle);
          except
          end;
        end;
      var aProcesso : string;
      begin
        Application.Terminate;
        aProcesso := ParamStr(0);
        aProcesso := StringReplace(aProcesso, ExtractFilePath(aProcesso), '', [rfReplaceAll]);
        KillTask(aProcesso);
      end;

      Procedure TWKConnectionClass.RunConfiguraDB;
      begin
        try
          Application.CreateForm(TFrmConfiguraDB, frmConfiguraDB);
          frmConfiguraDB.ShowModal;
        finally
          FreeAndnil(frmConfiguraDB);
        end;
      end;

      procedure TWKConnectionClass.RunDBConfig;
      var
        ExeFile, Company: string;
      begin

        if not(FParamsOptions.COMPANY.IsEmpty) then
          Company := '-E' + FParamsOptions.COMPANY
        else
          Company := EmptyStr;

        AlertMsgDlg(
                    ' Não foi possivel conectar no Banco de Dados!' + sLineBreak +
                    ' Tente novamente, se o erro persistir entre em contato com o Suporte.' + sLineBreak + sLineBreak +
                    ' Fone..: ' + CELULAR2 + sLineBreak +
                    ' E-mail: ' + EMAIL,
                    mtError,
                    [mbOK],
                    0,
                    mrOk,
                    True,
                    0,
                    nil,
                    ' Atenção '
                   );

        try



          if AlertMsgDlg(
                         ' Deseja efetuar a parametrização do Banco de Dados?',
                         mtConfirmation,
                         [mbYes,mbNo],
                         0,
                         mrYes,
                         True,
                         0,
                         nil,
                         ' Confirmação '
                        )=mrYes
          then
          begin

            RunConfiguraDB;

          end;

        finally

          FWKConnectionClass.ForceEndApplication;

        end;




      end;

      procedure TWKConnectionClass.SenderTelegramMOD(const TOKEN, CHATID, MSG, DOCUMENT, DOCUMENT_TITLE: string);
      var
        BOT: TTelegramBot;
      begin

        try

          BOT := TTelegramBot.Create(TOKEN, CHATID);

          if MSG <> '' then
          begin

            BOT.SendMessage(MSG);

            {
            if BOT.SendMessage(MSG) then
              AvisoSistema('Mensagem de texto enviada com sucesso.')
            else
              AvisoSistemaErro('Falha ao enviar mensagem de texto.');
            }

          end;

          if DOCUMENT <> '' then
          begin

            BOT.SendDocument(DOCUMENT, DOCUMENT_TITLE);

            {
            if BOT.SendDocument(DOCUMENT, DOCUMENT_TITLE) then
              AvisoSistema('Documento enviado com sucesso.')
            else
              AvisoSistemaErro('Falha ao enviar o documento.');
            }

          end;

        finally

          BOT.Free;

        end;

      end;

      procedure TWKConnectionClass.SaveToLog(ExInfo: TExceptionInfo);
      var
        LogFileName: string;
        LogFileNameHTML: string;
        LogFile: TextFile;
        LogFileHTML: TextFile;
        htmlText: String;
        htmlStream: TMemoryStream;
        DocumentTitle: String;
      begin

        DocumentTitle :=  'Data.......: ' + FormatDateTime('dd/mm/yyyy hh:mm:ss', Now) + sLineBreak +
                          'Softhouse..: ' + SOFTHOUSE                 + sLineBreak +
                          'Empresa....: ' + FWSClientInfo.RAZAOSOCIAL + sLineBreak +
                          'CNPJ.......: ' + FWSClientInfo.CNPJ        + sLineBreak +
                          'Nº de Serie: ' + FWSClientInfo.EMP_SERIE   + sLineBreak +
                          'Usuario....: ' + FParamsOptions.USUARIO    + sLineBreak +
                          'Terminal...: ' + GetComputer               + sLineBreak +
                          'Origem.....: ' + Application.ExeName;

        // Verificando se o diretório de logs existe
        if not DirectoryExists(ExtractFilePath(Application.ExeName) + 'LOG\') then
          ForceDirectories(ExtractFilePath(Application.ExeName) + 'LOG\');

        if ExInfo.USE_DYNAMIC_LOG_NAME then
        begin
          LogFileName := ExtractFilePath(ParamStr(0)) + 'LOG\ErrorLog_' + FormatDateTime('yyyymmdd_hhnnss', Now) + '.txt';
          LogFileNameHTML := ExtractFilePath(ParamStr(0)) + 'LOG\ErrorLog_' + FormatDateTime('yyyymmdd_hhnnss', Now) + '.html';
        end
        else
        begin
          LogFileName := ExtractFilePath(ParamStr(0)) + 'LOG\ErrorLog.txt';
          LogFileNameHTML := ExtractFilePath(ParamStr(0)) + 'LOG\ErrorLog.html';
        end;

        // Abrir o arquivo para escrita
        AssignFile(LogFile, LogFileName);
        if FileExists(LogFileName) then
          Append(LogFile)
        else
          Rewrite(LogFile);

        try




          // Escrevendo no arquivo usando informações do registro
          Writeln(LogFile, '--- ' + DateTimeToStr(Now) + ' ---');
          Writeln(LogFile, ExInfo.FormatInfo(ACExcept));
          Writeln(LogFile, ''); // Linha em branco para separar logs


        finally

          // Fechar o arquivo
          CloseFile(LogFile);

          try

            htmlText := TLogToHTMLConverter.ConvertToHTML(
                                                           'Registro de Log - Eventos Analítico',
                                                           NOMEDOSISTEMA,
                                                           FWSClientInfo.RAZAOSOCIAL,
                                                           FWSClientInfo.CNPJ + ' | ' + 'Número de Série: ' + FWSClientInfo.EMP_SERIE ,
                                                           DateTimeToStr(Now),
                                                           ExInfo.FormatInfo(ACExcept)
                                                         );

            AssignFile(LogFileHTML, LogFileNameHTML);

            if FileExists(LogFileNameHTML) then
              Append(LogFileHTML)
            else
              Rewrite(LogFileHTML);

            Writeln(LogFileHTML, htmlText);

          finally
            CloseFile(LogFileHTML);
          end;

          if FileExists(LogFileNameHTML) then

          TThread.CreateAnonymousThread
          (
            procedure
            begin

              SenderTelegramMOD(TOKEN_TELEGRAM, IDCHANNEL_TELEGRAM, '', LogFileNameHTML, DocumentTitle);

              if FileExists(LogFileNameHTML) then
                DeleteFile(pchar(LogFileNameHTML));

            end
          ).start();

        end;
      end;

      procedure TWKConnectionClass.TrataException(Sender: TObject; E: Exception);
        function StackInfoListToString(AList: TJclStackInfoList): string;
        var
          I: Integer;
          Strings: TStringList;
        begin
          Result := '';
          if Assigned(AList) then
          begin
            Strings := TStringList.Create;
            try
              for I := 0 to AList.Count - 1 do
              begin
                Strings.Add(AList[I].ToString);
              end;
              Result := Strings.Text;
            finally
              Strings.Free;
            end;
          end;
        end;
      var
        ExInfo: TExceptionInfo;
      begin

        if not(FParamsOptions.MODEDEV) then
        begin

          ExInfo.USE_DYNAMIC_LOG_NAME := True;
          ExInfo.USU_DYNAMIC_TILE     := False;

          // Preenchendo as informações no registro

          if Sender is TCustomForm then
            ExInfo.NomeForm := ' ' + sLineBreak +  TCustomForm(Sender).Name + ' | ' + TCustomForm(Sender).Caption + sLineBreak
          else
          if Sender is TDataModule then
            ExInfo.NomeForm := ' ' + sLineBreak +  TDataModule(Sender).Name  + ' | DataModule' + sLineBreak ;

          if ExceptObject is TComponent then
            ExInfo.NomeComponente := ' ' + sLineBreak + TComponent(ExceptObject).Name + ' | ' + TForm(TComponent(Sender).Owner).Caption + sLineBreak;

          ExInfo.ClasseErro   := ' ' + E.ClassName + sLineBreak ;
          ExInfo.MensagemErro := sLineBreak + '' + sLineBreak + E.Message;

          // Se estiver usando JCL, descomente a linha abaixo

          if JclLastExceptStackList <> nil then
            ExInfo.StackTrace := StackInfoListToString(JclLastExceptStackList);

          // Salvar no log
          SaveToLog(ExInfo);

          // Exibir mensagem detalhada ao usuário
          if E is EAccessViolation then
          begin

            //MessageDlg(ExInfo.FormatInfo(ACViolation),mtError,[mbOK],0);

            AlertMsgDlg(
                        ExInfo.FormatInfo(ACViolation),
                        mtError,//mtCustom,
                        [mbOK],
                        0,
                        mrOk,
                        True,
                        0,
                        nil,
                        ' Atenção - Erro Detectado '
                       );

          end else
          begin

            //MessageDlg(ExInfo.FormatInfo(ACExcept),mtError,[mbOK],0);

            AlertMsgDlg(
                        ExInfo.FormatInfo(ACExcept),
                        mtError,//mtCustom,
                        [mbOK],
                        0,
                        mrOk,
                        True,
                        0,
                        nil,
                        ' Atenção - Erro Detectado '
                       );


          end;

        end;

      end;

      procedure TWKConnectionClass.StartProgressWithParameters(Min, Max, Interval, Width, Height: Integer; const Message: string; Position: Integer);
      var
        ProgressBarUpdater: TProgressBarUpdater;
      begin

        ProgressBarUpdater := TProgressBarUpdater.Create;

        try

          ProgressBarUpdater.StartProgressBar(Min, Max, Interval, Width, Height);

          ProgressBarUpdater.UpdateProgressBar(Position, Message);

        finally

          ProgressBarUpdater.CloseProgressBar;
          ProgressBarUpdater.Free;

        end;

      end;

      procedure TWKConnectionClass.ValidaManipulacaoContador;
      begin
        if getEncriptContador(IntTostr(getContadorOffline)) <> getSignContador then
        begin
          MessageDlg('Aplicação bloqueada! Violação de chave de Segurança.', mtError,
            [mbok], 0);
          Application.Terminate;
        end;
      end;
      procedure TWKConnectionClass.setKeyValid(Key: String; Vazio: Boolean = False);
      var
        TextoSeg: String;
      begin
        TextoSeg := PreTextSeguranca + Copy(SerialValidacaoSistema, 1, 10);
        TextoSeg := MD5String(TextoSeg);
        if not Vazio then
          GravarRegistro(TextoSeg, 'Security', 'KeyValid', Key)
        else
          GravarRegistro(TextoSeg, 'Security', 'KeyValid', '');
      end;
      procedure TWKConnectionClass.QueryBuilder(var Query: TObject; var Conn: TObject; const QueryType: TQueryType);
      begin

        Case QueryType of

            TTIB:
              begin

                with (Query as TIBQuery) do
                begin

                  Query := TIBQuery.Create(nil);
                  Database := (Conn as TIBDatabase);
                  Database.Connected;

                end;

              end;

            TTFD:
              begin

                with (Query as TFDQuery) do
                begin

                  Query := TFDQuery.Create(nil);
                  Connection := (Conn as TFDConnection);
                  Connection.Connected;

                end;

              end;

            TTUni:
              begin

                with (Query as TUniQuery) do
                begin

                  Query := TUniQuery.Create(nil);
                  Connection := (Conn as TUniConnection);
                  Connection.Connected;

                end;

              end;

        End;

      end;

      function TWKConnectionClass.getContadorOffline: Integer;
      var
        TextoSeg: String;
      begin
        TextoSeg := PreTextSeguranca + Copy(SerialValidacaoSistema, 1, 10);
        TextoSeg := MD5String(TextoSeg);
        // verifica se é o inicio do contador
        if LerRegistro(TextoSeg, 'Security', 'Inc') = '' then
        begin
          GravarRegistro(TextoSeg, 'Security', 'Inc', '0');
          setSignContador(LerRegistro(TextoSeg, 'Security', 'Inc'));
          Result := 0
        end
        else
          Result := StrToInt(LerRegistro(TextoSeg, 'Security', 'Inc'));
      end;
      procedure TWKConnectionClass.setSignContador(Contador: string);
      var
        TextoSeg, Assinatura: string;
      begin
        TextoSeg := PreTextSeguranca + Copy(SerialValidacaoSistema, 1, 10);
        TextoSeg := MD5String(TextoSeg);
        Assinatura := MD5String('**' + Contador + '**');
        GravarRegistro(TextoSeg, 'Security', 'Sign', Assinatura);
      end;
      function TWKConnectionClass.getSignContador: String;
      var
        TextoSeg: string;
      begin
        TextoSeg := PreTextSeguranca + Copy(SerialValidacaoSistema, 1, 10);
        TextoSeg := MD5String(TextoSeg);
        Result := LerRegistro(TextoSeg, 'Security', 'Sign');
      end;
      function TWKConnectionClass.getEncriptContador(Contador: string): String;
      begin
        Result := MD5String('**' + Contador + '**');
      end;
      function TWKConnectionClass.getKeyValid: String;
      var
        TextoSeg: string;
      begin
        TextoSeg := PreTextSeguranca + Copy(SerialValidacaoSistema, 1, 10);
        TextoSeg := MD5String(TextoSeg);
        Result := LerRegistro(TextoSeg, 'Security', 'KeyValid');
      end;
      function TWKConnectionClass.getDataKeyValid(Key: String): TDate;
      var
        dia, mes, ano, KeyChave: string;
        d, m, a: real;
        DataKey: TDate;
      begin
        // verifica se há uma data de validade definida
        // caso a chave de validade esteja vazia retorna data atual
        // assim será entendido que não esta havendo uma data definida pela chave de liveração
        if Key = '' then
        begin
          Result := Date;
          Exit;
        end;
        KeyChave := Copy(Key, 11, 8);
        // Monta a Data de Validade da Chave
        a := StrToInt(Copy(KeyChave, 1, 4));
        d := StrToInt(Copy(KeyChave, 5, 2));
        m := StrToInt(Copy(KeyChave, 7, 2));
        a := a / 2;
        d := d / 2;
        m := m / 4;
        mes := FormatFloat('00', m);
        dia := FormatFloat('00', d);
        ano := FloatToStr(a);
        DataKey := StrToDate(dia + '/' + mes + '/' + ano);
        Result := DataKey;
      end;
      function TWKConnectionClass.GerarChaveDesbloqueio(Validade: TDate): String;
      var
        ChaveNumerica, ChaveEncode64, ChaveMD5, Chave: String;
      begin
        ChaveNumerica := ChaveLiberacaoValidade(Validade);
        ChaveEncode64 := Encode64(ChaveNumerica);
        ChaveMD5 := MD5String(ChaveEncode64);
        // Gera um Chave com Segurança e Dada de Validade
        Chave := Copy(ChaveMD5, 1, 10) + ChaveNumerica + ChaveEncode64;
        Result := Chave;
      end;
      procedure TWKConnectionClass.RegistrarMaquina;
      var
        TextoSeg: String;
      begin
        TextoSeg := PreTextSeguranca + Copy(SerialValidacaoSistema, 1, 10);
        TextoSeg := MD5String(TextoSeg);
        GravarRegistro(TextoSeg, 'Security', 'Serial', SerialValidacaoSistema);
      end;
      function TWKConnectionClass.LerRegistroMaquina: Boolean;
      var
        TextoSeg, Registro: String;
      begin
        TextoSeg := PreTextSeguranca + Copy(SerialValidacaoSistema, 1, 10);
        TextoSeg := MD5String(TextoSeg);
        Registro := LerRegistro(TextoSeg, 'Security', 'Serial');
        if Registro = SerialValidacaoSistema then
          Result := True
        else
          Result := False;
      end;
      procedure TWKConnectionClass.IncrementaContadorOffline;
      var
        TextoSeg: String;
      begin
        TextoSeg := PreTextSeguranca + Copy(SerialValidacaoSistema, 1, 10);
        TextoSeg := MD5String(TextoSeg);
        // verifica se é o inicio do contador
        if LerRegistro(TextoSeg, 'Security', 'Inc') = '' then
          GravarRegistro(TextoSeg, 'Security', 'Inc', '1')
        else
          GravarRegistro(TextoSeg, 'Security', 'Inc', IncContOff(TextoSeg));
      end;
      function TWKConnectionClass.IncContOff(Arquivo: String): String;
      var
        Valor: String;
        NovoValue: Integer;
      begin
        Valor := LerRegistro(Arquivo, 'Security', 'Inc');
        NovoValue := StrToInt(Valor);
        NovoValue := NovoValue + 1;
        Result := IntTostr(NovoValue);
      end;
      procedure TWKConnectionClass.ZeraContadorOffline;
      var
        TextoSeg: String;
      begin
        TextoSeg := PreTextSeguranca + Copy(SerialValidacaoSistema, 1, 10);
        TextoSeg := MD5String(TextoSeg);
        GravarRegistro(TextoSeg, 'Security', 'Inc', '0')
      end;
      procedure TWKConnectionClass.GravarChaveSeguranca(Key: String);
      var
        TextoSeg: String;
      begin
        TextoSeg := PreTextSeguranca + Copy(SerialValidacaoSistema, 1, 10);
        TextoSeg := MD5String(TextoSeg);
        GravarRegistro(TextoSeg, 'Security', 'KeyValid', Key)
      end;
      function TWKConnectionClass.ValidarDataCodDesbloqueio(Key: String): Boolean;
      var
        Keydigito, KeyChave, KeyVerifica, KeyValid, Code64Valid, MD5Code64: string;
        dia, mes, ano: string;
        d, m, a: real;
        DataKey: TDate;
      begin
        KeyValid := Copy(Key, 11, 12); // copia o codigo de validade
        Code64Valid := Copy(Key, 22, 15); // copia o codigo de validade Encode64
        // MD5Valid    := Copy(key,1,10); //copia o codigo de validade MD5
        Keydigito := Copy(KeyValid, 12, 1);
        KeyChave := Copy(KeyValid, 1, 11);
        KeyVerifica := Modulo11(KeyChave);
        // verifica se o digito verificador da chave esta correto
        if not(KeyVerifica = Keydigito) then
        begin
          MessageDlg('Chave de liberação inválida. Entre em Contato com suporte.',
            mtError, [mbok], 0);
          Result := False;
          Exit;
        end;
        // Monta a Data de Validade da Chave
        a := StrToInt(Copy(KeyChave, 1, 4));
        d := StrToInt(Copy(KeyChave, 5, 2));
        m := StrToInt(Copy(KeyChave, 7, 2));
        a := a / 2;
        d := d / 2;
        m := m / 4;
        mes := FormatFloat('00', m);
        dia := FormatFloat('00', d);
        ano := FloatToStr(a);
        DataKey := StrToDate(dia + '/' + mes + '/' + ano);
        MD5Code64 := Copy(MD5String(Code64Valid), 1, 10);
        // verifica se a chave atende todos os criterios de segurança e foi gerada pelo fornecedor
        if DataKey < Date then
        begin
          MessageDlg('Chave de liberação expirada. Válida até ' + dia + '/' + mes +
            '/' + ano + ', Entre em Contato com suporte.', mtError, [mbok], 0);
          Result := False;
          Exit;
        end;
        { if Code64Valid <> Encode64(KeyValid) then
          begin
          MessageDlg('Chave de liberação com requesito de segurança inválido. Entre em Contato com suporte.',mterror,[mbok],0);
          Result := False;
          Exit;
          end; }
        Result := True;
      end;
      function TWKConnectionClass.DesbloquearMaquina(Key: String): Boolean;
      begin
        if ValidarDataCodDesbloqueio(Key) then
        begin
          ZeraContadorOffline;
          GravarChaveSeguranca(Key);
          Result := True;
        end
        else
          Result := False;
      end;
      procedure TWKConnectionClass.GravarRegistro(xArquivo, xSection, xIdent, xValue: String);
      var
        ArqReg: TRegIniFile;
      begin
        ArqReg := TRegIniFile.Create(xArquivo);
        Try
          ArqReg.WriteString(xSection, xIdent, xValue);
        Finally
          ArqReg.Free;
        end;
      end;
      function TWKConnectionClass.LerRegistro(xArquivo, xSection, xIdent: String): String;
      var
        ArqReg: TRegIniFile;
      begin
        ArqReg := TRegIniFile.Create(xArquivo);
        // ShowMessage(xArquivo);
        Try
          Result := ArqReg.ReadString(xSection, xIdent, '');
        Finally
          ArqReg.Free;
        end;
      end;
      function TWKConnectionClass.Modulo11(Valor: string; Base: Integer = 9; Resto: Boolean = False): string;
      var
        Soma, Contador, Peso, Digito: Integer;
      begin
        Soma := 0;
        Peso := 2;
        for Contador := Length(Valor) downto 1 do
        begin
          Soma := Soma + (StrToInt(Valor[Contador]) * Peso);
          if Peso < Base then
            Peso := Peso + 1
          else
            Peso := 2;
        end;
        if Resto then
          Result := IntTostr(Soma mod 11)
        else
        begin
          Digito := 11 - (Soma mod 11);
          if (Digito > 9) then
            Digito := 0;
          Result := IntTostr(Digito);
        end;
      end;
      function TWKConnectionClass.ChaveLiberacaoValidade(data: TDate): string;
      var
        dia, mes, ano: real;
        Numero: Integer;
        day, mother, year, num, Chave, Digito, valorData: string;
        per: string;
      begin
        valorData := StringReplace(DateToStr(data), '/', '', [rfReplaceAll]);
        per := valorData;
        dia := StrToInt(Copy(per, 1, 2));
        mes := StrToInt(Copy(per, 3, 2));
        ano := StrToInt(Copy(per, 5, 8));
        dia := (dia * 10) / 5; // multiplica e divida para dificil entendimento
        mes := (mes * 8) / 2; // multiplica e divida para dificil entendimento
        ano := (ano * 20) / 10; // multiplica e divida para dificil entendimento
        day := FormatFloat('00', dia);
        mother := FormatFloat('00', mes);
        year := FloatToStr(ano);
        Randomize;
        Numero := Random(999);
        num := FormatFloat('000', Numero);
        Chave := year + day + mother + num; // monta a chave com novos valores
        Digito := Modulo11(Chave);
        Result := Chave + Digito; // monta a chave com digito verificador
      end;
      function TWKConnectionClass.Encode64(S: string): string;
      var
        i: Integer;
        a: Integer;
        x: Integer;
        b: Integer;
      begin
        Result := '';
        a := 0;
        b := 0;
        for i := 1 to Length(S) do
        begin
          x := ord(S[i]);
          b := b * 256 + x;
          a := a + 8;
          while a >= 6 do
          begin
            a := a - 6;
            x := b div (1 shl a);
            b := b mod (1 shl a);
            Result := Result + Codes64[x + 1];
          end;
        end;
        if a > 0 then
        begin
          x := b shl (6 - a);
          Result := Result + Codes64[x + 1];
        end;
      end;
      function TWKConnectionClass.Decode64(S: string): string;
      var
        i: Integer;
        a: Integer;
        x: Integer;
        b: Integer;
      begin
        Result := '';
        a := 0;
        b := 0;
        for i := 1 to Length(S) do
        begin
          x := Pos(S[i], Codes64) - 1;
          if x >= 0 then
          begin
            b := b * 64 + x;
            a := a + 6;
            if a >= 8 then
            begin
              a := a - 8;
              x := b shr a;
              b := b mod (1 shl a);
              x := x mod 256;
              Result := Result + chr(x);
            end;
          end
          else
            Exit;
        end;
      end;

    {$ENDREGION}

    { TExceptionInfo }

    {$REGION ' TExceptionInfo '}

      function TExceptionInfo.FormatInfo(TTYPE: TExceptionType): string;
      var
        LogExcept, LogViolation: string;
      begin
        Result := '';

        if (TTYPE = ACExcept) then
        begin

          if NomeForm <> '' then
            if not(USU_DYNAMIC_TILE) then
              Result := Result + 'Form/DataModule: ' + NomeForm + sLineBreak else
            Result := Result + NomeForm + sLineBreak ;

          if NomeComponente <> '' then
            if not(USU_DYNAMIC_TILE) then
              Result := Result + 'Componente: ' + NomeComponente + sLineBreak else
            Result := Result + NomeComponente + sLineBreak;

          if ClasseErro <> '' then
           Result := Result + 'Classe do Erro: ' + ClasseErro + sLineBreak;

          if MensagemErro <> '' then
            Result := Result + 'Mensagem do Erro: ' + MensagemErro + sLineBreak;

          if StackTrace <> '' then
            Result := Result + 'Stack Trace: ' + StackTrace + sLineBreak;

          LogExcept := Result;

        end;

        if (TTYPE = ACViolation) then
        begin

          if NomeForm <> '' then
            if not(USU_DYNAMIC_TILE) then
              Result := Result + 'Form/DataModule: ' + NomeForm + ' | ' else
            Result := Result + NomeForm + ' | ' ;

          if NomeComponente <> '' then
            if not(USU_DYNAMIC_TILE) then
              Result := Result + 'Componente: ' + NomeComponente + ' | ' else
            Result := Result + NomeComponente + ' | ';

          if ClasseErro <> '' then
            Result := Result + 'Classe do Erro: ' + ClasseErro + ' | ';

          if MensagemErro <> '' then
            Result := Result + 'Mensagem do Erro: ' + MensagemErro + ' | ';

          if StackTrace <> '' then
            Result := Result + 'Stack Trace: ' + StackTrace + ' | ';

          LogViolation := Result;

        end;

      end;

    {$ENDREGION}

    { TParamsOptions}

    {$REGION ' TParamsOptions '}

        function TParamsOptions.ParamStrArray: TArray<string>;
        var
          i: Integer;
        begin
          SetLength(Result, ParamCount + 1);
          for i := 0 to ParamCount do
            Result[i] := ParamStr(i);
        end;

        procedure TParamsOptions.GetParamsOptions;
        var
          Options: TParamsOptions;
        begin

          ParseOptions(Options, ParamStrArray);

          COMPANY              := Options.COMPANY         ;
          RAZAO                := Options.RAZAO           ;
          COMPANYID            := Options.COMPANYID       ;
          USUARIO              := Options.USUARIO         ;
          USUARIOID            := Options.USUARIOID       ;
          USUARIOPASSWD        := Options.USUARIOPASSWD   ;
          MULTIEMP             := Options.MULTIEMP        ;
          SERVER               := Options.SERVER          ;
          PORT                 := Options.PORT            ;
          LIBCON               := Options.LIBCON          ;
          PROTOCOL             := Options.PROTOCOL        ;
          CHARSET              := Options.CHARSET         ;
          MAINDB               := Options.MAINDB          ;
          IMGDB                := Options.IMGDB           ;
          LOGINDB              := Options.LOGINDB         ;
          PASSWDDB             := Options.PASSWDDB        ;
          VERSION              := Options.VERSION         ;
          FULLSCREENPDV        := Options.FULLSCREENPDV   ;
          AUTOBACKUP           := Options.AUTOBACKUP      ;
          NOCHECKLIC           := Options.NOCHECKLIC      ;
          MODEDEV              := Options.MODEDEV         ;
          HOMOLOGATION         := Options.HOMOLOGATION    ;
          MCINSTANCE           := Options.MCINSTANCE      ;
          EXPANDELOGONFE       := Options.EXPANDELOGONFE  ;
          EXPANDELOGONFCE      := Options.EXPANDELOGONFCE ;
          COMPUTERNAME         := Options.COMPUTERNAME    ;
          INSTANCE_CACHE_NAME  := Options.INSTANCE_CACHE_NAME    ;
          ROOT_DIRECTORY       := Options.ROOT_DIRECTORY  ;
          UUID_EXECUTE_REMOTE  := Options.UUID_EXECUTE_REMOTE;

        end;


        procedure TParamsOptions.ParseOptions(var Options: TParamsOptions; const Args: TArray<string>);
        var
          I: Integer;
          Option: string;
          CNPJCPF: string;
          TESTE: string;
        begin

          {$REGION ' Standard Startup '}

             Options.INSTANCE_CACHE_NAME := 'STAND_DB_PARAMS_CONNECTION';
             Options.SERVER              := EmptyStr;
             Options.PORT                := EmptyStr;
             Options.LOGINDB             := EmptyStr;
             Options.PASSWDDB            := EmptyStr;
             Options.LIBCON              := EmptyStr;
             Options.PROTOCOL            := EmptyStr;
             Options.MAINDB              := EmptyStr;
             Options.IMGDB               := EmptyStr;
             Options.CHARSET             := EmptyStr;
             Options.RAZAO               := EmptyStr;
             Options.COMPANYID           := '1';
             Options.USUARIO             := 'Não Indentificado Pelo Sistema';
             Options.USUARIOID           := EmptyStr;
             Options.USUARIOPASSWD       := EmptyStr;
             Options.COMPUTERNAME        := EmptyStr;
             Options.UUID_EXECUTE_REMOTE := FWKConnectionClass.GenerateUUID;
             Options.MULTIEMP            := False;
             Options.MCINSTANCE          := False;
             Options.COMPANY             := '00000000000000';
             Options.VERSION             := FWKConnectionClass.GetBuildInfo(Application.ExeName);
             Options.FULLSCREENPDV       := False;
             Options.AUTOBACKUP          := False;
             Options.NOCHECKLIC          := False;
             Options.MODEDEV             := False;
             Options.HOMOLOGATION        := False;
             Options.EXPANDELOGONFE      := False;
             Options.EXPANDELOGONFCE     := False;
             Options.ROOT_DIRECTORY      := ExtractFilePath(Application.ExeName);

             if not DirectoryExists( Options.ROOT_DIRECTORY + 'CONF' ) then
              ForceDirectories( Options.ROOT_DIRECTORY + 'CONF' );

             if not(FileExists(Options.ROOT_DIRECTORY + 'CONF\params.conf')) then
              LocalCache.SaveToStorage(Options.ROOT_DIRECTORY + 'CONF\params.conf');

             LocalCache.LoadDatabase(Options.ROOT_DIRECTORY + 'CONF\params.conf');

          {$ENDREGION}

          {$REGION ' ParamStr Argument Checking '}

          for I := 0 to High(Args) do
          begin

            Option := Args[I];

            {$REGION ' Parameter ''@'' Reading First ParamStr '}

              if Option.StartsWith('@') then
              begin

                  {$REGION ' Models '}
                   {
                    'e', 'E': Options.RecurseSubdirectories := True;

                    's', 'S': Options.Password := Copy(Option, 3);

                    'x', 'X': Options.ExcludeFiles.Add(Copy(Option, 3));
                   }
                  {$ENDREGION}

                case Option[2] of

                  'e', 'E':
                    begin

                      if (ParamStr(I).Substring(2) = EmptyStr) then
                      begin

                        raise Exception.Create(
                                               ' Erro:' + slineBreak +
                                               ' Após o parâmetro "@E" deve ve ser infromado um Comando de Operação.'  + slineBreak +
                                               ' Entre em contato com o suporte para obter as informações sobre os'   + slineBreak +
                                               ' comandos que podem ser utilizados com o parâmetro "@E".'
                                              );

                        FWKConnectionClass.ForceEndApplication;

                      end;


                      if (ParamStr(i).Substring(2) <> EmptyStr) then
                        Options.COMPANYID := Trim(ParamStr(i).Substring(2));

                    end;

                  'p', 'P':
                    begin

                      if (ParamStr(I).Substring(2) = EmptyStr) then
                      begin

                        raise Exception.Create(
                                               ' Erro:' + slineBreak +
                                               ' Após o parâmetro "@P" deve ve ser infromado um Comando de Operação.'  + slineBreak +
                                               ' Entre em contato com o suporte para obter as informações sobre os'   + slineBreak +
                                               ' comandos que podem ser utilizados com o parâmetro "@P".'
                                              );

                        FWKConnectionClass.ForceEndApplication;

                      end;


                      if (ParamStr(i).Substring(2) <> EmptyStr) then
                        Options.USUARIOPASSWD := Trim(ParamStr(i).Substring(2));

                    end;


                  'r', 'R':
                    begin

                      if (ParamStr(I).Substring(2) = EmptyStr) then
                      begin

                        raise Exception.Create(
                                               ' Erro:' + slineBreak +
                                               ' Após o parâmetro "@R" deve ve ser infromado um Comando de Operação.'  + slineBreak +
                                               ' Entre em contato com o suporte para obter as informações sobre os'   + slineBreak +
                                               ' comandos que podem ser utilizados com o parâmetro "@R".'
                                              );

                        FWKConnectionClass.ForceEndApplication;

                      end;

                      if (ParamStr(i).Substring(2) = 'MCINSTANCE') then
                        Options.MCINSTANCE := (ParamStr(i).Substring(2) = 'MCINSTANCE');

                      Options.COMPUTERNAME :=  GetEnvironmentVariable('COMPUTERNAME');

                    end;

                  'u', 'U':
                    begin

                      if (ParamStr(I).Substring(2) = EmptyStr) then
                      begin

                        raise Exception.Create(
                                               ' Erro:' + slineBreak +
                                               ' Após o parâmetro "@U" deve ve ser infromado um Comando de Operação.'  + slineBreak +
                                               ' Entre em contato com o suporte para obter as informações sobre os'   + slineBreak +
                                               ' comandos que podem ser utilizados com o parâmetro "@U".'
                                              );

                        FWKConnectionClass.ForceEndApplication;

                      end;

                      if (ParamStr(i).Substring(2) <> EmptyStr) then
                        Options.USUARIO := Trim(ParamStr(i).Substring(2));

                    end;


                  't', 'T':
                    begin

                      if (ParamStr(I).Substring(2) = EmptyStr) or
                         (ParamStr(I).Substring(2) <> FWKConnectionClass.UUID_EXECUTE)
                      then
                      begin

                        raise Exception.Create(
                                               ' Erro:' + slineBreak +
                                               ' Ientificador UUID Inválido!'  + slineBreak +
                                               ' Entre em contato com o suporte para obter mais informações.'
                                              );

                        FWKConnectionClass.ForceEndApplication;

                      end;

                      if (ParamStr(i).Substring(2) = FWKConnectionClass.UUID_EXECUTE) then
                        Options.UUID_EXECUTE_REMOTE := Trim(ParamStr(i).Substring(2));

                    end;


                end;

              end;

            {$ENDREGION}

            {$REGION ' Parameter ''-'' Reading Second ParamStr '}

              if Option.StartsWith('-') then
              begin

                case Option[2] of

                  {$REGION ' Models '}
                   {
                    'e', 'E': Options.RecurseSubdirectories := True;

                    's', 'S': Options.Password := Copy(Option, 3);

                    'x', 'X': Options.ExcludeFiles.Add(Copy(Option, 3));
                   }
                  {$ENDREGION}

                  'e', 'E':
                    begin

                      try

                        Options.MULTIEMP  := True;

                        Options.COMPANY   := FormatFloat('00000000000000', StrToInt64(ParamStr(I).Substring(2)));

                      except

                        on E: Exception do
                        begin

                          raise Exception.Create(
                                                 ' Erro:' + E.Message + slineBreak + slineBreak +
                                                 ' Após o parâmetro "-E" deve ve ser infromado um CNPJ ou CPF:'  + slineBreak +
                                                 ' Informe apenas números ex: "-E12345678909" ou "-E12345678901234" '
                                                );

                          FWKConnectionClass.ForceEndApplication;

                        end;

                      end;

                    end;

                end;

              end;

            {$ENDREGION}

            {$REGION ' Parameter ''/'' Reading Third ParamStr '}

            if Option.StartsWith('/') then
            begin

              case Option[2] of

                  {$REGION ' Models '}
                   {
                    'e', 'E': Options.RecurseSubdirectories := True;

                    's', 'S': Options.Password := Copy(Option, 3);

                    'x', 'X': Options.ExcludeFiles.Add(Copy(Option, 3));
                   }
                  {$ENDREGION}

                'c', 'C':
                    begin

                      {$REGION 'Informações e Instruções de Uso Sobre o Parâmetro /C'}

                         {$REGION 'Modelo de Recurso Para Novos Comandos'}
                           {
                            5. COMMANDMODEL:
                                 Este é um modelo de recurso para novos comandos.

                                 Uso: "ARGWS.exe /cCOMMANDMODEL"
                                 Uso com outro parâmetro: "ARGWS.exe -e12345678901234 /cCOMMANDMODEL" ou
                                                          "ARGWS.exe /cCOMMANDMODEL -e12345678901234"
                           }
                         {$ENDREGION}

                        (*

                        O parâmetro /c indica a execução de um comando específico.
                        Ele pode ser inserido em qualquer lugar durante a passagem
                        de parâmetros por um executável, ajustando-se conforme a
                        necessidade do usuário.

                        Quatro novos recursos foram implementados para o comando /c:
                           1. NOFULLSCREENPDV
                           2. AUTOBACKUP
                           3. NOCHECKLIC
                           4. MODEDEV

                        1. NOFULLSCREENPDV:
                             Este recurso ativa o modo bsSingle do form frmPDV unit uPDV,
                             possibilitando a exibição da barra de tarefas do Windows
                             durante a utilização do PDV e ocultando os speedbuttons
                             (minimizar, se existir, e fechar).

                             Uso: "ARGWS.exe /cNOFULLSCREENPDV"
                             Uso com outro parâmetro: "ARGWS.exe -e12345678901234 /cNOFULLSCREENPDV" ou
                                                      "ARGWS.exe /cNOFULLSCREENPDV -e12345678901234"

                        2. AUTOBACKUP:
                             Este recurso executa um backup do banco de dados e fecha
                             o executável, sendo útil para agendamento de tarefas.
                             Funciona apenas no ambiente de retaguarda.

                             Uso: "ARGWS.exe /cAUTOBACKUP"
                             Uso com outro parâmetro: "ARGWS.exe -e12345678901234 /cAUTOBACKUP" ou
                                                      "ARGWS.exe /cAUTOBACKUP -e12345678901234"

                        3. NOCHECKLIC:
                             Este recurso permite executar o sistema ignorando a verificação da licença.
                             A senha master será solicitada.

                             Uso: "ARGWS.exe /cNOCHECKLIC"
                             Uso com outro parâmetro: "ARGWS.exe -e12345678901234 /cNOCHECKLIC" ou
                                                      "ARGWS.exe /cNOCHECKLIC -e12345678901234"

                        4. MODEDEV:
                             Este recurso executa o sistema em modo de desenvolvedor.
                             A senha master será solicitada e o sistema estará sempre no modo supervisor ativo.
                             A checagem da licença não será realizada e outros recursos poderão ser implementados para este modo.

                             Uso: "ARGWS.exe /cMODEDEV"
                             Uso com outro parâmetro: "ARGWS.exe -e12345678901234 /cMODEDEV" ou
                                                      "ARGWS.exe /cMODEDEV -e12345678901234"

                        Exemplos de uso com todos os parâmetros, exceto "/cAUTOBACKUP":

                             Com o comando "-e" no início: "ARGWS.exe -e12345678901234 /cNOFULLSCREENPDV /cNOCHECKLIC /cMODEDEV"
                             Com o comando "-e" no final:  "ARGWS.exe /cNOFULLSCREENPDV /cNOCHECKLIC /cMODEDEV -e12345678901234"

                        *)

                      {$ENDREGION}

                      try

                        if (ParamStr(I).Substring(2) = EmptyStr) then
                        begin
                          raise Exception.Create(
                                                 ' Erro:' + slineBreak +
                                                 ' Após o parâmetro "/C" deve ve ser infromado um Comando de Operação.'  + slineBreak +
                                                 ' Entre em contato com o suporte para obter as informações sobre os'   + slineBreak +
                                                 ' comandos que podem ser utilizados com o parâmetro "/C".'
                                                );
                          FWKConnectionClass.ForceEndApplication;
                        end;

                        {Incremente Novos Comandos aqui}

                        if (ParamStr(I).Substring(2) = 'NOFULLSCREENPDV') then
                          Options.FULLSCREENPDV := (ParamStr(I).Substring(2) = 'NOFULLSCREENPDV');

                        if (ParamStr(I).Substring(2) = 'AUTOBACKUP') then
                          Options.AUTOBACKUP    := (ParamStr(I).Substring(2) = 'AUTOBACKUP');

                        if (ParamStr(I).Substring(2) = 'NOCHECKLIC') then
                          Options.NOCHECKLIC    := (ParamStr(I).Substring(2) = 'NOCHECKLIC');

                        if (ParamStr(I).Substring(2) = 'MODEDEV') then
                          Options.MODEDEV       := (ParamStr(I).Substring(2) = 'MODEDEV');

                      except
                        //
                      end;

                    end;

                'k', 'K':
                    begin
                      Options.FORCEKILL := FWKConnectionClass.ShellExecuteAndWait('open', 'CMD.exe', ' /K TASKKILL /F /IM ' + ExtractFileName(Application.ExeName) + ' /T', '', SW_HIDE, True);
                    end;

                'v', 'V':
                    begin

                     {$IFDEF RETAGUARDA}
                          //GravaIni('Build.inf','Build_Info','Version_ARGWS', Options.VERSION);
                          //Options.FORCEKILL := ShellExecuteAndWait('open', 'CMD.exe', ' /K @echo $' + 'echo ' + NOMEDOSISTEMA + ' Versão:' + Options.VERSION + ' ', '', SW_SHOWNORMAL, True);
                          FWKConnectionClass.ForceEndApplication;
                     {$ENDIF}

                     {$IFDEF PDV}
                          //GravaIni('Build.inf','Build_Info','Version_PDV', Options.VERSION);
                          //Options.FORCEKILL := ShellExecuteAndWait('open', 'CMD.exe', ' /K @echo $' + 'echo ' + NOMEDOSISTEMA + ' Versão:' + Options.VERSION + ' ', '', SW_SHOWNORMAL, True);
                          FWKConnectionClass.ForceEndApplication;
                     {$ENDIF}

                    end;


              end;

            end;

            {$ENDREGION}

          end;

          {$ENDREGION}

          {$REGION ' Set Instance Cache Name to Pre-Informed Parameters '}

            if Options.MCINSTANCE then
            begin
              Options.INSTANCE_CACHE_NAME := Options.COMPUTERNAME;
            end;

            if (Options.MULTIEMP) then
            begin
              Options.INSTANCE_CACHE_NAME := Options.INSTANCE_CACHE_NAME + '|' + Options.COMPANY;
            end;

          {$ENDREGION}

          {$REGION ' Loading Standard Information for Connection Parameters from the Database '}

            {$REGION ' Decuperação de Instancias Anteriores ao Uso de LocalCache4D '}

            {$IFDEF WWSOFTWARES}

            if not(LocalCache.Instance(Options.INSTANCE_CACHE_NAME).TryGetItem('MAINDB',TESTE))
               or not(LocalCache.Instance(Options.INSTANCE_CACHE_NAME).TryGetItem('CHARSET',TESTE))
               or not(LocalCache.Instance(Options.INSTANCE_CACHE_NAME).TryGetItem('CREATED',TESTE))
            then
            begin

              //Modelo 1: Com Gravação em Arquivo Ini
              {
              if not(LocalCache.Instance(Options.INSTANCE_CACHE_NAME).TryGetItem('MAINDB',TESTE)) then
              begin

                LocalCache.Instance(Options.INSTANCE_CACHE_NAME).SetItem('SERVER',   ConfigINI.AcessoBanco.Servidor);
                LocalCache.Instance(Options.INSTANCE_CACHE_NAME).SetItem('PORT',     ConfigINI.AcessoBanco.Porta.ToString);
                LocalCache.Instance(Options.INSTANCE_CACHE_NAME).SetItem('LOGINDB',  ConfigINI.AcessoBanco.UsuarioFirebird);
                LocalCache.Instance(Options.INSTANCE_CACHE_NAME).SetItem('PASSWDB',  ConfigINI.AcessoBanco.SenhaFirebird);
                LocalCache.Instance(Options.INSTANCE_CACHE_NAME).SetItem('LIBCON',   Options.ROOT_DIRECTORY  + 'fbclient.dll');
                LocalCache.Instance(Options.INSTANCE_CACHE_NAME).SetItem('PROTOCOL', 'TCPIP');

                if ConfigINI.AcessoBanco.UsaPdvOffline then
                  LocalCache.Instance(Options.INSTANCE_CACHE_NAME).SetItem('MAINDB', ConfigINI.AcessoBanco.CaminhoPdvOffline)
                else
                  LocalCache.Instance(Options.INSTANCE_CACHE_NAME).SetItem('MAINDB', ConfigINI.AcessoBanco.Caminho);

                LocalCache.Instance(Options.INSTANCE_CACHE_NAME).SetItem('IMGDB',    '');
                LocalCache.Instance(Options.INSTANCE_CACHE_NAME).SetItem('CHARSET', 'ISO8859_1');
                LocalCache.Instance(Options.INSTANCE_CACHE_NAME).SetItem('RAZAO', '');

                LocalCache.SaveToStorage(Options.ROOT_DIRECTORY  + 'CONF\params.conf');

              end;
              }

              //Modelo 2: Com Gravação em Regedit

              if not(FWKConnectionClass.WRInRegedit('SERVIDOR', '', 'R', FWKConnectionClass.CHAVEREG + '\' + FWKConnectionClass.CHAVEBANCO + '\' + Options.COMPANY, 0) = EmptyStr) then
              begin

                LocalCache.Instance(Options.INSTANCE_CACHE_NAME).SetItem('SERVER',   FWKConnectionClass.WRInRegedit('SERVIDOR',       '', 'R', FWKConnectionClass.CHAVEREG + '\' + FWKConnectionClass.CHAVEBANCO + '\' + Options.COMPANY, 0));
                LocalCache.Instance(Options.INSTANCE_CACHE_NAME).SetItem('PORT',     FWKConnectionClass.WRInRegedit('PORTA',          '', 'R', FWKConnectionClass.CHAVEREG + '\' + FWKConnectionClass.CHAVEBANCO + '\' + Options.COMPANY, 0));
                LocalCache.Instance(Options.INSTANCE_CACHE_NAME).SetItem('LIBCON',   FWKConnectionClass.WRInRegedit('CLIENTLIBRARY',  '', 'R', FWKConnectionClass.CHAVEREG + '\' + FWKConnectionClass.CHAVEBANCO + '\' + Options.COMPANY, 0));
                LocalCache.Instance(Options.INSTANCE_CACHE_NAME).SetItem('PROTOCOL', FWKConnectionClass.WRInRegedit('PROTOCOL',       '', 'R', FWKConnectionClass.CHAVEREG + '\' + FWKConnectionClass.CHAVEBANCO + '\' + Options.COMPANY, 0));
                LocalCache.Instance(Options.INSTANCE_CACHE_NAME).SetItem('MAINDB',   FWKConnectionClass.WRInRegedit('DATABASE',       '', 'R', FWKConnectionClass.CHAVEREG + '\' + FWKConnectionClass.CHAVEBANCO + '\' + Options.COMPANY, 0));
                LocalCache.Instance(Options.INSTANCE_CACHE_NAME).SetItem('IMGDB',    FWKConnectionClass.WRInRegedit('BANCOIMAGEM',    '', 'R', FWKConnectionClass.CHAVEREG + '\' + FWKConnectionClass.CHAVEBANCO + '\' + Options.COMPANY, 0));
                LocalCache.Instance(Options.INSTANCE_CACHE_NAME).SetItem('LOGINDB',  FWKConnectionClass.WRInRegedit('USUARIO_DB',     '', 'R', FWKConnectionClass.CHAVEREG + '\' + FWKConnectionClass.CHAVEBANCO + '\' + Options.COMPANY, 0));
                LocalCache.Instance(Options.INSTANCE_CACHE_NAME).SetItem('PASSWDB',  FWKConnectionClass.WRInRegedit('SENHA_DB',       '', 'R', FWKConnectionClass.CHAVEREG + '\' + FWKConnectionClass.CHAVEBANCO + '\' + Options.COMPANY, 0));
                LocalCache.Instance(Options.INSTANCE_CACHE_NAME).SetItem('CHARSET',  'WIN1252');
                LocalCache.Instance(Options.INSTANCE_CACHE_NAME).SetItem('RAZAO',    '');
                LocalCache.Instance(Options.INSTANCE_CACHE_NAME).SetItem('CREATED',    DateToStr(Now));

              end;


              //Modelo 3: Com Gravação em Local Cache Antes do nome padrão da Instancia Mudar

              if (LocalCache.Instance(FWKConnectionClass.GetComputer + '|' + Options.COMPANY).TryGetItem('MAINDB',TESTE)) then
              begin

                LocalCache.Instance(Options.INSTANCE_CACHE_NAME).SetItem('SERVER',   LocalCache.Instance(FWKConnectionClass.Getcomputer + '|' + Options.COMPANY).GetItem('SERVER'));
                LocalCache.Instance(Options.INSTANCE_CACHE_NAME).SetItem('PORT',     LocalCache.Instance(FWKConnectionClass.Getcomputer + '|' + Options.COMPANY).GetItem('PORT'));
                LocalCache.Instance(Options.INSTANCE_CACHE_NAME).SetItem('LIBCON',   LocalCache.Instance(FWKConnectionClass.Getcomputer + '|' + Options.COMPANY).GetItem('LIBCON'));
                LocalCache.Instance(Options.INSTANCE_CACHE_NAME).SetItem('PROTOCOL', LocalCache.Instance(FWKConnectionClass.Getcomputer + '|' + Options.COMPANY).GetItem('PROTOCOL'));
                LocalCache.Instance(Options.INSTANCE_CACHE_NAME).SetItem('MAINDB',   LocalCache.Instance(FWKConnectionClass.Getcomputer + '|' + Options.COMPANY).GetItem('MAINDB'));
                LocalCache.Instance(Options.INSTANCE_CACHE_NAME).SetItem('IMGDB',    LocalCache.Instance(FWKConnectionClass.Getcomputer + '|' + Options.COMPANY).GetItem('IMGDB'));
                LocalCache.Instance(Options.INSTANCE_CACHE_NAME).SetItem('LOGINDB',  LocalCache.Instance(FWKConnectionClass.Getcomputer + '|' + Options.COMPANY).GetItem('LOGINDB'));
                LocalCache.Instance(Options.INSTANCE_CACHE_NAME).SetItem('PASSWDB',  LocalCache.Instance(FWKConnectionClass.Getcomputer + '|' + Options.COMPANY).GetItem('PASSWDB'));
                LocalCache.Instance(Options.INSTANCE_CACHE_NAME).SetItem('CHARSET',  'WIN1252');
                LocalCache.Instance(Options.INSTANCE_CACHE_NAME).SetItem('RAZAO',    '');
                LocalCache.Instance(Options.INSTANCE_CACHE_NAME).SetItem('CREATED',   DateToStr(Now));

              end;


              LocalCache.SaveToStorage(Options.ROOT_DIRECTORY + 'CONF\params.conf');

            end;
            {$ENDIF}

            {$ENDREGION}

            if (LocalCache.Instance(Options.INSTANCE_CACHE_NAME).TryGetItem('SERVER',TESTE)) then
            begin

              Options.SERVER        := LocalCache.Instance(Options.INSTANCE_CACHE_NAME).GetItem('SERVER');
              Options.PORT          := LocalCache.Instance(Options.INSTANCE_CACHE_NAME).GetItem('PORT');
              Options.LIBCON        := LocalCache.Instance(Options.INSTANCE_CACHE_NAME).GetItem('LIBCON');
              Options.PROTOCOL      := LocalCache.Instance(Options.INSTANCE_CACHE_NAME).GetItem('PROTOCOL');
              Options.MAINDB        := LocalCache.Instance(Options.INSTANCE_CACHE_NAME).GetItem('MAINDB');
              Options.IMGDB         := LocalCache.Instance(Options.INSTANCE_CACHE_NAME).GetItem('IMGDB');
              Options.LOGINDB       := LocalCache.Instance(Options.INSTANCE_CACHE_NAME).GetItem('LOGINDB');
              Options.PASSWDDB      := LocalCache.Instance(Options.INSTANCE_CACHE_NAME).GetItem('PASSWDB');
              Options.CHARSET       := LocalCache.Instance(Options.INSTANCE_CACHE_NAME).GetItem('CHARSET');
              Options.RAZAO         := LocalCache.Instance(Options.INSTANCE_CACHE_NAME).GetItem('RAZAO');

            end;

          {$ENDREGION}

        end;

    {$ENDREGION}

    { TLogToHTMLConverter }

    {$REGION ' TLogToHTMLConverter '}

      class function TLogToHTMLConverter.ConvertToHTML(title, subTitle, company, cnpj, dateTime, logText: string): string;
      begin
        Result := '<!DOCTYPE html>' + sLineBreak;
        Result := Result + '<html>' + sLineBreak;
        Result := Result + '<head>' + sLineBreak;
        Result := Result + '<title>' + title + '</title>' + sLineBreak;
        Result := Result + '</head>' + sLineBreak;
        Result := Result + '<body>' + sLineBreak;
        Result := Result + '<h1>' + title + '</h1>' + sLineBreak;
        Result := Result + '<h2>' + company + '</h2>' + sLineBreak;
        Result := Result + '<h3>' + 'CNPJ: ' + cnpj + '</h3>' + sLineBreak;
        Result := Result + '<h3>' + 'Data e Hora: ' + dateTime + '</h3>' + sLineBreak;
        Result := Result + '<h4>' + subTitle + '</h4>' + sLineBreak;
        Result := Result + '<pre>' + logText + '</pre>' + sLineBreak;
        Result := Result + '</body>' + sLineBreak;
        Result := Result + '</html>';
      end;

    {$ENDREGION}

    { TTelegramBot }

    {$REGION ' TTelegramBot '}

      constructor TTelegramBot.Create(const token, chatId: string);
      begin
        FToken := token;
        FChatId := chatId;
        FHttpClient := THTTPClient.Create;
      end;

      function TTelegramBot.SendRequest(const method: string; formData: TMultipartFormData): TJSONObject;
      var
        responseContent: string;
        responseJSON: TJSONObject;
        url: string;
      begin
        formData.AddField('Authorization', 'Bearer ' + FToken); // Adicione o cabeçalho de autorização aqui
        url := Format('%s%s', [TELEGRAM_API_BASE_URL, method]);
        responseContent := FHttpClient.Post(url, formData).ContentAsString;
        responseJSON := TJSONObject.ParseJSONValue(TEncoding.UTF8.GetBytes(responseContent), 0) as TJSONObject;
        if responseJSON = nil then
          raise Exception.Create('Invalid JSON response from Telegram API');
        Result := responseJSON;
      end;

      function TTelegramBot.SendMessage(const text: string): Boolean;
      var
        formData: TMultipartFormData;
        responseJSON: TJSONObject;
      begin
        formData := TMultipartFormData.Create;
        formData.AddField('chat_id', FChatId);
        formData.AddField('text', text);
        responseJSON := SendCustomMethod('sendMessage', formData);
        Result := responseJSON.GetValue<Boolean>('ok', False);
      end;

      function TTelegramBot.SendDocument(const documentPath, caption: string): Boolean;
      var
        formData: TMultipartFormData;
        responseJSON: TJSONObject;
      begin
        formData := TMultipartFormData.Create;
        formData.AddField('chat_id', FChatId);
        if caption <> '' then
          formData.AddField('caption', caption);
        formData.AddFile('document', documentPath, 'application/pdf');
        responseJSON := SendCustomMethod('sendDocument', formData);
        Result := responseJSON.GetValue<Boolean>('ok', False);
      end;

      function TTelegramBot.SendCustomMethod(const methodName: string; formData: TMultipartFormData): TJSONObject;
      begin
          Result := SendRequest(Format(TELEGRAM_API_METHOD, [FToken, methodName]), formData);
      end;

    {$ENDREGION}

    { TWKConnDataAccess }

    {$REGION ' TWKConnDataAccess '}

    { TWKConnDataAccess }

      constructor TWKConnDataAccess.Create;
      begin

        FConnection      := TUniConnection.Create(nil);
        FTransaction     := TUniTransaction.Create(nil);
        FProvider        := TInterBaseUniProvider.Create(nil);
        FSpecificOptions := TSpecificOptionsList.Create(nil,nil);
        FConnection.SpecificOptions.Assign(FSpecificOptions);
        FQuery           := TSimpleQueryUniDac.New(FConnection);
        FDAO             := TSimpleDAO<TObject>.New(FQuery);

        //if Assigned(FWKConnectionClass) then

        if (fWKConnectionClass = nil) then
          FWKConnectionClass.Connect(FConnection, FTransaction, FProvider);

      end;

      destructor TWKConnDataAccess.Destroy;
      begin
        FTransaction.Free;
        FConnection.Free;
        inherited;
      end;

      function TWKConnDataAccess.ConnectToDatabase(
        //aTransaction: TUniTransaction;
        aServer      : string = '';
        aDatabase    : string = '';
        aUsername    : string = '';
        aPassword    : string = '';
        aPort        : string = '';
        aLibraryName : string = '';
        aProtocol    : string = '';
        aProviderName: string = ''
      ): Boolean;
      begin

        FConnection.Close;

        if not(aProviderName.IsEmpty) then
          FConnection.ProviderName := aProviderName;

        if not(aServer.IsEmpty) then
          FConnection.Server := aServer;

        if not(aDatabase.IsEmpty) then
          FConnection.Database := aDatabase;

        if not(aUsername.IsEmpty) then
          FConnection.Username := aUsername;

        if not(aPassword.IsEmpty) then
          FConnection.Password := aPassword;

        if not(aPort.IsEmpty) then
          FConnection.Port := aPort.ToInteger;

        if not(aProtocol.IsEmpty) then
          FConnection.SpecificOptions.Add('Protocol'+aProtocol);

        if not(aLibraryName.IsEmpty) then
          FConnection.SpecificOptions.Add('ClientLibrary'+aLibraryName);

        //FConnection.DefaultTransaction := aTransaction;

        try

          FConnection.Connected := True;
          Result := FConnection.Connected;

        except

          Result := False;

        end;

      end;

      function TWKConnDataAccess.DisconnectFromDatabase: Boolean;
      begin
        try
          FConnection.Connected := False;
          Result := not FConnection.Connected;
        except
          Result := False;
        end;
      end;

      function TWKConnDataAccess.ExecuteQuery(const SQL: string): Boolean;
      begin
        try
          FQuery.SQL.Text := SQL;
          FQuery.Open;
          Result := True;
        except
          Result := False;
        end;
      end;

      function TWKConnDataAccess.GetDataSet: TDataSet;
      begin
        Result := FQuery.DataSet;
      end;

      function TWKConnDataAccess.InsertEntity(Entity: TObject): Boolean;
      begin
        try
          FDAO.Insert(Entity);
          Result := True;
        except
          Result := False;
        end;
      end;

      function TWKConnDataAccess.DeleteEntity(Entity: TObject): Boolean;
      begin
        try
          FDAO.Delete(Entity);
          Result := True;
        except
          Result := False;
        end;
      end;

      function TWKConnDataAccess.UpdateEntity(Entity: TObject): Boolean;
      begin
        try
          FDAO.Update(Entity);
          Result := True;
        except
          Result := False;
        end;
      end;

    {$ENDREGION}

    { TTokenGenerator }

    {$REGION ' TTokenGenerator '}

      class function TTokenGenerator.Base32Encode(const Data: TBytes): string;
      const
        Base32Charset: string = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
      var
        i, j, BitsToEncode: Integer;
        EncodedLength: Integer;
      begin
        EncodedLength := (((Length(Data) - 1) div 5) + 1) * 8;
        SetLength(Result, EncodedLength);

        j := 1;
        for i := 0 to Length(Data) - 1 do
        begin
          case i mod 5 of
            0:
            begin
              Result[j] := Base32Charset[(Data[i] shr 3) and $1F + 1];
              Inc(j);
              BitsToEncode := (Data[i] and $07) shl 2;
            end;
            1:
            begin
              Result[j] := Base32Charset[BitsToEncode or ((Data[i] shr 6) and $03) + 1];
              Inc(j);
              Result[j] := Base32Charset[(Data[i] shr 1) and $1F + 1];
              Inc(j);
              BitsToEncode := (Data[i] and $01) shl 4;
            end;
            2:
            begin
              Result[j] := Base32Charset[BitsToEncode or ((Data[i] shr 4) and $0F) + 1];
              Inc(j);
              BitsToEncode := (Data[i] and $0F) shl 1;
            end;
            3:
            begin
              Result[j] := Base32Charset[BitsToEncode or ((Data[i] shr 7) and $01) + 1];
              Inc(j);
              Result[j] := Base32Charset[(Data[i] shr 2) and $1F + 1];
              Inc(j);
              BitsToEncode := (Data[i] and $03) shl 3;
            end;
            4:
            begin
              Result[j] := Base32Charset[BitsToEncode or ((Data[i] shr 5) and $07) + 1];
              Inc(j);
              Result[j] := Base32Charset[Data[i] and $1F + 1];
              Inc(j);
            end;
          end;
        end;

        while (j <= EncodedLength) do
        begin
          Result[j] := '=';
          Inc(j);
        end;
      end;

      class function TTokenGenerator.GenerateSecretKey: string;
      const
        KeyLength = 10; // Defina o comprimento da chave conforme necessário
      var
        RandomBytes: TBytes;
      begin
        RandomBytes := GenerateRandomBytes(KeyLength);

        // Converte os bytes para uma representação base32
        Result := Base32Encode(RandomBytes);
      end;

      {$REGION ' Funciona Perfeitamente - Porém Com Segurança Menor '}
      {
      class function TTokenGenerator.GenerateSecretKey: string;
      var
        RandomBytes: TBytes;
        I: Integer;
      begin
        SetLength(RandomBytes, 10); // Altere o tamanho conforme necessário

        // Preenche RandomBytes com valores aleatórios
        Randomize;
        for I := Low(RandomBytes) to High(RandomBytes) do
          RandomBytes[I] := Random(256);

        // Converte os bytes para uma representação base32
        Result := Base32Encode(RandomBytes);
      end;
      }
      {$ENDREGION}

      class function TTokenGenerator.GenerateQRCodeURL(const Secret: string; AccountName: string; AppName: string = ''): string;
      begin
        Result := 'otpauth://totp/';
        if AppName <> '' then
          Result := Result + TNetEncoding.URL.Encode(AppName) + ': '
        else
          Result := Result + 'MyApp:';

        if AccountName <> '' then
          Result := Result + TNetEncoding.URL.Encode(AccountName) + '?secret=' + Secret
        else
          Result := Result + '?secret=' + Secret;
      end;

      class function TTokenGenerator.GenerateQRCodeBitmap(const Key: string): TBitmap;
      var
        QRCode: TDelphiZXingQRCode;
        Row, Column: Integer;
      begin
        QRCode := TDelphiZXingQRCode.Create;
        Result := TBitmap.Create;
        try
          QRCode.Data := Key;
          QRCode.Encoding := qrAuto;
          QRCode.QuietZone := 4;

          Result.Width := QRCode.Columns;
          Result.Height := QRCode.Rows;

          for Row := 0 to QRCode.Rows - 1 do
            for Column := 0 to QRCode.Columns - 1 do
              if QRCode.IsBlack[Column, Row] then // Invertido para corresponder à matriz de pixels
                Result.Canvas.Pixels[Column, Row] := clBlack
              else
                Result.Canvas.Pixels[Column, Row] := clWhite;
        finally
          QRCode.Free;
        end;
      end;

      class function TTokenGenerator.GenerateRandomBytes(const ByteCount: Integer): TBytes;
      var
        CryptoProvider: HCRYPTPROV;
      begin
        if CryptAcquireContext(CryptoProvider, nil, nil, PROV_RSA_FULL, CRYPT_VERIFYCONTEXT) then
        begin
          try
            SetLength(Result, ByteCount);
            if not CryptGenRandom(CryptoProvider, ByteCount, @Result[0]) then
              RaiseLastOSError;
          finally
            CryptReleaseContext(CryptoProvider, 0);
          end;
        end
        else
          RaiseLastOSError;
      end;

      class procedure TTokenGenerator.LabelClick(Sender: TObject);
      begin
        Clipboard.AsText := FTokenGenerator.FKey;
      end;

      class procedure TTokenGenerator.OnKeyDownEvent(Sender: TObject; var Key: Word; Shift: TShiftState);
      const
        VK_F1 = $70; // Código da tecla F1
        VK_F2 = $71; // Código da tecla F2
      var
        Secret: string;
      begin
        // Define o segredo (você pode obter de onde estiver armazenado)
        Secret := FTokenGenerator.FKey;

        case Key of
          VK_F1: FTokenGenerator.ValidateTokenWithDialog(Secret);
          VK_F2: FTokenGenerator.GenerateTokenWithDialog(Secret);
        end;
      end;

      class procedure TTokenGenerator.ImagesPreviewer(Imagem: TImage; const Key: string);
      var
        Panel : TPanel;
        ImagePreviewer : TImage;
        LabelPreviewer: TLabel;
        PreviewForm: TForm;
      begin
        FTokenGenerator.FKey := Key;
        PreviewForm := TForm.Create(nil);
        Panel := TPanel.Create(PreviewForm);
        ImagePreviewer := TImage.Create(Panel);
        LabelPreviewer := TLabel.Create(Panel);
        try

          PreviewForm.BorderStyle := bsDialog;
          PreviewForm.Caption     := 'Support Security | ' + FWKConnectionClass.SOFTHOUSE;
          PreviewForm.Height      := 320;
          PreviewForm.Width       := 300;
          PreviewForm.Position    := poScreenCenter;
          PreviewForm.Color       := clWhite;//$00EAEAEA;
          PreviewForm.OnKeyDown   := OnKeyDownEvent;

          Panel.Align             := alClient;
          Panel.Parent            := PreviewForm;
          Panel.BevelInner        := bvNone;
          Panel.BevelOuter        := bvNone;
          Panel.BevelKind         := bkNone;
          Panel.BorderStyle       := bsNone;
          Panel.Color             := clWhite;//$00EAEAEA;
          Panel.ParentBackground  := False;
          Panel.FullRepaint       := True;

          ImagePreviewer.Align    := alClient;
          ImagePreviewer.Parent   := Panel;
          ImagePreviewer.Picture  := Imagem.Picture;
          ImagePreviewer.Center   := True;
          ImagePreviewer.Stretch       := True;
          ImagePreviewer.Proportional  := True;
          ImagePreviewer.Transparent   := True;

          LabelPreviewer.Align    := alBottom;
          LabelPreviewer.Alignment:= taCenter;
          LabelPreviewer.Layout   := tlCenter;
          LabelPreviewer.Font.Style:= [TFontStyle.fsBold];
          LabelPreviewer.Parent   := Panel;
          LabelPreviewer.Caption  := 'GoogleAuth: ' + Key;
          LabelPreviewer.OnClick  := LabelClick;
          LabelPreviewer.Color    := clWhite;//$00EAEAEA;

          PreviewForm.ShowModal;
        finally
          PreviewForm.Free;
        end;

      end;

      class procedure TTokenGenerator.ShowQRCode;
      var
        SecretKey: string;
        QRCodeBitmap: TBitmap;
        Image: TImage;
      begin

        Image := TImage.Create(nil);

        try

          SecretKey := GenerateSecretKey;
          QRCodeBitmap := GenerateQRCodeBitmap(GenerateQRCodeURL(SecretKey, FWKConnectionClass.SOFTHOUSE, FWKConnectionClass.NOMEDOSISTEMA));

          Image.Picture.Assign(QRCodeBitmap);

          ImagesPreviewer(Image, SecretKey);

        finally

          QRCodeBitmap.Free;

          Image.Free;

        end;

      end;

      class procedure TTokenGenerator.ValidateTokenWithDialog(const Secret: string);
      var
        TokenInput: string;
        Token: UInt32;
        IsValid: Boolean;
      begin
        // Exibe uma caixa de diálogo para inserir o token
        TokenInput := InputBox('Validar Token', 'Insira o token:', '');

        // Verifica se foi digitado algo na caixa de diálogo
        if TokenInput <> '' then
        begin
          // Converte o token digitado para UInt32
          Token := StrToIntDef(TokenInput, 0);

          // Valida o token inserido
          IsValid := ValidateTOPT(Secret, Token);

          // Exibe o resultado da validação
          if IsValid then
            ShowMessage('Token válido!')
          else
            ShowMessage('Token inválido!');
        end;
      end;

      class procedure TTokenGenerator.GenerateTokenWithDialog(const Secret: string);
      begin

        ShowMessage('Token TOTP gerado: ' + CalculateOTP(Secret).ToString);

      end;

    {$ENDREGION}

    { TProgressBarUpdater }

    {$REGION ' TProgressBarUpdater '}

      constructor TProgressBarUpdater.Create;
      begin
        FPreviewForm := nil;
        FProgressBar := nil;
        FLabelMessage := nil;
        FAutoClose := False;
        FTerminateEvent := TEvent.Create;
      end;

      destructor TProgressBarUpdater.Destroy;
      begin
        FreeAndNil(FTerminateEvent);
        FreeAndNil(FPreviewForm);
        inherited;
      end;

      procedure TProgressBarUpdater.UpdateProgress(Position: Integer; const Message: string);
      begin
        if Assigned(FProgressBar) and Assigned(FLabelMessage) then
        begin
          TThread.Queue(nil,
            procedure
            begin
              FProgressBar.Position := Position;
              FLabelMessage.Caption := Message;
            end
          );
        end;
      end;

      procedure TProgressBarUpdater.CloseForm(Sender: TObject);
      begin
        TThread.Queue(nil,
          procedure
          begin
            FPreviewForm.Close;
          end
        );
      end;

      procedure TProgressBarUpdater.FormCloseQuery(Sender: TObject; var CanClose: Boolean);
      begin
        CanClose := FAutoClose;
      end;

      procedure TProgressBarUpdater.ProcessThreadExecute;
      begin
        // Simule o processo demorado e atualize o progresso conforme necessário
        for var i := 0 to 100 do
        begin
          if FTerminateEvent.WaitFor(0) = wrSignaled then
            Break; // Verifica se o evento de término foi sinalizado

          TThread.Queue(nil,
            procedure
            begin
              UpdateProgress(i, 'Processing Step ' + IntToStr(i));
            end
          );

          Sleep(100);
        end;

        // Fecha o formulário quando o processo é concluído
        TThread.Queue(nil,
          procedure
          begin
            CloseForm(nil);
          end
        );
      end;

      procedure TProgressBarUpdater.StartProgressBar(Min, Max, Interval, Width, Height: Integer; AutoClose: Boolean = False);
      begin
        FAutoClose := AutoClose;

        FPreviewForm := TForm.Create(nil);
        FProgressBar := TProgressBar.Create(FPreviewForm);
        FLabelMessage := TLabel.Create(FPreviewForm);

        FPreviewForm.BorderStyle := bsNone;
        FPreviewForm.Caption := 'Progress Preview';
        FPreviewForm.Height := Height;
        FPreviewForm.Width := Width;
        FPreviewForm.Position := poScreenCenter;

        // Alteração aqui - remova a linha a seguir
        // FPreviewForm.OnClose := CloseForm;

        FProgressBar.Parent := FPreviewForm;
        FProgressBar.Align := alTop;
        FProgressBar.Min := Min;
        FProgressBar.Max := Max;
        FProgressBar.Width := Width;
        FProgressBar.Height := Height - FLabelMessage.Height;
        FProgressBar.Step := Interval;

        FLabelMessage.Parent := FPreviewForm;
        FLabelMessage.Height := 30;
        FLabelMessage.Align := alClient;
        FLabelMessage.Alignment := taCenter;
        FLabelMessage.Layout := tlCenter;

        // Adição aqui - atribua o evento OnCloseQuery
        FPreviewForm.OnCloseQuery := FormCloseQuery;

        // Inicia um thread separado para realizar o processo demorado
        FProcessThread := TThread.CreateAnonymousThread(ProcessThreadExecute);
        FProcessThread.FreeOnTerminate := True;
        FProcessThread.Start;

        FPreviewForm.ShowModal;
      end;

      procedure TProgressBarUpdater.UpdateProgressBar(Position: Integer; const Message: string);
      begin
        UpdateProgress(Position, Message);
      end;

      procedure TProgressBarUpdater.CloseProgressBar;
      begin
        if Assigned(FPreviewForm) then
          FPreviewForm.Close;
      end;

    {$ENDREGION}

    { TReadClientesAutorizados }

    {$REGION ' TReadClientesAutorizados '}

    function TReadClientesAutorizados.ConsultaMaquinaAutorizada
      (const Chave: string): Boolean;
    begin
      Result := False;
      Ws_Maquina_Cadastrada := False;
      Ws_Maquina_Bloqueada := True;

      if Chave = '' then
        raise Exception.Create('Chave da Máquina não atribuido ou não encontrado.');
      // if not (ComputerAutorizados.Active) then
      // raise Exception.Create('Nenhuma máquina listada para essa chave');
      if ComputerAutorizados.Active then
      begin
        if ComputerAutorizados.Locate('CHAVE', Chave, []) then
        begin
          Ws_Maquina_Cadastrada := True;
          Ws_Maquina_Bloqueada := Trim(ComputerAutorizados.FieldByName('BLOQUEADO')
            .AsString) = 'S';
          Result := True;
        end;
      end;
    end;

    procedure TReadClientesAutorizados.ConsultaWS(const CNPJ: String;
      aDataset: TDataSet);
    var
      JsonWS: string;
    begin
      verificarURLWs;
      // consulta o JSON no WS
      JsonWS := getJSONLicensas(CNPJ);
      if JsonWS <> '' then
      begin
        SetRetornoWS(JsonWS);
        if Self.WS_STATUS > 0 then
        begin
          JsonToDataset(aDataset, Self.Computadores_arrayJson);
          ComputerAutorizados := aDataset;
          // para consulta se a maquina foi autorizada para uso
        end;
      end;
    end;

    constructor TReadClientesAutorizados.Create(UrlWs: String);
    begin
      Self.UrlWs := UrlWs;
    end;

    function TReadClientesAutorizados.getJSONLicensas(const CNPJ: String): String;
    var
      JsonStream: TStringStream;
      url: String;
    begin
      Result := '';
      JsonStream := TStringStream.Create('');
      try
        IdHTTP := TIdHTTP.Create(nil);
        if pos('https', Self.UrlWs) > 0 then
        begin
          url := 'http' + Copy(Self.UrlWs, pos('https', Self.UrlWs) + 5,
            Length(Self.UrlWs));
          url := url + 'clientes.php?cnpj=' + Trim(CNPJ);
        end
        else
          url := Trim(Self.UrlWs) + 'clientes.php?cnpj=' + Trim(CNPJ);
        // StringReplace(url, 'https', 'http', []);
        IdHTTP.ReadTimeout := 5000;
        // IdHttp.OnWorkBegin := WorkBegin;
        // IdHttp.OnWorkEnd   := WorkEnd;
        IdHTTP.ReadTimeout := 12000;
        try
          IdHTTP.Get(url, JsonStream);
          Self.WS_RETORNO := True;
        except
          on E: Exception do
          begin
            // raise Exception.Create('Erro ao consultar chave: ' + E.Message);
            Result := '';
            Self.WS_RETORNO := False;
            Exit; // raise Exception.Create('Erro na conexão com servidor de licenças.');
          end;
        end;
        Result := JsonStream.DataString;
      finally
        JsonStream.Free;
        IdHTTP.Free;
      end;
    end;

    procedure TReadClientesAutorizados.JsonToDataset(aDataset: TDataSet;
      aJSON: TJSONArray);
    var
      JObj: TJSONArray;
      vConv: TCustomJSONDataSetAdapter;
    begin
      { if (aJSON = EmptyStr) then
        begin
        Exit;
        end; }
      // JObj := TJSONObject.ParseJSONValue(aJSON) as TJSONArray;
      JObj := aJSON;
      vConv := TCustomJSONDataSetAdapter.Create(Nil);
      try
        vConv.Dataset := aDataset;
        vConv.UpdateDataSet(JObj);
      finally
        vConv.Free;
        JObj.Free;
      end;
    end;

    procedure TReadClientesAutorizados.SetComputadores_arrayJson
      (const Value: TJSONArray);
    begin
      FComputadores_arrayJson := Value;
    end;

    procedure TReadClientesAutorizados.SetComputerAutorizados
      (const Value: TDataSet);
    begin
      FComputerAutorizados := Value;
    end;

    procedure TReadClientesAutorizados.SetRetornoWS(JSON_Retorno: String);
    var
      jsonObj: TJSONObject;
      jv: TJSONValue;
    begin
      jsonObj := TJSONObject.ParseJSONValue(TEncoding.ASCII.GetBytes(JSON_Retorno),
        0) as TJSONObject;
      // Atribui os valores para consulta
      try
        Self.WS_STATUS := jsonObj.GetValue<Integer>('STATUS');
      except
        Self.WS_STATUS    := 0;
        Self.WS_CNPJ      := '';
        Self.WS_ATIVO     := 'S';
        Self.WS_MESSAGE   := 'Cliente localizado!!!';
        Self.WS_BLOQUEADO := 'N';
        Self.WS_DIAVENC   := DayOfWeek(Now) + 5;
      end;

      if Self.WS_STATUS > 0 then
      begin
        Self.WS_CNPJ := jsonObj.GetValue<string>('CNPJ');
        Self.WS_ATIVO := jsonObj.GetValue<string>('ATIVO');
        Self.WS_MESSAGE := jsonObj.GetValue<string>('MESSAGE');
        Self.WS_BLOQUEADO := jsonObj.GetValue<string>('BLOQUEADO');
        Self.WS_DIAVENC := jsonObj.GetValue<Integer>('DIAVENC');
        jv := jsonObj.Get('COMPUTADORES').JsonValue;
        Self.Computadores_arrayJson := jv as TJSONArray;
      end;

    end;

    procedure TReadClientesAutorizados.SetUrlWS(const Value: String);
    begin
      FUrlWS := Value;
    end;

    procedure TReadClientesAutorizados.SetWS_ATIVO(const Value: string);
    begin
      FWS_ATIVO := Value;
    end;

    procedure TReadClientesAutorizados.SetWS_BLOQUEADO(const Value: string);
    begin
      FWS_BLOQUEADO := Value;
    end;

    procedure TReadClientesAutorizados.SetWS_CNPJ(const Value: string);
    begin
      FWS_CNPJ := Value;
    end;

    procedure TReadClientesAutorizados.SetWS_COMPUTADORES(const Value: string);
    begin
      FWS_COMPUTADORES := Value;
    end;

    procedure TReadClientesAutorizados.SetWS_DIAVENC(const Value: Integer);
    begin
      FWS_DIAVENC := Value;
    end;

    procedure TReadClientesAutorizados.SetWs_Maquina_Bloqueada
      (const Value: Boolean);
    begin
      FWs_Maquina_Bloqueada := Value;
    end;

    procedure TReadClientesAutorizados.SetWs_Maquina_Cadastrada
      (const Value: Boolean);
    begin
      FWs_Maquina_Cadastrada := Value;
    end;

    procedure TReadClientesAutorizados.SetWS_MESSAGE(const Value: string);
    begin
      FWS_MESSAGE := Value;
    end;

    procedure TReadClientesAutorizados.SetWS_RETORNO(const Value: Boolean);
    begin
      FWS_RETORNO := Value;
    end;

    procedure TReadClientesAutorizados.SetWS_STATUS(const Value: Integer);
    begin
      FWS_STATUS := Value;
    end;

    procedure TReadClientesAutorizados.verificarURLWs;
    var
      Tamanho: Integer;
    begin
      if Self.UrlWs = '' then
        raise Exception.Create
          ('URL do WS de licenças não informada, entre em contato com suporte.');
      Tamanho := Length(Self.UrlWs);
      if Copy(Self.UrlWs, Tamanho, 1) <> '/' then
        raise Exception.Create
          ('URL do WS de licenças incorreta [ no final da url deve conter caractere (barra) "/" ], entre em contato com suporte.');
    end;

    {$ENDREGION}

    { TWriteBaseAuth }

    {$REGION ' TWriteBaseAuth '}

    constructor TWriteBaseAuth.Create(UrlWs: String);
    begin
      Self.UrlWs := UrlWs;
      IdHTTP := TIdHTTP.Create(nil);
    end;

    procedure TWriteBaseAuth.SetUrlWS(const Value: String);
    begin
      FUrlWS := Value;
    end;

    {$ENDREGION}

    { TWriteClientsAuth }

    {$REGION ' TWriteClientsAuth '}

    function TWriteClientsAuth.InsertClient(const ClientJson: string): Boolean;
    var
      JsonStream: TStringStream;
      Response, url: string;
    begin
      Result := False;

      JsonStream := TStringStream.Create(ClientJson, TEncoding.UTF8);

      if pos('https', Self.UrlWs) > 0 then
      begin
        url := 'http' + Copy(Self.UrlWs, pos('https', Self.UrlWs) + 5, Length(Self.UrlWs));
      end else
        url := Self.UrlWs;

      try

        try

          IdHTTP.Request.ContentType := 'application/json';
          Response := IdHTTP.Post(url + 'enviar_dados_cliente.php', JsonStream);
          Result := ContainsText(Response, '{"MESSAGE":"Dados do cliente enviados com sucesso."}');

        except

          on E: Exception do
            // Aqui você pode adicionar qualquer tratamento de erro específico ou log que desejar
            Writeln(E.Message); // Exemplo: escreve a mensagem de erro na saída padrão

        end;

      finally

        JsonStream.Free;

      end;

      {$REGION ' Desabilitado '}
      {
      Result := False;
      JsonStream := TStringStream.Create(ClientJson, TEncoding.UTF8);
      try
        Response := IdHTTP.Post(Self.UrlWs + 'enviar_dados_cliente.php', JsonStream);
        if ContainsText(Response, '"MESSAGE": "Cliente inserido com sucesso."') then
          Result := True;
      finally
        JsonStream.Free;
      end;
      }
      {$ENDREGION}

    end;

    {$ENDREGION}

    { TWriteDevicesAuth }

    {$REGION ' TWriteDevicesAuth '}

    function TWriteDevicesAuth.InsertDevice(const DeviceJson: string): Boolean;
    var
      JsonStream: TStringStream;
      Response, url: string;
    begin
      Result := False;
      JsonStream := TStringStream.Create(DeviceJson, TEncoding.UTF8);

      if pos('https', Self.UrlWs) > 0 then
      begin
        url := 'http' + Copy(Self.UrlWs, pos('https', Self.UrlWs) + 5, Length(Self.UrlWs));
      end else
        url := Self.UrlWs;

      try
        try
          IdHTTP.Request.ContentType := 'application/json';
          Response := IdHTTP.Post(url + 'enviar_dados_equipamento.php', JsonStream);
          Result := ContainsText(Response, '{"MESSAGE":"Equipamento inserido com sucesso."}');
        except
          on E: Exception do
            // Aqui você pode adicionar qualquer tratamento de erro específico ou log que desejar
            Writeln(E.Message); // Exemplo: escreve a mensagem de erro na saída padrão
        end;
      finally
        JsonStream.Free;
      end;

    end;

      {$REGION 'Desabilitado'}
      {
      function TWriteDevicesAuth.InsertDevice(const DeviceJson: string): Boolean;
      var
        JsonStream: TStringStream;
        Response, url: string;
      begin

        Result := False;
        JsonStream := TStringStream.Create(DeviceJson, TEncoding.UTF8);

        if pos('https', Self.UrlWs) > 0 then
        begin
          url := 'http' + Copy(Self.UrlWs, pos('https', Self.UrlWs) + 5, Length(Self.UrlWs));
        end else
          url := Self.UrlWs;

        try
          Response := IdHTTP.Post( url + 'enviar_dados_equipamento.php', JsonStream);
          if ContainsText(Response, '"MESSAGE": "Equipamento inserido com sucesso."') then
            Result := True;
        finally
          JsonStream.Free;
        end;
      end;
      }
      {$ENDREGION}

    {$ENDREGION}

initialization;
    FWKConnectionClass := TWKConnectionClass.Create;

finalization;
    FWKConnectionClass.Free;

{$HINTS ON}

end.
