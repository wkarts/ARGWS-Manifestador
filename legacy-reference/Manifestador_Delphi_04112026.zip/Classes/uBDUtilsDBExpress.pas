unit uBDUtilsDBExpress;

interface
uses
  db, controls, SysUtils, Forms, Windows, dbCLient, uBDUtils, Contnrs, 
  Uni;


type

  TTransacao = class (TObject)
  public

    //TransDesc : TFDDBXTransactionDesc;
    //constructor Create(TransDesc : TFDDBXTransactionDesc);

  end;

  TListaTransacoes = class (TOBjectList)
  public

    //Function ObterTransDesc (IdTransacao : Integer) : TFDDBXTransactionDesc;
    //procedure RemoverTransDesc(IdTransacao: integer);

  end;



  TBDUtilsDBExpress = class(TBDUtils)
  private
    ListaTransacoesAtivas : TListaTransacoes;
  public
    function CriarQuery (Query: String; Parametros: array of variant) : TDataSet; override;
    function CriarStoredProcedure (NomeStoredProcedure: String; Parametros: array of variant): TDataSet; override;
    function ExecutarSQL (Query: String; Parametros: array of variant; lancarExcecao : Boolean = FALSE): Integer; override;

    function ObterValorCampo (ExprSQL: String; ValorDefault : String) : String;  overload; override;
    function ObterValorCampo (ExprSQL: String; ValorDefault : Integer) : Integer; overload; override;
    function ObterValorCampo (ExprSQL: String; ValorDefault : Double) : Double; overload; override;
    function ObterValorCampo (ExprSQL: String; ValorDefault : Boolean) : Boolean; overload; override;
    function ObterValorCampoData (ExprSQL: String; ValorDefault : TDate) : TDate; override;
    function ObterValorGenerator(NomeGenerator: string; Incremento: integer = 1): integer; override;
    procedure IniciarTransacao(IDTransacao: integer = 1; NivelIsolamento: TBdUtTransIsolationLevel = tilREADCOMMITTED); override;
    procedure ConfirmarTransacao(IDTransacao : Integer = 1); override;
    procedure CancelarTransacao(IDTransacao : Integer = 1); override;
    function EmTransacao(IDTransacao: Integer = 1): boolean; override;
    constructor Create;
    destructor Destroy; override;
  end;

implementation



{ TBDUtilsDBExpress }

function TBDUtilsDBExpress.CriarQuery(Query: String; Parametros: array of variant) : TDataSet;
var
  SQLQuery: TUniQuery;
  i, Count: integer;
  Comando: string;
begin
  SQLQuery := TUniQuery.Create(nil);
  with SQLQuery do
  begin
    Tag := 999999;
    Connection := FConexao As TUniConnection;
    SQL.Add(Query);
    Count := Length(Parametros);
    for i := 0 to Count - 1 do
    begin
      if Params[i].DataType = ftBlob then
        Params[i].AsBlob := Parametros[i]
      else
        Params[i].value := Parametros[i];
    end;

    Comando := Copy(Trim(UpperCase(Query)), 1, 6);
    if Comando = 'SELECT' then
      Open;
    Result := SQLQuery;
  end;

end;

function TBDUtilsDBExpress.CriarStoredProcedure(
  NomeStoredProcedure: String; Parametros: array of variant): TDataSet;
var
  SQLStoredProc: TUniStoredProc;
  i, Count: integer;
begin
  SQLStoredProc := TUniStoredProc.Create(nil);
  with SQLStoredProc do
  begin
    Connection  := FConexao as TUniConnection;
    StoredProcName := NomeStoredProcedure;
    Count := Length(Parametros);
    for i := 0 to Count - 1 do
      Params[i].Value := Parametros[i];
    Result := SQLStoredProc;
  end;

end;

function TBDUtilsDBExpress.ExecutarSQL(Query: String;
  Parametros: array of variant; lancarExcecao: Boolean): Integer;
var
  SQLQuery: TUniQuery;
  i, Count, iValue, iCode: integer;
  s: String;
begin

  Result   := 0;
  SQLQuery := TUniQuery.Create(nil);

  try

    with SQLQuery do
    begin

      Connection := FConexao as TUniConnection;
      SQLCommand := Query;
      SQL.Add(Query);
      Count := Length(Parametros);

      for i := 0 to Count - 1 do
      begin

        if Params[i].DataType = ftBlob then
          Params[i].AsBlob := Parametros[i]
        else
        if (Params[i].DataType = ftInteger) then
          Params[i].AsInteger := StrToInt(Parametros[i])
        else
        if (Params[i].DataType = ftUnknown) then
        begin

          s := Parametros[i];
          Val(s, iValue, iCode);

          if (iCode = 0) then
            Params[i].AsInteger := StrToInt(Parametros[i])
          else
            Params[i].value := Parametros[i];

        end
        else
          Params[i].value := Parametros[i];

      end;

      ExecSQL;
      Result := RowsAffected;

    end;

    SQLQuery.Free;

  except

    on E:exception do
    begin

      SQLQuery.Free;

      if (not LancarExcecao) then
        Application.MessageBox(PChar(E.Message), 'Erro', MB_ICONERROR)
      else
        Raise;

    end;

  end;
end;



function TBDUtilsDBExpress.ObterValorCampo(ExprSQL,
  ValorDefault: String): String;
var
  SQLQuery: TUniQuery;
begin
  Result := '';
  try
    try
      SQLQuery := CriarQuery(ExprSQL, []) As TUniQuery;
      Result   := SQLQuery.Fields[0].AsString;
    except
      on E:exception do
      begin
        Application.MessageBox(PChar(E.Message), 'Erro', MB_ICONERROR);
      end;
    end;
  finally
    FreeAndNil(SQLQuery);
  end;
end;


function TBDUtilsDBExpress.ObterValorCampoData(ExprSQL: String;
  ValorDefault: TDate): TDate;
var
  SQLQuery: TUniQuery;
begin
  Result := 0;
  try
    try
      SQLQuery := CriarQuery(ExprSQL, []) As TUniQuery;
      Result   := SQLQuery.Fields[0].AsDateTime;
    except
      on E:exception do
      begin
        Application.MessageBox(PChar(E.Message), 'Erro', MB_ICONERROR);
      end;
    end;
  finally
    FreeAndNil(SQLQuery);
  end;
end;


function TBDUtilsDBExpress.ObterValorCampo(ExprSQL: String;
  ValorDefault: Boolean): Boolean;
var
  SQLQuery: TUniQuery;
begin
  Result := False;
  try
    try
      SQLQuery := CriarQuery(ExprSQL, []) As TUniQuery;
      Result   := SQLQuery.Fields[0].AsBoolean;
    except
      on E:exception do
      begin
        Application.MessageBox(PChar(E.Message), 'Erro', MB_ICONERROR);
      end;
    end;
  finally
    FreeAndNil(SQLQuery);
  end;
end;


function TBDUtilsDBExpress.ObterValorCampo(ExprSQL: String;
  ValorDefault: Integer): Integer;
var
  SQLQuery: TUniQuery;
begin
  Result := 0;
  try
    try
      SQLQuery := CriarQuery(ExprSQL, []) As TUniQuery;
      if (not SQLQuery.Fields[0].IsNull) then
        Result := SQLQuery.Fields[0].AsInteger;
    except
      on E:exception do
      begin
        Application.MessageBox(PChar(E.Message), 'Erro', MB_ICONERROR);
      end;
    end;
  finally
    FreeAndNil(SQLQuery);
  end;
end;


function TBDUtilsDBExpress.ObterValorCampo(ExprSQL: String;
  ValorDefault: Double): Double;
var
  SQLQuery: TUniQuery;
begin
  Result := 0;
  try
    try
      SQLQuery := CriarQuery(ExprSQL, []) As TUniQuery;
      Result   := SQLQuery.Fields[0].AsFloat;
    except
      on E:exception do
      begin
        Application.MessageBox(PChar(E.Message), 'Erro', MB_ICONERROR);
      end;
    end;
  finally
    FreeAndNil(SQLQuery);
  end;
end;


procedure TBDUtilsDBExpress.IniciarTransacao(IDTransacao: integer = 1; NivelIsolamento: TBdUtTransIsolationLevel = tilREADCOMMITTED);
//var
//  transDesc : TFDDBXTransactionDesc;
begin

  {
  transDesc.TransactionID  := IDTransacao;
  case NivelIsolamento of
    tilREADCOMMITTED  : transDesc.IsolationLevel := xiReadCommitted;
    tilREPEATABLEREAD : transDesc.IsolationLevel := xiRepeatableRead;
    tilDIRTYREAD      : transDesc.IsolationLevel := xiDirtyRead;
    tilCUSTOM         : transDesc.IsolationLevel := xiReadCommitted;
  end;
  }
  //ListaTransacoesAtivas.Add(TTransacao.Create(transDesc));
  (FConexao as TUniConnection).StartTransaction;

end;


procedure TBDUtilsDBExpress.ConfirmarTransacao(IDTransacao : Integer = 1);
//var
//  transDesc : TFDDBXTransactionDesc;
begin
//  transDesc := ListaTransacoesAtivas.ObterTransDesc(IDTransacao);
//  ListaTransacoesAtivas.RemoverTransDesc(IDTransacao);
  (FConexao as TUniConnection).Commit;
end;


procedure TBDUtilsDBExpress.CancelarTransacao(IDTransacao : Integer = 1);
//var
// transDesc : TFDDBXTransactionDesc;
begin
  //transDesc := ListaTransacoesAtivas.ObterTransDesc(IDTransacao);
  //ListaTransacoesAtivas.RemoverTransDesc(IDTransacao);
  (FConexao as TUniConnection).Rollback;
end;


function TBDUtilsDBExpress.ObterValorGenerator(NomeGenerator: string;
  Incremento: integer): integer;
var
  SQLQuery: TUniQuery;
begin
  Result := 0;
  try
    try
      SQLQuery := CriarQuery('SELECT FIRST 1 CAST(GEN_ID(' + NomeGenerator + ', ' + IntToStr(Incremento)+') AS INTEGER) AS NOVASEQUENCIA '+
                             '  FROM RDB$DATABASE',
                             []) As TUniQuery;
      Result   := SQLQuery.Fields[0].AsInteger;
    except
      on E:exception do
      begin
        Application.MessageBox(PChar(E.Message), 'Erro', MB_ICONERROR);
      end;
    end;
  finally
    FreeAndNil(SQLQuery);
  end;
end;


constructor TBDUtilsDBExpress.Create;
begin
  Self.ListaTransacoesAtivas := TListaTransacoes.Create(True);
end;

destructor TBDUtilsDBExpress.Destroy;
begin
  FreeAndNil(ListaTransacoesAtivas);
  inherited;
end;

function TBDUtilsDBExpress.EmTransacao(IDTransacao: Integer): boolean;
//var
//  transDesc : TFDDBXTransactionDesc;
begin
  try
    //transDesc := ListaTransacoesAtivas.ObterTransDesc(IDTransacao);
    Result    := True;
  except
   Result := False; 
  end;
end;

{ TTransacao }
{
constructor TTransacao.Create(TransDesc: TFDDBXTransactionDesc);
begin
   Self.TransDesc := TransDesc;
end;
}


{ TListaTransacoes }

{
function TListaTransacoes.ObterTransDesc(IdTransacao: Integer): TFDDBXTransactionDesc;
var
  i : Integer;
  achouTransacaoAtiva : Boolean;
begin
  achouTransacaoAtiva := False;
  for i := 0 to Self.Count - 1 do
  begin
    if (TTransacao(Self.GetItem(i)).TransDesc.TransactionID = IdTransacao) then
    begin
      Result := TTransacao(Self.GetItem(i)).TransDesc;
      achouTransacaoAtiva := True;
      break;
    end;
  end;
  if (not achouTransacaoAtiva) then
    Raise Exception.Create('N�o foi encontrada uma transa��o ativa com o ID = '+IntToStr(IdTransacao));
end;

procedure TListaTransacoes.RemoverTransDesc(IdTransacao: integer);
var
  i : Integer;
  achouTransacaoAtiva : Boolean;
begin
  achouTransacaoAtiva := False;
  for i := 0 to Self.Count - 1 do
  begin
    if (TTransacao(Self.GetItem(i)).TransDesc.TransactionID = IdTransacao) then
    begin
      //Result := TTransacao(Self.GetItem(i)).TransDesc;
      Self.Delete(i);
      achouTransacaoAtiva := True;
      break;
    end;
  end;
  if (not achouTransacaoAtiva) then
    Raise Exception.Create('N�o foi encontrada uma transa��o ativa com o ID = '+IntToStr(IdTransacao));
end;
}

end.

