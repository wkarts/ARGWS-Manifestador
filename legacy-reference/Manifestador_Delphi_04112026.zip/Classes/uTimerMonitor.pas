unit uTimerMonitor;

interface

uses
  SysUtils, Classes, ExtCtrls, Controls, Windows, TypInfo;

type
  TTimerMonitor = class(TComponent)
  private
    FTimer: TTimer;
    FOwnerCaption: TObject;
    FOnTimeRemainingUpdate: TNotifyEvent;
    function GetTimeRemaining: Integer;
    procedure TimerTick(Sender: TObject);
  protected
    procedure DoTimeRemainingUpdate;
  public
    constructor Create(AOwner: TComponent); override;
    destructor Destroy; override;
    procedure UpdateTimeRemainingAndCaption;
    property OnTimeRemainingUpdate: TNotifyEvent read FOnTimeRemainingUpdate write FOnTimeRemainingUpdate;
  end;

function GetTimeRemainingForTimer(Timer: TTimer; OwnerCaption: TObject): TTimerMonitor;

implementation

function GetTimeRemainingForTimer(Timer: TTimer; OwnerCaption: TObject): TTimerMonitor;
begin
  Result := TTimerMonitor.Create(nil);
  Result.FTimer := Timer;
  Result.FOwnerCaption := OwnerCaption;
end;

constructor TTimerMonitor.Create(AOwner: TComponent);
begin
  inherited;
  FTimer := TTimer.Create(Self);
  FTimer.Enabled := False;
  FTimer.OnTimer := TimerTick;
end;

destructor TTimerMonitor.Destroy;
begin
  FTimer.Free;
  inherited;
end;

procedure TTimerMonitor.DoTimeRemainingUpdate;
begin
  if Assigned(FOnTimeRemainingUpdate) then
    FOnTimeRemainingUpdate(Self);
end;

function TTimerMonitor.GetTimeRemaining: Integer;
begin
  if FTimer.Enabled then
    Result := FTimer.Interval - (GetTickCount - FTimer.Tag)
  else
    Result := 0;
end;

procedure TTimerMonitor.TimerTick(Sender: TObject);
begin
  UpdateTimeRemainingAndCaption;
  DoTimeRemainingUpdate;
end;

procedure TTimerMonitor.UpdateTimeRemainingAndCaption;
var
  APropInfo, BPropInfo: PPropInfo;
begin
  if Assigned(FOwnerCaption) and (FOwnerCaption is TControl) then
  begin
    APropInfo := GetPropInfo(TControl(FOwnerCaption).ClassInfo, 'Caption');
    if Assigned(APropInfo)
       //and (PropInfo^.PropType^.Kind = tkString)
    then
    begin

      // Configura a propriedade Caption com o tempo restante
      SetStrProp(FOwnerCaption, APropInfo, 'Tempo restante: ' + IntToStr(GetTimeRemaining) + ' ms');

      BPropInfo := GetPropInfo(TControl(FOwnerCaption).ClassInfo, 'Visible');

      // Configura a propriedade Visible como True, se existir
      if Assigned(BPropInfo)
         //and (BPropInfo^.PropType^.Kind = tkEnumeration)
      then
        SetOrdProp(FOwnerCaption, BPropInfo, Integer(True)); // Configura Visible como True


      ;
    end;
  end;
end;

end.
