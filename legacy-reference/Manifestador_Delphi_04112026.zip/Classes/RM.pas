unit RM;

interface

uses
  Classes, Contnrs;

type

  TRMEmit = class

  public

    Codigo: Integer;
    CNPJ: String;
    IE: String;
    xNome: String;
    xFant: string;
    xLgr: string;
    nro: Integer;
    xCpl: string;
    xBairro: string;
    cMun: Integer;
    xMun: String;
    UF: String;
    CEP: Integer;
    cPais: Integer;
    XPais: String;
    Fone: String;

  end;

  TRMTransp = class

  public

    Codigo: Integer;
    CNPJ: String;
    IE: String;
    xNome: String;
    xLgr: string;
    xMun: String;
    UF: String;

  end;

  TRMProduto = class

  public

    IdProduto: Integer;
    IdFabricante: Integer;
    nItem: Integer;
    cProd: String;
    xProd: String;
    NCM: String;
    IdNCM: Integer;
    CFOP: String;
    uCom: String;
    qCom: Double;
    vUnCom: Currency;
    vProd: Currency;
    uTrib: String;
    qTrib: Double;
    vUnTrib: Currency;
    orig: Integer;
    CST: String;
    vBCICMS: Currency;
    pICMS: Currency;
    vICMS: Currency;
    pIPI: Currency;
    vIPI: Currency;
    pICMSST: Currency;
    vICMSST: Currency;
    vBCICMSST: Currency;

  end;

  TRMFatura = class

  public

    nDup: String;
    dVenc: TDateTime;
    vDup: Currency;

  end;

  TRM = class

  public

    Id: Integer;
    IdEmpresa: Integer;
    Status: String;
    TipoDocumento: String;
    Usuario: String;
    IdLocalidade: Integer;
    Emitente: TRMEmit;
    Transportadora: TRMTransp;
    CNPJDest: String;
    ChaveNF: String;
    NSU: String;
    Numero: Integer;
    Modelo: Integer;
    Serie: Integer;
    DataEmissao: TDateTime;
    Total: Currency;
    TotalProdutos: Currency;
    Frete: Currency;
    Despesas: Currency;
    Descontos: Currency;
    IPI: Currency;
    ICMS: Currency;
    ICMSST: Currency;
    SubstPagar: Currency;
    CFOP: String;
    LocalidadeEstoque: Integer;
    MovimentarEstoque: Boolean;
    Produtos: TObjectList;
    Faturas: TObjectList;

    constructor Create;
    destructor Free;

  end;

implementation

{ TRM }

constructor TRM.Create;
begin

  Emitente := TRMEmit.Create;
  Transportadora := TRMTransp.Create;
  Produtos := TObjectList.Create;
  Faturas := TObjectList.Create;

end;

destructor TRM.Free;
begin

  Emitente.Free;
  Transportadora.Free;
  Produtos.Clear;
  Produtos.Free;
  Faturas.Clear;
  Faturas.Free;

end;

end.
