unit uBDUtilsFactory;

interface
uses
  db, controls, SysUtils,
  uBDUtilsDBExpress, uBDUtils;

type

  TBDUtilsFactory = class(TObject)
  public
    class function BuildBDUtils(bdUtilsType : TBDUtilsType) : TBDUtils;
  end;

implementation

{ TBDUtilsFactory }

class function TBDUtilsFactory.BuildBDUtils(
  bdUtilsType: TBDUtilsType): TBDUtils;
begin
  Result := nil;
  case bdUtilsType of
    bdutDBExpress : Result := TBDUtilsDBExpress.Create;
    bdutIBX       : Raise Exception.Create('Estrutura ainda n�o foi desenvolvida para IBX');
  end;
end;

end.
