unit UniQueryAnalyzer;

interface

uses
  Uni, SysUtils, StrUtils;

type
  TUniQueryAnalyzer = class
  private
    FUniQuery: TUniQuery;
    function ExtractTableName(const SQL: string): string;
  public
    constructor Create(AUniQuery: TUniQuery);
    function GetPrimaryKey: string;
    function GetTableName: string;
  end;

implementation

constructor TUniQueryAnalyzer.Create(AUniQuery: TUniQuery);
begin
  inherited Create;

  if not Assigned(AUniQuery) then
    raise Exception.Create('FUniQuery n�o pode ser nil.');

  FUniQuery := AUniQuery;

  if not FUniQuery.Connection.Connected then
    raise Exception.Create('FUniQuery n�o est� conectado ao banco de dados.');
end;

function TUniQueryAnalyzer.ExtractTableName(const SQL: string): string;
var
  StartPos, EndPos, i: Integer;
  TempSQL: string;
begin
  TempSQL := Trim(SQL); // Remove espa�os e quebras de linha antes e depois

  StartPos := Pos('FROM', UpperCase(TempSQL));
  if StartPos = 0 then Exit(''); // Retorna uma string vazia se 'FROM' n�o for encontrado
  Inc(StartPos, 4); // Avan�a a posi��o de in�cio al�m da palavra 'FROM'

  // Ignora espa�os e quebras de linha ap�s "FROM"
  while (StartPos <= Length(TempSQL)) and
        ((TempSQL[StartPos] = ' ') or
         (TempSQL[StartPos] = #$D) or
         (TempSQL[StartPos] = #$A)) do
    Inc(StartPos);

  // Procura o final do nome da tabela
  EndPos := StartPos;
  while (EndPos <= Length(TempSQL)) and
        not(TempSQL[EndPos] in [' ', #$D, #$A, ',', ';']) do
  begin
    Inc(EndPos);
  end;

  Result :=  UpperCase(Copy(TempSQL, StartPos, EndPos - StartPos));
end;


{
function TUniQueryAnalyzer.ExtractTableName(const SQL: string): string;
var
  StartPos: Integer;
  EndPos: Integer;
  TempSQL: string;
begin
  TempSQL := UpperCase(Trim(SQL));
  StartPos := Pos('FROM', TempSQL);

  if StartPos = 0 then Exit('');
  Inc(StartPos, 4);

  EndPos := PosEx(' ', TempSQL, StartPos);
  if EndPos = 0 then EndPos := Length(TempSQL) + 1;

  Result := Trim(Copy(SQL, StartPos, EndPos - StartPos));
end;
}
function TUniQueryAnalyzer.GetTableName: string;
begin
  Result :=  UpperCase(ExtractTableName(FUniQuery.SQL.Text));

  if Result = '' then
    raise Exception.Create('Nome da tabela n�o foi encontrado na SQL.');
end;

function TUniQueryAnalyzer.GetPrimaryKey: string;
var
  UniQuery: TUniQuery;
  TableName: string;
begin
  TableName := GetTableName;

  UniQuery := TUniQuery.Create(nil);
  try
    UniQuery.Connection := FUniQuery.Connection;

    UniQuery.SQL.Text :=
      'SELECT ' +
      'RDB$INDEX_SEGMENTS.RDB$FIELD_NAME AS field_name ' +
      'FROM RDB$INDEX_SEGMENTS ' +
      'LEFT JOIN RDB$INDICES ON RDB$INDICES.RDB$INDEX_NAME = RDB$INDEX_SEGMENTS.RDB$INDEX_NAME ' +
      'LEFT JOIN RDB$RELATION_CONSTRAINTS ON RDB$RELATION_CONSTRAINTS.RDB$INDEX_NAME = RDB$INDICES.RDB$INDEX_NAME ' +
      'WHERE ' +
      'RDB$RELATION_CONSTRAINTS.RDB$CONSTRAINT_TYPE = ''PRIMARY KEY'' AND ' +
      'RDB$RELATION_CONSTRAINTS.RDB$RELATION_NAME = :TableName';

    UniQuery.ParamByName('TableName').AsString := UpperCase(TableName);
    UniQuery.Open;

    if not UniQuery.Eof then
      Result := Trim(UniQuery.FieldByName('field_name').AsString)
    else
      Result := '';
  finally
    UniQuery.Free;
  end;
end;

end.
