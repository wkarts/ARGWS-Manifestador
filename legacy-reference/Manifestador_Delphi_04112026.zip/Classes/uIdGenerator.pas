{$IFDEF UNICODE}
  {$WARN IMPLICIT_STRING_CAST OFF}
  {$WARN IMPLICIT_STRING_CAST_LOSS OFF}
{$ENDIF}
unit uIdGenerator;

interface

uses
  SysUtils,
  FireDac.Comp.Client,
  FireDAC.Stan.Param,
  Uni,
  DB,
  System.Classes,
  System.Variants,
  Vcl.Dialogs,
  Vcl.Controls;

type
 TGenBuilder = (TGenInsert, TGenConfirm, TGenReserve, TGenCancel);

type
  TIDGenNameTableField = record
    TableName, FieldName, UUID, ID: String;
  end;

type
  TIdGenerator = class
  private
    FDB       : TUniConnection;
    FGen      : TIDGenNameTableField;
    FTableName : String;
    FFieldName : String;
    FUUID      : String;
    FID        : String;
    function ExisteRegistro(ExpressaoSQL : string; var Params: array of Variant; var TotalRegistros : integer):Boolean;
    procedure SQlExecutar(ExpressaoSQL : string; Params: array of Variant);
    procedure AbrirQuery(var Query : TUniQuery; ExpressaoSQL : string; Params: array of Variant);
    function IdExistsInSourceTable(SourceTable: string; SourceField: string; Id: string): Boolean;
  public
    constructor Create(ADB: TUniConnection);
    function ConfirmarPendencia(Tabela, Campo, ValorAtual: string): Boolean;
    function GenerateId(Tabela: string; Campo: string; Pendencia: boolean; const ValorAtual : string = ''; Confirma: boolean = False): string;
    //function GenerateId(Tabela: string; Campo: string; Pendencia: Boolean; const ValorAtual: string = ''; Confirma: Boolean = False; ConsiderarZero: Boolean = False): string;
    function EnsureAuxTableExists: Boolean;
    property TableName :String read FTableName write FTableName;
    property FieldName :String read FFieldName write FFieldName;
    property UUID      :String read FUUID      write FUUID;
    property ID        :String read FID        write FID;
  end;

  var
    FFIdGenerator: TIdGenerator;
    procedure GeneratorBuilder(Mode: TGenBuilder; DataSet: TDataSet; FFConn: TUniConnection);
    procedure QueryBuilder( var Query: TUniQuery; FFConn: TUniConnection);
    function GetNameFieldTable(TF: string; FFQuery: TObject): String;
    function ReserveNextIDForTable(Connection: TUniConnection; TableName, FieldName: string; Pendencia: Boolean = False; ValorAtual : string = ''; Confirma: Boolean = False): Integer;

implementation

  {$REGION ' Instru��es de Uso Atutomatizador '}

  (*
    Instru��es de Uso:

    Este m�todo, ExecutarFluxoAutomatico, foi projetado para automatizar o fluxo de gera��o de IDs,
    pend�ncias e confirma��es em uma tabela espec�fica.

    Para utiliz�-lo, siga os passos abaixo:

    1. Chame o m�todo passando os par�metros adequados:
       - Tabela: Nome da tabela para a qual voc� deseja gerar IDs.
       - Campo: Nome do campo da tabela para o qual o ID ser� gerado.
       - ValorAtual (opcional): Valor atual do ID, se dispon�vel.

    2. O m�todo gera um novo ID para a tabela especificada.

    3. Em seguida, gera um ID pendente para a tabela. Este passo simula uma situa��o ap�s um insert.

    4. Insira a l�gica espec�fica do seu projeto para verificar se o insert foi bem-sucedido.
       - Se o insert foi bem-sucedido, a pend�ncia � marcada automaticamente.
       - Se o insert falhar ou for cancelado, a pend�ncia pode ser exclu�da.

    5. O m�todo tenta confirmar a pend�ncia automaticamente.
       - Se a confirma��o for bem-sucedida, o fluxo continua normalmente.
       - Se a confirma��o falhar, voc� pode incluir a l�gica para cancelar o insert ou realizar outras a��es necess�rias.

    6. Por fim, o m�todo obt�m o pr�ximo ID sem gerar pend�ncia para uso subsequente.

    Certifique-se de adaptar as partes comentadas do c�digo conforme necess�rio para
    atender aos requisitos espec�ficos do seu projeto.

  *)

  (*

  function ExecutarFluxoAutomatico(Tabela, Campo: string; const ValorAtual: string = ''): string;
  var
    idGenerator: TIdGenerator;
    novoId: string;
  begin
    idGenerator := TIdGenerator.Create;

    try
      // Gera��o de ID para uma tabela espec�fica
      novoId := idGenerator.GenerateId(Tabela, Campo);

      // Gera��o de ID pendente para uma tabela espec�fica ap�s um insert
      novoId := idGenerator.GenerateId(Tabela, Campo, True, novoId);

      // Marcar a pend�ncia se necess�rio ap�s o insert
      // ... l�gica para verificar se o insert foi bem-sucedido e marcar a pend�ncia se necess�rio ...

      // Confirmar a pend�ncia caso exista
      if not idGenerator.ConfirmarPendencia(Tabela, Campo, ValorAtual) then
      begin
        // Exclus�o do insert se for cancelado
        // ... l�gica para cancelar o insert ...
      end;

      // Obten��o do pr�ximo ID sem gerar pend�ncia
      novoId := idGenerator.GenerateId(Tabela, Campo, False);

      // Agora voc� pode usar o novoId conforme necess�rio

      Result := novoId;

    finally
      idGenerator.Free;
    end;
  end;

  procedure TDMManifestador.ZQueryEmpresaAfterPost(DataSet: TDataSet);
  begin
    GeneratorBuilder(TGenConfirm, DataSet, (DataSet as TUniQuery).Connection);
  end;

  procedure TDMManifestador.ZQueryEmpresaBeforeCancel(DataSet: TDataSet);
  begin
    GeneratorBuilder(TGenCancel, DataSet, (DataSet as TUniQuery).Connection);
  end;

  procedure TDMManifestador.ZQueryEmpresaNewRecord(DataSet: TDataSet);
  begin
    GeneratorBuilder(TGenInsert, DataSet, (DataSet as TUniQuery).Connection);
  end;

  *)

  {$ENDREGION}

  {$REGION ' Aplica��es Pr�ticas TIdGenerator '}

    (*

      Como utilizar cada situa��o do TIdGenerator em aplica��es pr�ticas:

      1. Gera��o de ID para uma tabela espec�fica:

         Quando usar:
          Use esta op��o quando desejar obter um novo ID para um campo em uma
          tabela espec�fica antes de realizar uma opera��o de inser��o.

         Exemplo pr�tico:
          Antes de inserir um novo registro em uma tabela, obtenha um novo ID
          usando GenerateId e use esse ID ao inserir o registro.

      2. Gera��o de ID pendente para uma tabela espec�fica:

         Quando usar:
          Use esta op��o quando desejar gerar um ID pendente para um campo em
          uma tabela, mas n�o confirmar imediatamente. �til quando pode haver
          uma desist�ncia de insert ou uma parada inesperada no processo.

         Exemplo pr�tico:
          Ao iniciar um processo de inser��o, gere um ID pendente usando GenerateId
          com o par�metro Pendencia definido como True. Em caso de desist�ncia, o ID
          n�o confirmado n�o afetar� as opera��es futuras.

      3. Confirma��o de um ID pendente:

         Quando usar:
          Use esta op��o quando desejar confirmar um ID pendente gerado anteriormente.

         Exemplo pr�tico:
          Ap�s uma opera��o bem-sucedida, confirme o ID pendente gerado usando GenerateId
          com os par�metros Pendencia e Confirma definidos como True.

      4. Gera��o de ID e confirma��o pendente para uma tabela espec�fica:

         Quando usar:
          Use esta op��o quando desejar gerar um ID e garantir que ele seja confirmado em
          uma transa��o subsequente. Isso � �til quando voc� deseja gerar um ID e garantir
          sua validade antes de uma opera��o cr�tica.

         Exemplo pr�tico:
          Antes de iniciar uma transa��o, gere um ID pendente usando GenerateId com o par�metro
          Pendencia definido como True. Ap�s o sucesso da transa��o, confirme o ID pendente usando
          GenerateId com os par�metros Pendencia e Confirma definidos como True.

      5. Obten��o do pr�ximo ID sem gerar pend�ncia:

         Quando usar:
          Use esta op��o quando desejar apenas obter o pr�ximo ID sem gerar pend�ncia.
          �til quando precisa do pr�ximo ID, mas n�o deseja criar um registro pendente.

         Exemplo pr�tico:
          Pode ser usado quando precisa exibir o pr�ximo ID dispon�vel antes de realizar uma
          opera��o de inser��o, mas sem comprometer-se com a cria��o imediata do registro.

        Essas s�o diretrizes gerais, e a escolha depender� das necessidades espec�ficas do seu aplicativo e
        do fluxo de trabalho que est� implementando. A aplica��o pr�tica pode variar com base nos requisitos
        de neg�cios e nas condi��es espec�ficas do sistema.

    *)

  {$ENDREGION}

  {$REGION ' Instru��es de Uso TIdGenerator '}

  (*
     Instru��es de Uso do TIdGenerator:

     O TIdGenerator � uma classe projetada para gerar IDs �nicos com base em tabelas de controle
     no banco de dados (SEQUENCER e SEQUENCER_PENDENCIES). Aqui est�o algumas diretrizes sobre quando
     e como usar cada recurso da classe:

     1. Gera��o de ID para uma tabela espec�fica:
        - Use o m�todo GenerateId para obter um novo ID para um campo em uma tabela.
        - Exemplo:
          ```delphi
          var
            Tabela, Campo, NovoID: string;
          begin
            Tabela := 'NomeDaTabela'; // Substitua pelo nome da sua tabela
            Campo := 'NomeDoCampo';   // Substitua pelo nome do seu campo

            NovoID := IdGenerator.GenerateId(Tabela, Campo);
          end;
          ```

     2. Gera��o de ID pendente para uma tabela espec�fica:
        - Use o m�todo GenerateId com o par�metro Pendencia definido como True para gerar um ID pendente.
        - Isso � �til quando h� uma desist�ncia de insert ou uma parada inesperada no processo.
        - Exemplo:
          ```delphi
          var
            Tabela, Campo, ValorAtual: string;
          begin
            Tabela := 'NomeDaTabela';   // Substitua pelo nome da sua tabela
            Campo := 'NomeDoCampo';     // Substitua pelo nome do seu campo
            ValorAtual := 'ValorAtual';  // Substitua pelo valor atual do campo, se aplic�vel

            IdGenerator.GenerateId(Tabela, Campo, True, ValorAtual);
          end;
          ```

     3. Confirma��o de um ID pendente:
        - Use o m�todo GenerateId com os par�metros Pendencia e Confirma definidos como True para confirmar um ID pendente.
        - Isso � �til quando voc� deseja confirmar a gera��o do ID ap�s uma opera��o bem-sucedida.
        - Exemplo:
          ```delphi
          var
            Tabela, Campo, ValorAtual: string;
          begin
            Tabela := 'NomeDaTabela';   // Substitua pelo nome da sua tabela
            Campo := 'NomeDoCampo';     // Substitua pelo nome do seu campo
            ValorAtual := 'ValorAtual';  // Substitua pelo valor atual do campo, se aplic�vel

            IdGenerator.GenerateId(Tabela, Campo, True, ValorAtual, True);
          end;
          ```

     4. Gera��o de ID e confirma��o pendente para uma tabela espec�fica:
        - Use o m�todo GenerateId com os par�metros Pendencia e Confirma definidos como True para gerar um ID e confirmar pend�ncia.
        - Isso � �til quando voc� deseja gerar um ID e garantir que ele seja confirmado em uma transa��o subsequente.
        - Exemplo:
          ```delphi
          var
            Tabela, Campo, ValorAtual: string;
          begin
            Tabela := 'NomeDaTabela';   // Substitua pelo nome da sua tabela
            Campo := 'NomeDoCampo';     // Substitua pelo nome do seu campo
            ValorAtual := 'ValorAtual';  // Substitua pelo valor atual do campo, se aplic�vel

            IdGenerator.GenerateId(Tabela, Campo, True, ValorAtual);
          end;
          ```

     5. Obten��o do pr�ximo ID sem gerar pend�ncia:
        - Use o m�todo GenerateId com o par�metro Pendencia definido como False para obter o pr�ximo ID sem gerar pend�ncia.
        - Isso � �til quando voc� s� precisa do pr�ximo ID, mas n�o deseja criar um registro pendente.
        - Exemplo:
          ```delphi
          var
            Tabela, Campo, NovoID: string;
          begin
            Tabela := 'NomeDaTabela'; // Substitua pelo nome da sua tabela
            Campo := 'NomeDoCampo';   // Substitua pelo nome do seu campo

            NovoID := IdGenerator.GenerateId(Tabela, Campo, False);
          end;
          ```

     Certifique-se de ajustar os par�metros e valores conforme necess�rio para o seu caso espec�fico.
  *)

  {$ENDREGION}

  uses
     UniQueryAnalyzer;

procedure GeneratorBuilder(Mode: TGenBuilder; DataSet: TDataSet; FFConn: TUniConnection);
begin

  case Mode of

    TGenBuilder.TGenInsert:
    begin

      with (DataSet) do
      begin

        if State in [dsInsert]  then
        begin

          FieldByName(GetNameFieldTable('F',(DataSet))).AsInteger :=
            ReserveNextIDForTable(
                                   FFConn,
                                   GetNameFieldTable('T',(DataSet)),
                                   GetNameFieldTable('F',(DataSet))
                                 );

           if FFConn.DefaultTransaction.Active then
            FFConn.DefaultTransaction.CommitRetaining;

        end;

      end;

    end;

    TGenBuilder.TGenConfirm:
    begin

      with (DataSet) do
      begin

        ReserveNextIDForTable(
                              FFConn,
                              GetNameFieldTable('T', DataSet),
                              GetNameFieldTable('F', DataSet),
                              False,
                              FieldByName(GetNameFieldTable('F', DataSet)).AsString,
                              True
                             );

         if FFConn.DefaultTransaction.Active then
          FFConn.DefaultTransaction.CommitRetaining;

      end;

    end;

    TGenBuilder.TGenReserve:
    begin

      with (DataSet) do
      begin


         if FFConn.DefaultTransaction.Active then
          FFConn.DefaultTransaction.CommitRetaining;

      end;

    end;

    TGenBuilder.TGenCancel:
    begin

      with (DataSet) do
      begin

        if State in [dsInsert] then
              ReserveNextIDForTable(
                                    FFConn,
                                    GetNameFieldTable('T', DataSet),
                                    GetNameFieldTable('F', DataSet),
                                    True,
                                    DataSet.FieldByName(GetNameFieldTable('F', DataSet)).AsString
                                   );

              {ReserveNextIDForTable(
                                    FFConn,
                                    GetNameFieldTable('T', DataSet),
                                    GetNameFieldTable('F', DataSet),
                                    True,
                                    DataSet.FieldByName(GetNameFieldTable('F', DataSet)).AsString
                                   );}

         if FFConn.DefaultTransaction.Active then
          FFConn.DefaultTransaction.CommitRetaining;

      end;

    end;

  end;

end;

procedure QueryBuilder( var Query: TUniQuery; FFConn: TUniConnection);
begin
  Query := TUniQuery.Create(nil);
  Query.Connection := FFConn;
  Query.Connection.Connected;
end;

function GetNameFieldTable(TF: string; FFQuery: TObject): String;
var
  FUniQueryAnalyzer: TUniQueryAnalyzer;
  TableName: string;
  PrimaryKey: string;
  NAME_TABLE: string;
  FIELD_ID: string;
begin

  Result := '';

  FUniQueryAnalyzer := TUniQueryAnalyzer.Create((FFQuery as TUniQuery));
  NAME_TABLE  := FUniQueryAnalyzer.GetTableName;
  FIELD_ID    := FUniQueryAnalyzer.GetPrimaryKey;

  if (TF='T') then
    Result := NAME_TABLE
  else
    Result := FIELD_ID;


end;

function ReserveNextIDForTable(Connection: TUniConnection; TableName, FieldName: string; Pendencia: Boolean = False; ValorAtual : string = ''; Confirma: Boolean = False): Integer;
  function GetIDValue(GTableName, GFieldName: string; FFConn: TUniConnection): string;
  var mQuery: TUniQuery;
  begin

    QueryBuilder(mQuery, FFConn);

    with mQuery do
    begin

      Close;
      SQL.Clear;
      SQL.Text := ' SELECT MAX(' + GFieldName + ') FROM ' + GTableName;
      Open;

      //if not(IsEmpty) or not(Fields[0].IsNull) then

      if (Fields[0].AsInteger > 0) then
        Result := Fields[0].AsString
      else
        Result := '0';

    end;

  end;
var
  IdGen: TIdGenerator;
  Id: string;
begin

  Result := 0;

  IdGen := TIdGenerator.Create(Connection);

  try

    if IdGen.EnsureAuxTableExists then
    begin

      Id := IdGen.GenerateId(TableName, FieldName, Pendencia, ValorAtual, Confirma);

      if (Id <= GetIDValue(TableName, FieldName, Connection))  then
      begin

        //while not( ID > GetIDValue(TableName, FieldName, Connection) ) do
        while not( ID <= GetIDValue(TableName, FieldName, Connection) ) do
        begin

          IdGen.GenerateId(TableName, FieldName, True, Id, True);

          Id := (GetIDValue(TableName, FieldName, Connection).ToInteger + 1).ToString;

        end;

      end;

    end;

    {$REGION ' Desabilitado Recursos de Analise '}
    (*

    //Id    :=  GetIDValue(TableName, FieldName);

    try

      if IdGen.EnsureAuxTableExists then
      begin

        Id := IdGen.GenerateId(TableName, FieldName, Pendencia, ValorAtual, Confirma);

        if (Id <= GetIDValue(TableName, FieldName))  then
        begin

          while not( ID > GetIDValue(TableName, FieldName) ) do
          begin

            IdGen.GenerateId(TableName, FieldName, True, Id, True);

            Id := (GetIDValue(TableName, FieldName).ToInteger + 1).ToString;

          end;

        end;

        // Gera��o de ID para uma tabela espec�fica
        // Id := IdGen.GenerateId(TableName, FieldName, False);

        // Gera��o de ID pendente para uma tabela espec�fica ap�s um insert
        // Id := IdGen.GenerateId(TableName, FieldName, True, Id);

        // Marcar a pend�ncia se necess�rio ap�s o insert
        // ... l�gica para verificar se o insert foi bem-sucedido e marcar a pend�ncia se necess�rio ...

        // Confirmar a pend�ncia caso exista
        // if not IdGen.ConfirmarPendencia(TableName, FieldName, ValorAtual) then
        // begin
          // Exclus�o do insert se for cancelado
          // ... l�gica para cancelar o insert ...
        // end;

        // Obten��o do pr�ximo ID sem gerar pend�ncia
        // Id := IdGen.GenerateId(TableName, FieldName, False);

        // Agora voc� pode usar o novoId conforme necess�rio


        {
        if IsInsert then
        begin
          Id := IdGen.GenerateId(TableName, FieldName, Pendencia, GetIDValue(TableName, FieldName), Confirma);
        end else
        begin
          Id := IdGen.GenerateId(TableName, FieldName, Pendencia, ValorAtual, Confirma);
        end;
        }

      end;

      {
      if Pendencia then
        Result := 0
      else
      }


    *)
    {$ENDREGION}

    if not(Id.IsEmpty) then
      Result := Id.ToInteger;

  finally

    IdGen.Free;

  end;


end;


constructor TIdGenerator.Create(ADB: TUniConnection);
begin
  inherited Create;
  FDB := ADB;
end;

function TIdGenerator.ConfirmarPendencia(Tabela, Campo, ValorAtual: string): Boolean;
var
  params: array of Variant;
  SQLTemp: string;
  IREG_ACHADOS: Integer;
begin
  SetLength(params, 3);
  params[0] := Tabela;
  params[1] := Campo;
  params[2] := ValorAtual;

  // Verifica se existe pend�ncia para confirmar
  SQLTemp := 'SELECT * FROM SEQUENCER_PENDENCIES WHERE ' +
             'SEQUENCER_TABLE = :p0 AND ' +
             'SEQUENCER_FIELD = :p1 AND ' +
             'SEQUENCER_VALUE = :p2 AND ' +
             'SEQUENCER_CONDITION IN (''F'', ''I'') ';

  Result := ExisteRegistro(SQLTemp, params, IREG_ACHADOS);

  if Result then
  begin
    // Marca a pend�ncia como confirmada
    SQLTemp := 'UPDATE SEQUENCER_PENDENCIES SET SEQUENCER_CONDITION = ''I'' ' +
               'WHERE SEQUENCER_TABLE = :p0 AND SEQUENCER_FIELD = :p1 AND SEQUENCER_VALUE = :p2 ';

    SQlExecutar(SQLTemp, params);
  end;
end;


function TIdGenerator.ExisteRegistro(ExpressaoSQL : String; var Params: array of Variant; var TotalRegistros : integer):Boolean;
var
  IQuery : TUniQuery;
begin

  IQuery := TUniQuery.Create(nil);

  try

    IQuery.Connection := FDB;

    AbrirQuery(IQuery, ExpressaoSQL, Params);

    TotalRegistros := IQuery.RecordCount;

    Result := ( TotalRegistros > 0 );

  finally

    IQuery.Free;

  end;

end;

procedure TIdGenerator.SQlExecutar(ExpressaoSQL: string; Params: array of Variant);
var
  IQUERY: TUniQuery;
  i: Integer;
begin
  IQUERY := TUniQuery.Create(nil);
  try
    IQUERY.Connection := FDB;
    IQUERY.SQL.Text := ExpressaoSQL;

    // Certifique-se de que os par�metros n�o est�o vazios antes de atribu�-los
    for i := Low(Params) to High(Params) do
      if VarIsNull(Params[i]) then
        IQUERY.Params[i].Clear
      else
        IQUERY.Params[i].Value := Params[i];

    if (UpperCase(Copy(ExpressaoSQL, 1, 7)) = 'EXECUTE') or
       (UpperCase(Copy(ExpressaoSQL, 1, 6)) = 'UPDATE') or
       (UpperCase(Copy(ExpressaoSQL, 1, 6)) = 'INSERT') or
       (UpperCase(Copy(ExpressaoSQL, 1, 6)) = 'DELETE') or
       (UpperCase(Copy(ExpressaoSQL, 1, 6)) = 'CREATE') then
      IQUERY.ExecSQL
    else
      IQUERY.Open;  // Remova a cl�usula "with IQUERY do Open" para evitar problemas
  finally
    IQUERY.Connection.DefaultTransaction.CommitRetaining;
    IQUERY.Free;
  end;
end;

{$REGION ' Desabilitado TIdGenerator.SQlExecutar '}
(*
procedure TIdGenerator.SQlExecutar(ExpressaoSQL:string; Params: array of Variant);
var
  IQUERY : TFDQuery;
  i: Integer;
begin
  IQUERY := TFDQuery.Create(nil);
  try
    IQUERY.Connection := FDB;
    IQUERY.SQL.Text := ExpressaoSQL;
    for i := Low(Params) to High(Params) do
      IQUERY.Params[i].Value := Params[i];
    if (UpperCase(Copy(ExpressaoSQL, 1, 7)) = 'EXECUTE') or
       (UpperCase(Copy(ExpressaoSQL, 1, 6)) = 'UPDATE') or
       (UpperCase(Copy(ExpressaoSQL, 1, 6)) = 'INSERT') or
       (UpperCase(Copy(ExpressaoSQL, 1, 6)) = 'DELETE') or
       (UpperCase(Copy(ExpressaoSQL, 1, 6)) = 'CREATE')
    then
      IQUERY.ExecSQL
    else
    begin

      with IQUERY do
      begin
       Open;
      end;

    end;
  finally
    IQUERY.Connection.Transaction.CommitRetaining;
    IQUERY.Free;
  end;
end;
*)
{$ENDREGION}

procedure TIdGenerator.AbrirQuery(var Query : TUniQuery; ExpressaoSQL : string; Params: array of Variant);
var
  i: Integer;
begin

  Query := TUniQuery.Create(nil);

  try

    Query.Connection := FDB;
    Query.SQL.Text   := ExpressaoSQL;
    for i := Low(Params) to High(Params) do
      Query.Params[i].Value := Params[i];
    Query.Open;

  except

    Query.Free;
    Query := nil;

  end;

end;

function TIdGenerator.IdExistsInSourceTable(SourceTable: string; SourceField: string; Id: string): Boolean;
var
  IQuery: TUniQuery;
  SQL: string;
begin
  //Result := False;
  IQuery := TUniQuery.Create(nil);
  try
    IQuery.Connection := FDB;
    SQL := 'SELECT 1 FROM ' + SourceTable + ' WHERE ' + SourceField + ' = :p0';
    IQuery.SQL.Text := SQL;
    IQuery.ParamByName('p0').Value := Id;
    IQuery.Open;
    Result := not IQuery.Eof;
  finally
    IQuery.Free;
  end;
end;

function TIdGenerator.GenerateId(Tabela: string; Campo: string; Pendencia: Boolean; const ValorAtual: string = ''; Confirma: Boolean = False): string;
var
  IQuerySeq: TUniQuery;
  SQLTemp, IDSequencia, ILock: string;
  IREG_ACHADOS: Integer;
  params: array of Variant;
begin
  IQuerySeq := nil;
  ILock := '';//' WITH LOCK';

  //SEQUENCER_CONDITION = F {FREE}
  //SEQUENCER_CONDITION = I {IN dsIinsert} or {USED}

  if Pendencia then
  begin

    SetLength(params, 3);

    params[0] := TABELA;
    params[1] := CAMPO;
    params[2] := VALORATUAL;
    SQLTemp   := 'SELECT * FROM SEQUENCER_PENDENCIES WHERE ' +
                 'SEQUENCER_TABLE = :p0 AND ' +
                 'SEQUENCER_FIELD = :p1 AND ' +
                 'SEQUENCER_VALUE = :p2 AND ' +
                 'SEQUENCER_CONDITION IN (''F'',''I'') ' ;

    if VALORATUAL.IsEmpty then
      Exit;

    if not(ExisteRegistro(SQLTemp, params, IREG_ACHADOS)) then
    begin

      SQLTemp := 'INSERT INTO SEQUENCER_PENDENCIES ( SEQUENCER_TABLE, SEQUENCER_FIELD, SEQUENCER_VALUE ) ' +
                      'VALUES(:p0, :p1, :p2)';

      SQlExecutar(SQLTemp, params);

    end else
    begin

      SQLTemp := 'UPDATE SEQUENCER_PENDENCIES SET SEQUENCER_CONDITION = ''F'' ' +
                 'WHERE SEQUENCER_TABLE = :p0 AND SEQUENCER_FIELD = :p1 AND SEQUENCER_VALUE = :p2';

      SQlExecutar(SQLTemp, params);

    end;

    exit;

  end;

  if Confirma then
  begin

    SetLength(params, 3);

    params[0] := TABELA;
    params[1] := CAMPO;
    params[2] := VALORATUAL;

    SQLTemp   := 'SELECT * FROM SEQUENCER_PENDENCIES WHERE ' +
                 'SEQUENCER_TABLE = :p0 AND ' +
                 'SEQUENCER_FIELD = :p1 AND ' +
                 'SEQUENCER_VALUE = :p2 AND ' +
                 'SEQUENCER_CONDITION IN (''F'', ''I'') ' ;

    if (ExisteRegistro(SQLTemp, params, IREG_ACHADOS)) then
    begin

       SQLTemp := 'DELETE FROM SEQUENCER_PENDENCIES ' +
                  'WHERE SEQUENCER_TABLE = :p0 AND SEQUENCER_FIELD = :p1 AND SEQUENCER_VALUE = :p2 ';

       SQlExecutar( SQLTemp, params );

    end;

    exit;

  end;

  while IQuerySeq = nil do
  begin

    SetLength(params, 2);
    params[0] := TABELA;
    params[1] := CAMPO;

    SQLTemp := 'SELECT COUNT(*) AS REC_COUNT FROM SEQUENCER_PENDENCIES ' +
               'WHERE SEQUENCER_TABLE = :p0 AND ' +
               'SEQUENCER_FIELD = :p1 AND ' +
               'SEQUENCER_VALUE IS NOT NULL AND ' +
               'SEQUENCER_CONDITION = ''F'' ';

    if ExisteRegistro(SQLTemp, params, IREG_ACHADOS) then
      AbrirQuery(IQUERYSEQ, SQLTemp + ILock, params)
    else
      IREG_ACHADOS := 0;

    if (IREG_ACHADOS <> 0) and (IQuerySeq.FieldByName('REC_COUNT').AsInteger > 0) then
    begin

      SQLTemp := 'SELECT MAX(SEQUENCER_VALUE) AS SEQUENCE FROM SEQUENCER_PENDENCIES ' +
                 'WHERE SEQUENCER_TABLE = :p0 AND SEQUENCER_FIELD = :p1 AND ' +
                 'SEQUENCER_CONDITION = ''F'' ';
      AbrirQuery(IQuerySeq, SQLTemp + ILock, params);
      IDSequencia := IQuerySeq.FieldByName('SEQUENCE').Text;

      Result := IDSequencia;

      if IdExistsInSourceTable(Tabela, Campo, Result) then
      begin
        repeat
          Result := (Result.ToInteger + 1).ToString;
        until not(IdExistsInSourceTable(Tabela, Campo, Result)) ;
      end;

      SQLTemp := 'UPDATE SEQUENCER_PENDENCIES SET SEQUENCER_CONDITION = ''I'' ' +
                 'WHERE SEQUENCER_TABLE = :p0 AND SEQUENCER_FIELD = :p1 AND SEQUENCER_VALUE = :p2 ';
      SQlExecutar(SQLTemp, [TABELA, CAMPO, IDSequencia]);

      Exit;

    end;

    SQLTemp := 'SELECT SEQUENCER_VALUE AS SEQUENCE FROM SEQUENCER ' +
               'WHERE SEQUENCER_TABLE = :p0 AND SEQUENCER_FIELD = :p1';

    if not(ExisteRegistro(SQLTemp, params, IREG_ACHADOS)) then
    begin
      SQLTemp := 'INSERT INTO SEQUENCER (SEQUENCER_TABLE, SEQUENCER_FIELD, SEQUENCER_VALUE) VALUES (:p0, :p1, 2)';
      SQlExecutar(SQLTemp, params);
      Result := '1';
      Exit;
    end
    else
    begin
      AbrirQuery(IQUERYSEQ, (SQLTemp + ILock), params);
      if (IQUERYSEQ <> nil) then
      begin
        Result := IQUERYSEQ.FieldByName('SEQUENCE').Text;

        if IdExistsInSourceTable(Tabela, Campo, Result) then
        begin
          repeat
            Result := (Result.ToInteger + 1).ToString;
          until not(IdExistsInSourceTable(Tabela, Campo, Result)) ;
        end;

        SQLTemp := 'UPDATE SEQUENCER ' +
                   'SET SEQUENCER_VALUE = SEQUENCER_VALUE + 1 ' +
                   'WHERE SEQUENCER_TABLE = :p0 AND SEQUENCER_FIELD = :p1';

        SQlExecutar(SQLTemp, params);

        Exit;
      end;
    end;

    if (IQuerySeq = nil) then
      Sleep(1000);     // Espera 1 Segundo para Continuar casa haja Erro
  end;

end;

{$REGION ' Desabilitado TIdGenerator.GenerateId '}
(*
function TIdGenerator.GenerateId(Tabela: string; Campo: string; Pendencia: boolean; const ValorAtual : string = ''; Confirma: boolean = False): string;
var
  IQuerySeq : TUniQuery;
  SQLTemp,
  IDSequencia,
  IWhere,
  ILock,
  IOrdem : string;
  IREG_ACHADOS : integer;
  params: array of Variant;
  SOURCE: Boolean;
begin
  IQuerySeq := nil;
  ILock     := '';//' WITH LOCK';
  IOrdem    := ' ORDER BY SEQUENCER_VALUE';

  //SEQUENCER_CONDITION = F {FREE}
  //SEQUENCER_CONDITION = I {IN dsIinsert} or {USED}

  if Pendencia then
  begin

    SetLength(params, 3);

    params[0] := TABELA;
    params[1] := CAMPO;
    params[2] := VALORATUAL;
    SQLTemp   := 'SELECT * FROM SEQUENCER_PENDENCIES WHERE ' +
                 'SEQUENCER_TABLE = :p0 AND ' +
                 'SEQUENCER_FIELD = :p1 AND ' +
                 'SEQUENCER_VALUE = :p2 AND ' +
                 'SEQUENCER_CONDITION IN (''F'',''I'') ' ;

    if VALORATUAL.IsEmpty then
      Exit;

    if not(ExisteRegistro(SQLTemp, params, IREG_ACHADOS)) then
    begin

      SQLTemp := 'INSERT INTO SEQUENCER_PENDENCIES ( SEQUENCER_TABLE, SEQUENCER_FIELD, SEQUENCER_VALUE ) ' +
                      'VALUES(:p0, :p1, :p2)';

      SQlExecutar(SQLTemp, params);

    end else
    begin

      SQLTemp := 'UPDATE SEQUENCER_PENDENCIES SET SEQUENCER_CONDITION = ''F'' ' +
                 ' WHERE SEQUENCER_TABLE = :p0 AND SEQUENCER_FIELD = :p1 AND SEQUENCER_VALUE = :p2';

      SQlExecutar(SQLTemp, params);

    end;

    exit;

  end;

  if Confirma then
  begin

    SetLength(params, 3);

    params[0] := TABELA;
    params[1] := CAMPO;
    params[2] := VALORATUAL;

    SQLTemp   := 'SELECT * FROM SEQUENCER_PENDENCIES WHERE ' +
                 'SEQUENCER_TABLE = :p0 AND ' +
                 'SEQUENCER_FIELD = :p1 AND ' +
                 'SEQUENCER_VALUE = :p2 AND ' +
                 'SEQUENCER_CONDITION IN (''F'', ''I'') ' ;

    if (ExisteRegistro(SQLTemp, params, IREG_ACHADOS)) then
    begin

       SQLTemp := ' DELETE FROM SEQUENCER_PENDENCIES ' +
                  ' WHERE SEQUENCER_TABLE = :p0 AND SEQUENCER_FIELD = :p1 AND SEQUENCER_VALUE = :p2 ';

       SQlExecutar( SQLTemp, params );

    end;

    exit;

  end;

  while IQuerySeq = nil do
  begin

    SetLength(params, 2);
    params[0] := TABELA;
    params[1] := CAMPO;
    SQLTemp := 'SELECT MIN(SEQUENCER_VALUE) AS SEQUENCE ' +
               ' FROM SEQUENCER_PENDENCIES ' +
               ' WHERE SEQUENCER_TABLE = :p0 AND ' +
               ' SEQUENCER_FIELD = :p1 AND ' +
               ' SEQUENCER_VALUE is NOT NUll AND ' +
               ' SEQUENCER_CONDITION = ''F'' ';

    if ExisteRegistro(SQLTemp, params, IREG_ACHADOS) then
      AbrirQuery(IQUERYSEQ, SQLTemp + ILock, params)
    else
      IREG_ACHADOS := 0;

    //if (IQuerySeq <> nil) then
    begin

      if (IREG_ACHADOS <> 0) and (IQuerySeq.FieldByName('SEQUENCE').Text <> '') then
      begin


        IDSequencia := IQuerySeq.FieldByName('SEQUENCE').Text;

        Result      := IDSequencia;

        if IdExistsInSourceTable(Tabela, Campo, Result) then
        begin
          repeat
            Result := (Result.ToInteger + 1).ToString;
          until not(IdExistsInSourceTable(Tabela, Campo, Result)) ;
        end;

        SQLTemp := 'UPDATE SEQUENCER_PENDENCIES SET SEQUENCER_CONDITION = ''I'' ';
                   //' WHERE SEQUENCER_TABLE = :p0 AND SEQUENCER_FIELD = :p1 ';

        //SQLTemp := 'DELETE FROM SEQUENCER_PENDENCIES ';

        SQlExecutar(SQLTemp + ' WHERE SEQUENCER_TABLE = :p0 AND SEQUENCER_FIELD = :p1 AND SEQUENCER_VALUE = :p2 ', [TABELA, CAMPO, IDSequencia]);

        IQuerySeq.Close;

        IQuerySeq := nil;

        exit;

      end;

    end;

    if (IQuerySeq = nil) or (IREG_ACHADOS > 0)then
    begin

      SQLTemp := 'SELECT SEQUENCER_VALUE AS SEQUENCE FROM SEQUENCER ' +
                 ' WHERE SEQUENCER_TABLE = :p0 AND SEQUENCER_FIELD = :p1';
      if not(ExisteRegistro(SQLTemp, params, IREG_ACHADOS)) then
      begin
        SQLTemp := 'INSERT INTO SEQUENCER ( SEQUENCER_TABLE, SEQUENCER_FIELD, SEQUENCER_VALUE ) VALUES (:p0, :p1, 2)';
        SQlExecutar(SQLTemp, params);
        Result := '1';
        exit;
      end
      else
      begin

        AbrirQuery(IQUERYSEQ, (SQLTemp + ILock), params);
        if (IQuerySeq <> nil) then begin

          Result := IQuerySeq.FieldByName('SEQUENCE').Text;

          if IdExistsInSourceTable(Tabela, Campo, Result) then
          begin
            repeat
              Result := (Result.ToInteger + 1).ToString;
            until not(IdExistsInSourceTable(Tabela, Campo, Result)) ;
          end;

          SQLTemp := 'UPDATE SEQUENCER ' +
                     ' SET SEQUENCER_VALUE = SEQUENCER_VALUE + 1 ' +
                     ' WHERE SEQUENCER_TABLE = :p0 AND SEQUENCER_FIELD = :p1';

          SQlExecutar(SQLTemp, params);

          exit;
        end;

      end;
    end;

    if (IQuerySeq = nil) then
      Sleep(1000)     //Espera 1 Segundo para Continuar casa haja Erro
    else
      Result := IQuerySeq.FieldByName('SEQUENCE').Text;

  end;

end;
*)
{$ENDREGION}

function TIdGenerator.EnsureAuxTableExists: Boolean;
var
  FQuery: TUniQuery;
begin

  FQuery:= TUniQuery.Create(nil);
  try
     FQuery.Connection := FDB;

     try
        With FQuery do
        Begin

           {$REGION ' CRIA A TABELA SEQUENCER '}

           Close;
           Sql.Clear;
           Sql.Add(' SELECT COUNT(*) QTDE ');
           Sql.Add(' FROM RDB$RELATIONS ');
           Sql.Add(' WHERE RDB$FLAGS=1 and RDB$RELATION_NAME=''SEQUENCER'' ');
           Open;

           if (FieldByName('QTDE').AsInteger = 0) then
           begin

                 Sql.Clear;
                 Sql.Add(' CREATE TABLE SEQUENCER ( ');
                 Sql.Add(' SEQUENCER_ID     INTEGER GENERATED BY DEFAULT AS IDENTITY NOT NULL PRIMARY KEY, ');
                 Sql.Add(' SEQUENCER_TABLE  VARCHAR(100) UNIQUE NOT NULL , ');
                 Sql.Add(' SEQUENCER_FIELD  VARCHAR(30) NOT NULL, '); //Sql.Add(' SEQUENCER_FIELD  VARCHAR(30) UNIQUE NOT NULL, ');
                 Sql.Add(' SEQUENCER_VALUE  INTEGER NOT NULL, ');
                 Sql.Add(' SEQUENCER_DT     TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL, ');
                 Sql.Add(' SEQUENCER_UUID   CHAR(16) CHARACTER SET OCTETS NOT NULL ');
                 Sql.Add('  );');
                 ExecSQL;
                 Connection.DefaultTransaction.CommitRetaining;

                 Sql.Clear;
                 Sql.Add(' CREATE OR ALTER TRIGGER SEQUENCER_BI0 FOR SEQUENCER  ');
                 Sql.Add(' ACTIVE BEFORE INSERT POSITION 0 ');
                 Sql.Add(' AS ');
                 Sql.Add(' begin ');
                 Sql.Add('   if (new.SEQUENCER_UUID is null) then ');
                 Sql.Add('     new.SEQUENCER_UUID = gen_uuid(); ');
                 Sql.Add(' end ');
                 ExecSQL;
                 Connection.DefaultTransaction.CommitRetaining;

                 Sql.Clear;
                 Sql.Add(' CREATE OR ALTER TRIGGER SEQUENCER_BU0 FOR SEQUENCER  ');
                 Sql.Add(' ACTIVE BEFORE UPDATE POSITION 0 ');
                 Sql.Add(' AS ');
                 Sql.Add(' begin ');
                 Sql.Add('   if (new.SEQUENCER_UUID is null) then ');
                 Sql.Add('     new.SEQUENCER_UUID = gen_uuid(); ');
                 Sql.Add(' end ');
                 ExecSQL;
                 Connection.DefaultTransaction.CommitRetaining;

           end;

           {$ENDREGION}

           {$REGION ' CRIA A TABELA SEQUENCER_PENDENCIES '}

           Close;
           Sql.Clear;
           Sql.Add(' SELECT COUNT(*) QTDE ');
           Sql.Add(' FROM RDB$RELATIONS ');
           Sql.Add(' WHERE RDB$FLAGS=1 and RDB$RELATION_NAME=''SEQUENCER_PENDENCIES'' ');
           Open;

           if (FieldByName('QTDE').AsInteger = 0) then
           begin

                 Sql.Clear;
                 Sql.Add(' CREATE TABLE SEQUENCER_PENDENCIES ( ');
                 Sql.Add(' SEQUENCER_ID         INTEGER GENERATED BY DEFAULT AS IDENTITY NOT NULL PRIMARY KEY, ');
                 Sql.Add(' SEQUENCER_TABLE      VARCHAR(100) NOT NULL, ');
                 Sql.Add(' SEQUENCER_FIELD      VARCHAR(30) NOT NULL, ');
                 Sql.Add(' SEQUENCER_VALUE      INTEGER NOT NULL, ');
                 Sql.Add(' SEQUENCER_CONDITION  VARCHAR(1) DEFAULT ''F'' NOT NULL, ');
                 Sql.Add(' SEQUENCER_DT         TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL, ');
                 Sql.Add(' SEQUENCER_UUID       CHAR(16) CHARACTER SET OCTETS NOT NULL ');
                 Sql.Add('  );');
                 ExecSQL;
                 Connection.DefaultTransaction.CommitRetaining;

                 Sql.Clear;
                 Sql.Add(' CREATE OR ALTER TRIGGER SEQUENCER_PENDENCIES_BI0 FOR SEQUENCER_PENDENCIES  ');
                 Sql.Add(' ACTIVE BEFORE INSERT POSITION 0 ');
                 Sql.Add(' AS ');
                 Sql.Add(' begin ');
                 Sql.Add('   if (new.SEQUENCER_UUID is null) then ');
                 Sql.Add('     new.SEQUENCER_UUID = gen_uuid(); ');
                 Sql.Add(' end ');
                 ExecSQL;
                 Connection.DefaultTransaction.CommitRetaining;

                 Sql.Clear;
                 Sql.Add(' CREATE OR ALTER TRIGGER SEQUENCER_PENDENCIES_BU0 FOR SEQUENCER_PENDENCIES  ');
                 Sql.Add(' ACTIVE BEFORE UPDATE POSITION 0 ');
                 Sql.Add(' AS ');
                 Sql.Add(' begin ');
                 Sql.Add('   if (new.SEQUENCER_UUID is null) then ');
                 Sql.Add('     new.SEQUENCER_UUID = gen_uuid(); ');
                 Sql.Add(' end ');
                 ExecSQL;
                 Connection.DefaultTransaction.CommitRetaining;

           end;

          {$ENDREGION}

        End;

        Result := True;

     Except

        Result := False;

     end;

  finally

    FQuery.Free;

  end;

end;

end.
