unit uInterfaces;

interface

  uses

  FireDAC.Comp.Client,
  IBX.IBDatabase,
  cxPC,
  Data.DB;

type


  IRibbonForm = interface
    ['{32961A05-4945-42AE-BD48-6CF09F19D85F}']
    procedure SetRibbonBaseFormVisibility(IsVisible: Boolean);
  end;

  IMainCaption = interface
    ['{6E8EE9E9-D089-4603-A597-6AFEFD22CC09}']
    procedure SetCaptionTDIinMainForm(AlterCaption: String);
  end;

  IMainConnection = interface
    ['{5E8D6D39-36F0-4E13-9F46-7AEA1E0E7BDF}']
    procedure SetConnectionInMainForm(FD: TFDConnection; IB: TIBDatabase);
  end;

  IMainPageControl = interface
    ['{DF0A6B24-31AE-46ED-8640-2D921D61902E}']
    procedure SetPageControlInForm(PControl: TcxPageControl);
  end;

  IMainDataSource = Interface
    ['{0EAE7C59-7705-4D18-A799-803DF122793D}']
    procedure SetMainDataSourceInObject(DataSource: TDataSource);overload;
  End;

  IMainDataSource4Class = Interface
    ['{E40EFF5D-C2BD-457E-8675-A6B873361E7A}']
    procedure SetMainDataSourceInObject(DataSource: TDataSource);overload;
    procedure SetMainDataSourceInObject(DataSet: TDataSet); overload;
    procedure SetMainDataSourceInObject(DataSource: TDataSource; DataSet: TDataSet); overload;
    function GetMainDataSourceInObject(DataSource: TDataSource): TDataSource; overload;
    function GetMainDataSourceInObject(DataSet: TDataSet): TDataSet; overload;
    function GetMainDataSourceInObject(DataSource: TDataSource; DataSet: TDataSet): TDataSource; overload;
  End;

  TMainDataSource = class(TInterfacedObject, IMainDataSource4Class)
  private
    FMainDataSource: TDataSource;
    FMainDataSet: TDataSet;
    procedure SetMainDataSourceInObject(DataSource: TDataSource);overload;
    procedure SetMainDataSourceInObject(DataSet: TDataSet); overload;
    procedure SetMainDataSourceInObject(DataSource: TDataSource; DataSet: TDataSet); overload;
    function GetMainDataSourceInObject(DataSource: TDataSource): TDataSource; overload;
    function GetMainDataSourceInObject(DataSet: TDataSet): TDataSet; overload;
    function GetMainDataSourceInObject(DataSource: TDataSource; DataSet: TDataSet): TDataSource; overload;
  public
    property MainDataSource: TDataSource read FMainDataSource write FMainDataSource;
    property MainDataSet: TDataSet read FMainDataSet write FMainDataSet;
    constructor Create;
    destructor Destroy; override;
  end;

implementation

{ TMainDataSource }

{$REGION ' Instru��es de Uso N� 1 da Classe TMainDataSource '}

  (*

    uses
      uInterfaces, // Certifique-se de incluir a unit correta
      ..., // outras units que voc� precisa

    var
      MainDataSource: IMainDataSource4Class;
      MyDataSource: TDataSource;
      MyDataSet: TDataSet;
    begin
      MainDataSource := TMainDataSource.Create;

      // Agora voc� pode usar o MainDataSource para chamar os m�todos da interface

      // Definindo os objetos de dados atrav�s dos m�todos Set
      MainDataSource.SetMainDataSourceInObject(MyDataSource);
      MainDataSource.SetMainDataSourceInObject(MyDataSet);
      MainDataSource.SetMainDataSourceInObject(MyDataSource, MyDataSet);

      // Obtendo os objetos de dados atrav�s dos m�todos Get
      MyDataSource := MainDataSource.GetMainDataSourceInObject(MyDataSource);
      MyDataSet    := MainDataSource.GetMainDataSourceInObject(MyDataSet);
      MyDataSource := MainDataSource.GetMainDataSourceInObject(MyDataSource, MyDataSet);

      // ... (aqui voc� usaria MyDataSource e MyDataSet conforme necess�rio)

      // Lembre-se de liberar a inst�ncia de TMainDataSource quando terminar com ela
      // (Isso n�o � estritamente necess�rio neste caso, pois voc� est� usando uma interface,
      // e o Delphi gerenciar� a destrui��o do objeto para voc� uma vez que todas as refer�ncias a ele sejam liberadas)
    end;

    Neste exemplo:

    Criamos uma inst�ncia de TMainDataSource e a atribu�mos a uma vari�vel de interface IMainDataSource4Class.
    Usamos essa vari�vel de interface para chamar os v�rios m�todos definidos na interface IMainDataSource4Class.
    Usamos vari�veis MyDataSource e MyDataSet para armazenar os objetos de dados que estamos trabalhando.
    Neste exemplo, essas vari�veis s�o apenas placeholders;
    voc� substituiria esses com inst�ncias reais de TDataSource e TDataSet.

  *)

{$ENDREGION}

{$REGION ' Instru��es de Uso N� 2 da Classe TMainDataSource '}
 {

  Instru��es de Uso da Classe TMainDataSource

  1. Primeiramente, crie uma inst�ncia da classe TMainDataSource.
     var
       MainDataSource: IMainDataSource4Class;
     begin
       MainDataSource := TMainDataSource.Create;

  2. Utilize os m�todos SetMainDataSourceInObject para definir os objetos de dados.
     MainDataSource.SetMainDataSourceInObject(MyDataSource);
     MainDataSource.SetMainDataSourceInObject(MyDataSet);
     MainDataSource.SetMainDataSourceInObject(MyDataSource, MyDataSet);

  3. Use os m�todos GetMainDataSourceInObject para recuperar os objetos de dados.
     MyDataSource := MainDataSource.GetMainDataSourceInObject(MyDataSource);
     MyDataSet := MainDataSource.GetMainDataSourceInObject(MyDataSet);
     MyDataSource := MainDataSource.GetMainDataSourceInObject(MyDataSource, MyDataSet);

  4. Ap�s utilizar a inst�ncia da classe, limpe as refer�ncias para liberar a mem�ria alocada.
     MainDataSource := nil;

  5. Implemente tratamento de exce��es conforme necess�rio para gerenciar erros que possam ocorrer durante a execu��o.

  Exemplo tratamento de exce��es 1:

     try
       // seu c�digo aqui
     except
       on E: Exception do
       begin
         // tratamento de exce��es
       end;
     end;

  Exemplo de Uso da Classe:

  unit uMain;

  interface

  uses
    uInterfaces,
    ..., // outras units que voc� precisa

  implementation

  procedure UseMainDataSource;
  var
    MainDataSource: IMainDataSource4Class;
    MyDataSource: TDataSource;
    MyDataSet: TDataSet;
  begin
    MainDataSource := TMainDataSource.Create;
    try
      // Usando a classe conforme as instru��es de uso
    finally
      MainDataSource := nil;  // Isso ir� liberar a mem�ria alocada para a classe
    end;
  end;

  end.

 }
{$ENDREGION}

constructor TMainDataSource.Create;
begin
  inherited Create;
  // Inicializa��es necess�rias
end;

destructor TMainDataSource.Destroy;
begin
  // Limpeza necess�ria
  inherited Destroy;
end;

function TMainDataSource.GetMainDataSourceInObject(DataSource: TDataSource): TDataSource;
begin
  FMainDataSource := DataSource;
  Result  := MainDataSource;
end;

function TMainDataSource.GetMainDataSourceInObject(DataSource: TDataSource; DataSet: TDataSet): TDataSource;
begin
  FMainDataSource := DataSource;
  FMainDataSet := DataSet;
  Result := MainDataSource;
end;

function TMainDataSource.GetMainDataSourceInObject(DataSet: TDataSet): TDataSet;
begin
  FMainDataSet := DataSet;
  Result := MainDataSet;
end;

procedure TMainDataSource.SetMainDataSourceInObject(DataSource: TDataSource);
begin
 FMainDataSource := DataSource;
end;

procedure TMainDataSource.SetMainDataSourceInObject(DataSet: TDataSet);
begin
  FMainDataSet := DataSet;
end;

procedure TMainDataSource.SetMainDataSourceInObject(DataSource: TDataSource; DataSet: TDataSet);
begin
  FMainDataSource := DataSource;
  FMainDataSet := DataSet;
end;

end.
