unit RMRepository;

interface

uses
  SysUtils, DB, RM;

type

  TRMRepository = class

  public

    class procedure Incluir(RM: TRM);

  end;

implementation

{ TRMRepository }
uses
  uBDUtils;

class procedure TRMRepository.Incluir(RM: TRM);
var
  i: Integer;
begin

  try
  
    //Fornecedor
    {
    if (RM.Emitente.Codigo = 0) then
    begin

      RM.Emitente.Codigo := Servicos.Firebird.ObterGenerator('GEN_FORN_ID', 1);
      bdUtils.ExecutarSQL('INSERT INTO FORN                  ' +
                          '           (FOR_CD_FORNECEDOR,    ' +
                          '            FOR_CD_EMPRESA,       ' +
                          '            FOR_TX_RSOCIAL,       ' +
                          '            FOR_TX_FANTASIA,      ' +
                          '            FOR_CD_CGC,           ' +
                          '            FOR_CD_IE,            ' +
                          '            FOR_TX_ENDERECO,      ' +
                          '            FOR_TX_NUMERO,        ' +
                          '            FOR_TX_COMPLEMENTO,   ' +
                          '            FOR_TX_BAIRRO,        ' +
                          '            FOR_TX_CEP,           ' +
                          '            FOR_TX_CIDADE,        ' +
                          '            FOR_TX_UF,            ' +
                          '            FOR_TX_NACAO,         ' +
                          '            FOR_TX_FONE1,         ' +
                          '            FOR_DT_INCLUSAO,      ' +
                          '            FOR_ID_INCLUSAO,      ' +
                          '            FOR_CD_MUNICIPIO)     ' +
                          '     VALUES(:FOR_CD_FORNECEDOR,   ' +
                          '            :FOR_CD_EMPRESA,      ' +
                          '            :FOR_TX_RSOCIAL,      ' +
                          '            :FOR_TX_FANTASIA,     ' +
                          '            :FOR_CD_CGC,          ' +
                          '            :FOR_CD_IE,           ' +
                          '            :FOR_TX_ENDERECO,     ' +
                          '            :FOR_TX_NUMERO,       ' +
                          '            :FOR_TX_COMPLEMENTO,  ' +
                          '            :FOR_TX_BAIRRO,       ' +
                          '            :FOR_TX_CEP,          ' +
                          '            :FOR_TX_CIDADE,       ' +
                          '            :FOR_TX_UF,           ' +
                          '            :FOR_TX_NACAO,        ' +
                          '            :FOR_TX_FONE1,        ' +
                          '            CURRENT_TIMESTAMP,    ' +
                          '            :FOR_ID_INCLUSAO,     ' +
                          '            :FOR_CD_MUNICIPIO)    ',
                          [RM.Emitente.Codigo,
                           Servicos.Empresa.IdEmpresa,
                           RM.Emitente.xNome,
                           RM.Emitente.xFant,
                           RM.Emitente.CNPJ,
                           RM.Emitente.IE,
                           RM.Emitente.xLgr,
                           RM.Emitente.nro,
                           RM.Emitente.xCpl,
                           RM.Emitente.xBairro,
                           RM.Emitente.CEP,
                           RM.Emitente.xMun,
                           RM.Emitente.UF,
                           RM.Emitente.XPais,
                           RM.Emitente.Fone,
                           Servicos.App.Usuario,
                           RM.Emitente.cMun],
                           True);
  
    end;
    }

    // Cabe�alho
    bdUtils.ExecutarSQL('INSERT INTO RM                    ' +
                        '           (RM_CD_RECEBIMENTO,    ' +
                        '            RM_NR_DOCUMENTO,      ' +
                        '            RM_DT_EMISSAO,        ' +
                        '            RM_DT_RECEBIMENTO,    ' +
                        '            RM_VL_TOTAL,          ' +
                        '            RM_VL_FRETE,          ' +
                        '            RM_VL_DESPESAS,       ' +
                        '            RM_VL_DESCONTO,       ' +
                        '            RM_VL_PRODUTOS,       ' +
                        '            RM_VL_IPI,            ' +
                        '            RM_VL_ICMS,           ' +
                        '            RM_VL_SUBST,          ' +
                        '            RM_CD_CFOP,           ' +
                        '            RM_TX_MODELO,         ' +
                        '            RM_TX_CHAVENF,        ' +
                        '            RM_TX_NSU,            ' +
                        '            RM_NR_SERIE)          ' +
                        '     VALUES(:RM_CD_RECEBIMENTO,   ' +
                        '            :RM_NR_DOCUMENTO,     ' +
                        QuotedStr(FormatDateTime('mm/dd/yyyy', RM.DataEmissao)) + ',' +
                        QuotedStr(FormatDateTime('mm/dd/yyyy', RM.DataEmissao)) + ',' +
                        '            :RM_VL_TOTAL,         ' +
                        '            :RM_VL_FRETE,         ' +
                        '            :RM_VL_DESPESAS,      ' +
                        '            :RM_VL_DESCONTO,      ' +
                        '            :RM_VL_PRODUTOS,      ' +
                        '            :RM_VL_IPI,           ' +
                        '            :RM_VL_ICMS,          ' +
                        '            :RM_VL_SUBST,         ' +
                        '            :RM_CD_CFOP,          ' +
                        '            :RM_TX_MODELO,        ' +
                        '            :RM_TX_CHAVENF,       ' +
                        '            :RM_TX_NSU,           ' +
                        '            :RM_NR_SERIE)         ',
                        [RM.Id,
                         RM.Numero,
                         RM.Total,
                         RM.Frete,
                         RM.Despesas,
                         RM.Descontos,
                         RM.TotalProdutos,
                         RM.IPI,
                         RM.ICMS,
                         RM.ICMSST,
                         RM.Usuario,
                         RM.SubstPagar,
                         RM.CFOP,
                         RM.Modelo,
                         RM.ChaveNF,
                         RM.NSU,
                         RM.Serie],
                         True);

    // �tens
    for i := 0 to RM.Produtos.Count - 1 do
    begin

      bdUtils.ExecutarSQL('INSERT INTO IRM                      ' +
                          '           (IRM_CD_RECEBIMENTO,      ' +
                          '            IRM_NR_ITEM,             ' +
                          '            IRM_VL_TOTAL,            ' +
                          '            IRM_VL_PERIPI,           ' +
                          '            IRM_VL_IPI,              ' +
                          '            IRM_VL_PERICMS,          ' +
                          '            IRM_VL_ICMS,             ' +
                          '            IRM_ID_INCLUSAO,         ' +
                          '            IRM_TX_CST,              ' +
                          '            IRM_VL_QTDE,             ' +
                          '            IRM_TX_UN,               ' +
                          '            IRM_VL_UNITARIO,         ' +
                          '            IRM_TX_CFOP,             ' +
                          '            IRM_VL_PERCST,           ' +
                          '            IRM_VL_BASEST,           ' +
                          '            IRM_VL_ST)               ' +
                          '    VALUES (:IRM_CD_RECEBIMENTO,     ' +
                          '            :IRM_NR_ITEM,            ' +
                          '            :IRM_VL_TOTAL,           ' +
                          '            :IRM_VL_PERIPI,          ' +
                          '            :IRM_VL_IPI,             ' +
                          '            :IRM_VL_PERICMS,         ' +
                          '            :IRM_VL_ICMS,            ' +
                          '            :IRM_ID_INCLUSAO,        ' +
                          '            :IRM_TX_CST,             ' +
                          '            :IRM_VL_QTDE,            ' +
                          QuotedStr(Copy(TRMProduto(RM.Produtos[i]).uCom, 1, 3)) + ',' +
                          '            :IRM_VL_UNITARIO,        ' +
                          '            :IRM_TX_CFOP,            ' +
                          '            :IRM_VL_PERCST,          ' +
                          '            :IRM_VL_BASEST,          ' +
                          '            :IRM_VL_ST)              ',
                          [RM.Id,
                           TRMProduto(RM.Produtos[i]).nItem,
                           TRMProduto(RM.Produtos[i]).vProd,
                           TRMProduto(RM.Produtos[i]).pIPI,
                           TRMProduto(RM.Produtos[i]).vIPI,
                           TRMProduto(RM.Produtos[i]).pICMS,
                           TRMProduto(RM.Produtos[i]).vICMS,
                           RM.Usuario,
                           TRMProduto(RM.Produtos[i]).CST,
                           TRMProduto(RM.Produtos[i]).qCom,
                           TRMProduto(RM.Produtos[i]).vUnCom,
                           TRMProduto(RM.Produtos[i]).CFOP,
                           TRMProduto(RM.Produtos[i]).pICMSST,
                           TRMProduto(RM.Produtos[i]).vBCICMSST,
                           TRMProduto(RM.Produtos[i]).vICMSST],
                           True);

    end; 

    // Faturas
    for i := 0 to RM.Faturas.Count - 1 do
    begin

      bdUtils.ExecutarSQL('INSERT INTO RMF          ' +
                          '           (RMF_CD_RM,   ' +
                          '            RMF_TX_DUP,  ' +
                          '            RMF_DT_VCTO, ' +
                          '            RMF_VL_DUP)  ' +
                          '     VALUES(:RMF_CD_RM,  ' +
                          '            :RMF_TX_DUP, ' +
                          QuotedStr(FormatDateTime('mm/dd/yyyy', TRMFatura(RM.Faturas[i]).dVenc)) + ',' +
                          '            :RMF_VL_DUP) ',
                          [RM.Id,
                           TRMFatura(RM.Faturas[i]).nDup,
                           TRMFatura(RM.Faturas[i]).vDup],
                          True);

    end;

  except

    on E:Exception do
    begin

      raise Exception.Create(E.Message + ' SQL -> ' + bdUtils.SQLCommand);

    end;

  end;

end;


end.
