unit uConfACBrDFe;

interface

uses
  Vcl.Forms,
  SysUtils,
  Variants,
  Generics.Collections,
  Classes,
  ACBrNFe,
  ACBrNFeDANFEClass,
  ACBrNFeDANFEFR,
  ACBrNFeDANFEFRDM,
  ACBrNFeDANFeRL,
  ACBrNFeDANFeRLClass,
  ACBrNFeDANFeRLPaisagem,
  ACBrNFeDANFeRLReg,
  ACBrNFeDANFeRLRetrato,
  ACBrNFeDANFeRLSimplificado,
  ACBrNFeDANFeESCPOS,
  ACBrPosPrinter,
  ACBrDFeSSL,
  DB,
  ACBrNFe.Classes,
  pcnConversao,
  pcnConversaoNFe,
  //pcnConversaoBPe,
  //pcnConversaoCIOT,
  //pcnConversaoONE,
  pcnConversaoReinf,
  blcksock;

type
  TConfTypeDFe = (TConfNFe, TConfNFCe, TConfCTe, TConfMDFe, TConfCFe, TConfSchemas, TConfDFe, TConfMail);

type
  TConfTypeEmissao = (TConfNormal, TConfContingencia, TConfSCAN, TConfDPEC, TConfFSDA, TConfSVCAN, TConfSVCRS, TConfSVCSP, TConfOffLine);

type
  TConfTypeAmbiente = (TConfProducao, TConfHomologacao);

type
  TConfQRCode = (TQR000, TQR100, TQR200);

type
  TConfVerDF = (TDF200, TDF300, TDF310, TDF400);

type
  TEscPrinter = (TDARUMA, TBEMATECH, TELGIN, TDIEBOLD, TEPSON, TEPSON2, TVOX, TPOSSTAR, TJIANG, TGPRINTER, TTEXTO);

type
  TConfSSLLib = (TLibNone, TLibOpenSSL, TLibCapicom, TLibCapicomDelphiSoap, TLibWinCrypt, TLibCustom);

type
  TConfSSLCryptLib = (TCryNone, TCryOpenSSL, TCryCapicom, TCryWinCrypt);

type
  TConfSSLHttpLib  = (THttpNone, THttpWinINet, THttpWinHttp, THttpOpenSSL, THttpIndy);

type
  TConfSSLXmlSignLib = (TXsNone, TXsXmlSec, TXsMsXml, TXsMsXmlCapicom, TXsLibXml2);

type
  TConfSSLTipoCertificado = (TTpcDesconhecido, TTpcA1, TTpcA3);

type
  TConfSSLDgst = (TDgstMD2, TDgstMD4, TDgstMD5, TDgstRMD160, TDgstSHA, TDgstSHA1, TDgstSHA256, TDgstSHA512) ;

type
  TConfSSLHashOutput = (TOutHexa, TOutBase64, TOutBinary) ;

type
  TConfSSLStoreLocation = (TSlMemory, TSlLocalMachine, TSlCurrentUser, TSlActiveDirectory, TSlSmartCard);

type
  TConfSSLType = (TLT_all, TLT_SSLv2, TLT_SSLv3, TLT_TLSv1, TLT_TLSv1_1, TLT_TLSv1_2, TLT_TLSv1_3, TLT_SSHv2);

type
  TConfArquivos = (
                   TSalvar, TNSalvar,
                   TSepararPorMes, TNSepararPorMes,
                   TAdicionarLiteral, TNAdicionarLiteral,
                   TEmissaoPathNFe, TNEmissaoPathNFe,
                   TSalvarEvento, TNSalvarEvento,
                   TSepararPorCNPJ, TNSepararPorCNPJ,
                   TSepararPorModelo, TNSepararPorModelo
                  );

type
  TConfGeral = (
                TGSalvar, TNGSalvar,
                TExibirErroSchema, TNExibirErroSchema,
                TCamposFatObrigatorios, TNCamposFatObrigatorios
               );
type
  TConfWebServices = (
                      TWSalvar, TNWSalvar,
                      TVisualizar, TNVisualizar,
                      TAjustaAguardaConsultaRes, TNAjustaAguardaConsultaRet
                     );
Type
  TConfDFeOption = (TDFeSepararPorNome, TDFeNSepararPorNome);

type
  TConfPatchDFe = (
                    TPathSalvar,
                    TPathEnviadas,
                    TPathCancelamento,
                    TPathCCe,
                    TPathInutil,
                    TPathDPEC,
                    TPathEvento,
                    TPathPDF,
                    TPathArquivos,
                    TPathLogs,
                    TPathXML,
                    TPathXMLRecebidos,
                    TPathXMLManifestados,
                    TPathResponse,
                    TPathTemp,
                    TPathBackup,
                    TPathSchemasBPe,
                    TPachSchemasCTe,
                    TPachSchemasEsocial,
                    TPachSchemasGNRe,
                    TPachSchemasGTIN,
                    TPachSchemasMDFe,
                    TPachSchemasNF3e,
                    TPachSchemasNFCom,
                    TPachSchemasNFe,
                    TPachSchemasNFSe,
                    TPachSchemasONE,
                    TPachSchemasReinf
                  );

type
  TConfDefaultPath = (TCreateDefaultPath, TNCreateDefaultPath);

type
  TConfCustonPath = (TCustonPathBefore, TCustonPathAfter);

type
  TConfigACBRDFe = class

  const
    TFFormatoAlerta = 'TAG:%TAGNIVEL% ID:%ID%/%TAG%(%DESCRICAO%) - %MSG%.';
    NomedoSistema   = 'WWSoftware''s Tecnologia - DFE Manifestador';
    FoneContato     = '75 98333-4153';

  private
    ACBRNFeComp: TACBrNFe;

  public
  class function IfThen(Condition: Boolean; VTrue, VFalse: string): string; overload;
  class function IfThen(Condition: Boolean; VTrue, VFalse: Integer): Integer; overload;
  class function IfThen(Condition: Boolean; VTrue, VFalse: Boolean): Boolean; overload;
  class function IfThen(Condition: Boolean; VTrue, VFalse: Char): Char; overload;
  class function IfThen(Condition: Boolean; VTrue, VFalse: Double): Double; overload;
  class function IfThen(Condition: Boolean; VTrue, VFalse: Variant): Variant; overload;
  class procedure ConfiguraNFe(
                                ConfTypeDFe                   : TConfTypeDFe            ;
                                FConfTypeAmbiente             : TConfTypeAmbiente       ;
                                FConfVerDF                    : TConfVerDF              ;
                                FConfTypeEmissao              : TConfTypeEmissao        ;
                                FConfQRCode                   : TConfQRCode             ;
                                FACBrNFe                      : TACBrNFe                ;
                                FACBrDANFe                    : TComponent              ;
                                FSalvar                       : TConfArquivos           ;
                                FSepararPorMes                : TConfArquivos           ;
                                FAdicionarLiteral             : TConfArquivos           ;
                                FEmissaoPathNFe               : TConfArquivos           ;
                                FSalvarEvento                 : TConfArquivos           ;
                                FSepararPorCNPJ               : TConfArquivos           ;
                                FSepararPorModelo             : TConfArquivos           ;
                                FGSalvar                      : TConfGeral              ;
                                FExibirErroSchema             : TConfGeral              ;
                                FCamposFatObrigatorios        : TConfGeral              ;
                                FWSalvar                      : TConfWebServices        ;
                                FVisualizar                   : TConfWebServices        ;
                                FAjustaAguardaConsultaRes     : TConfWebServices        ;
                                FConfDFeOption                : TConfDFeOption          ;
                                FEscPrinter                   : TEscPrinter             ;
                                FACBrPosPrinter               : TACBrPosPrinter         ;
                                FACBrNFeDANFeESCPOS           : TACBrNFeDANFeESCPOS     ;
                                FConfSSLLib                   : TConfSSLLib             ;
                                FConfSSLCryptLib              : TConfSSLCryptLib        ;
                                FConfSSLHttpLib               : TConfSSLHttpLib         ;
                                FConfSSLXmlSignLib            : TConfSSLXmlSignLib      ;
                                FConfSSLTipoCertificado       : TConfSSLTipoCertificado ;
                                FConfSSLDgst                  : TConfSSLDgst            ;
                                FConfSSLHashOutput            : TConfSSLHashOutput      ;
                                FConfSSLStoreLocation         : TConfSSLStoreLocation   ;
                                FConfSSLType                  : TConfSSLType            ;
                                FFFormatoAlerta               : String = TFFormatoAlerta;
                                IDCSNFCe                      : String = ''             ;
                                CSNFCe                        : String = ''             ;
                                FCertSenha                    : String = ''             ;
                                FCertArquivoPFX               : String = ''             ;
                                FCertNumeroSerie              : String = ''             ;
                                UFEmitente                    : String = 'BA'           ;
                                FAguardarConsultaRet          : Integer = 1000          ;
                                FTentativas                   : Integer = 0             ;
                                FIntervaloTentativas          : Integer = 1000          ;
                                FProxyHost                    : String = ''             ;
                                FProxyPort                    : String = ''             ;
                                FProxyUser                    : String = ''             ;
                                FProxyPass                    : String = ''             ;
                                FNFePathSalvar                : String = ''             ;
                                FNFePathSchemas               : String = ''             ;
                                FNFePathNFe                   : String = ''             ;
                                FNFePathInu                   : String = ''             ;
                                FNFePathEvento                : String = ''             ;
                                FNFCePathSalvar               : String = ''             ;
                                FNFCePathSchemas              : String = ''             ;
                                FNFCePathNFe                  : String = ''             ;
                                FNFCePathInu                  : String = ''             ;
                                FNFCePathEvento               : String = ''             ;
                                FDFePathDownload              : String = ''             ;
                                FEscPrinterPORT               : String = 'COM1'         ;
                                FEscPrinterBaud               : Integer = 9600          ;
                                FEscPrinterEspacoEntreLinhas  : Integer = 9600          ;
                                FEscPrinterLinhasEntreCupons  : Integer = 1             ;
                                FESCPOSLarguraBobina          : Integer = 1             ;
                                FESCPOSMargemDireita          : Double  = 0.5           ;
                                FESCPOSMargemEsquerda         : Double  = 0.5           ;
                                FESCPOSMargemInferior         : Double  = 0.5           ;
                                FESCPOSMargemSuperior         : Double  = 0.5           ;
                                FNomedoSistema                : String  = NomedoSistema ;
                                FFoneContato                  : String  = FoneContato
                              );
  end;

  var
   FConfigACBRDFe: TConfigACBRDFe;

   function ConfigureACBR(
                          ConfTypeDFe                   : TConfTypeDFe            ;
                          FConfTypeAmbiente             : TConfTypeAmbiente       ;
                          FConfVerDF                    : TConfVerDF              ;
                          FConfTypeEmissao              : TConfTypeEmissao        ;
                          FConfQRCode                   : TConfQRCode             ;
                          FACBrNFe                      : TACBrNFe                ;
                          FACBrDANFe                    : TComponent              ;
                          FSalvar                       : TConfArquivos           ;
                          FSepararPorMes                : TConfArquivos           ;
                          FAdicionarLiteral             : TConfArquivos           ;
                          FEmissaoPathNFe               : TConfArquivos           ;
                          FSalvarEvento                 : TConfArquivos           ;
                          FSepararPorCNPJ               : TConfArquivos           ;
                          FSepararPorModelo             : TConfArquivos           ;
                          FGSalvar                      : TConfGeral              ;
                          FExibirErroSchema             : TConfGeral              ;
                          FCamposFatObrigatorios        : TConfGeral              ;
                          FWSalvar                      : TConfWebServices        ;
                          FWVisualizar                  : TConfWebServices        ;
                          FWAjustaAguardaConsultaRes    : TConfWebServices        ;
                          FConfDFeOption                : TConfDFeOption          ;
                          FConfDefaultPath              : TConfDefaultPath        ;
                          FConfCustonPath               : TConfCustonPath         ;
                          FEscPrinter                   : TEscPrinter             ;
                          FACBrPosPrinter               : TACBrPosPrinter         ;
                          FACBrNFeDANFeESCPOS           : TACBrNFeDANFeESCPOS     ;
                          FConfSSLLib                   : TConfSSLLib             ;
                          FConfSSLCryptLib              : TConfSSLCryptLib        ;
                          FConfSSLHttpLib               : TConfSSLHttpLib         ;
                          FConfSSLXmlSignLib            : TConfSSLXmlSignLib      ;
                          FConfSSLTipoCertificado       : TConfSSLTipoCertificado ;
                          FConfSSLDgst                  : TConfSSLDgst            ;
                          FConfSSLHashOutput            : TConfSSLHashOutput      ;
                          FConfSSLStoreLocation         : TConfSSLStoreLocation   ;
                          FConfSSLType                  : TConfSSLType            ;
                          FFFormatoAlerta               : String = '%TAGNIVEL% ID:%ID%/%TAG%(%DESCRICAO%) - %MSG%.';
                          IDCSNFCe                      : String = ''             ;
                          CSNFCe                        : String = ''             ;
                          FCertSenha                    : String = ''             ;
                          FCertArquivoPFX               : String = ''             ;
                          FCertNumeroSerie              : String = ''             ;
                          UFEmitente                    : String = 'BA'           ;
                          FAguardarConsultaRet          : Integer = 1000          ;
                          FTentativas                   : Integer = 0             ;
                          FIntervaloTentativas          : Integer = 1000          ;
                          FProxyHost                    : String = ''             ;
                          FProxyPort                    : String = ''             ;
                          FProxyUser                    : String = ''             ;
                          FProxyPass                    : String = ''             ;
                          FNFePathSalvar                : String = ''             ;
                          FNFePathSchemas               : String = ''             ;
                          FNFePathNFe                   : String = ''             ;
                          FNFePathInu                   : String = ''             ;
                          FNFePathEvento                : String = ''             ;
                          FNFCePathSalvar               : String = ''             ;
                          FNFCePathSchemas              : String = ''             ;
                          FNFCePathNFe                  : String = ''             ;
                          FNFCePathInu                  : String = ''             ;
                          FNFCePathEvento               : String = ''             ;
                          FDFePathDownload              : String = ''             ;
                          FEscPrinterPORT               : String = 'COM1'         ;
                          FEscPrinterBaud               : Integer = 9600          ;
                          FEscPrinterEspacoEntreLinhas  : Integer = 2             ;
                          FEscPrinterLinhasEntreCupons  : Integer = 4             ;
                          FESCPOSLarguraBobina          : Integer = 80            ;
                          FESCPOSMargemDireita          : Double  = 0.3           ;
                          FESCPOSMargemEsquerda         : Double  = 0.3           ;
                          FESCPOSMargemInferior         : Double  = 0.3           ;
                          FESCPOSMargemSuperior         : Double  = 0.3           ;
                          FNomedoSistema                : String  = 'WWSoftware''s Tecnologia - DFE Manifestador';
                          FFoneContato                  : String  = '75 98333-4153'
                         ):Boolean;

   function GetPathDFe(AType: TConfTypeDFe; SubPath: TConfPatchDFe; AConfDefaultPath: TConfDefaultPath; AConfCustonPath: TConfCustonPath; YearMonthDay: string = ''; CustomDirectory: string = ''): string;
   function GetSiglaUF(IBGE: Integer): string;
   function GetIBGEBySiglaUF(const SiglaUF: string): Integer;
   function OnlyNumbers(const S: string): string;
   function FormatDateTimeToString(const DateTimeParam: TDateTime; Format: string): string;

implementation


function ConfigureACBR(
                                ConfTypeDFe                   : TConfTypeDFe            ;
                                FConfTypeAmbiente             : TConfTypeAmbiente       ;
                                FConfVerDF                    : TConfVerDF              ;
                                FConfTypeEmissao              : TConfTypeEmissao        ;
                                FConfQRCode                   : TConfQRCode             ;
                                FACBrNFe                      : TACBrNFe                ;
                                FACBrDANFe                    : TComponent              ;
                                FSalvar                       : TConfArquivos           ;
                                FSepararPorMes                : TConfArquivos           ;
                                FAdicionarLiteral             : TConfArquivos           ;
                                FEmissaoPathNFe               : TConfArquivos           ;
                                FSalvarEvento                 : TConfArquivos           ;
                                FSepararPorCNPJ               : TConfArquivos           ;
                                FSepararPorModelo             : TConfArquivos           ;
                                FGSalvar                      : TConfGeral              ;
                                FExibirErroSchema             : TConfGeral              ;
                                FCamposFatObrigatorios        : TConfGeral              ;
                                FWSalvar                      : TConfWebServices        ;
                                FWVisualizar                  : TConfWebServices        ;
                                FWAjustaAguardaConsultaRes    : TConfWebServices        ;
                                FConfDFeOption                : TConfDFeOption          ;
                                FConfDefaultPath              : TConfDefaultPath        ;
                                FConfCustonPath               : TConfCustonPath         ;
                                FEscPrinter                   : TEscPrinter             ;
                                FACBrPosPrinter               : TACBrPosPrinter         ;
                                FACBrNFeDANFeESCPOS           : TACBrNFeDANFeESCPOS     ;
                                FConfSSLLib                   : TConfSSLLib             ;
                                FConfSSLCryptLib              : TConfSSLCryptLib        ;
                                FConfSSLHttpLib               : TConfSSLHttpLib         ;
                                FConfSSLXmlSignLib            : TConfSSLXmlSignLib      ;
                                FConfSSLTipoCertificado       : TConfSSLTipoCertificado ;
                                FConfSSLDgst                  : TConfSSLDgst            ;
                                FConfSSLHashOutput            : TConfSSLHashOutput      ;
                                FConfSSLStoreLocation         : TConfSSLStoreLocation   ;
                                FConfSSLType                  : TConfSSLType            ;
                                FFFormatoAlerta               : String = '%TAGNIVEL% ID:%ID%/%TAG%(%DESCRICAO%) - %MSG%.';
                                IDCSNFCe                      : String = ''             ;
                                CSNFCe                        : String = ''             ;
                                FCertSenha                    : String = ''             ;
                                FCertArquivoPFX               : String = ''             ;
                                FCertNumeroSerie              : String = ''             ;
                                UFEmitente                    : String = 'BA'           ;
                                FAguardarConsultaRet          : Integer = 1000          ;
                                FTentativas                   : Integer = 0             ;
                                FIntervaloTentativas          : Integer = 1000          ;
                                FProxyHost                    : String = ''             ;
                                FProxyPort                    : String = ''             ;
                                FProxyUser                    : String = ''             ;
                                FProxyPass                    : String = ''             ;
                                FNFePathSalvar                : String = ''             ;
                                FNFePathSchemas               : String = ''             ;
                                FNFePathNFe                   : String = ''             ;
                                FNFePathInu                   : String = ''             ;
                                FNFePathEvento                : String = ''             ;
                                FNFCePathSalvar               : String = ''             ;
                                FNFCePathSchemas              : String = ''             ;
                                FNFCePathNFe                  : String = ''             ;
                                FNFCePathInu                  : String = ''             ;
                                FNFCePathEvento               : String = ''             ;
                                FDFePathDownload              : String = ''             ;
                                FEscPrinterPORT               : String = 'COM1'         ;
                                FEscPrinterBaud               : Integer = 9600          ;
                                FEscPrinterEspacoEntreLinhas  : Integer = 2             ;
                                FEscPrinterLinhasEntreCupons  : Integer = 4             ;
                                FESCPOSLarguraBobina          : Integer = 80            ;
                                FESCPOSMargemDireita          : Double  = 0.3           ;
                                FESCPOSMargemEsquerda         : Double  = 0.3           ;
                                FESCPOSMargemInferior         : Double  = 0.3           ;
                                FESCPOSMargemSuperior         : Double  = 0.3           ;
                                FNomedoSistema                : String  = 'WWSoftware''s Tecnologia - DFE Manifestador';
                                FFoneContato                  : String  = '75 98333-4153'

                      ):Boolean;
var
  Configurador: TConfigACBRDFe;
begin
  try

    if not(Assigned(Configurador)) then
      Configurador := TConfigACBRDFe.Create;

    // Configurando o tipo de documento fiscal eletr�nico
    Configurador.ConfiguraNFe(
      ConfTypeDFe,                               // Tipo de documento fiscal eletr�nico (NFe)
      FConfTypeAmbiente,                         // Ambiente de opera��o (Produ��o)
      FConfVerDF,                                // Vers�o do Documento Fiscal Eletr�nico (DFe)
      FConfTypeEmissao,                          // Tipo de emiss�o (Normal)
      FConfQRCode,                               // Tipo de QR Code
      FACBrNFe,                                  // Objeto TACBrNFe (se j� tiver criado)
      FACBrDANFe,                                // TACBrNFeDANFEFR(FAST REPORT) ou TACBrNFeDANFERL(FORTES REPORT)
      FSalvar,                                   // Salvar arquivos
      FSepararPorMes,                            // N�o separar arquivos por m�s
      FAdicionarLiteral,                         // N�o adicionar literal nos arquivos
      FEmissaoPathNFe,                           // N�o usar caminho de emiss�o padr�o
      FSalvarEvento,                             // N�o salvar eventos
      FSepararPorCNPJ,                           // N�o separar por CNPJ
      FSepararPorModelo,                         // N�o separar por modelo
      FGSalvar,                                  // Salvar configura��es gerais
      FExibirErroSchema,                         // N�o exibir erro de schema
      FCamposFatObrigatorios,                    // N�o tornar campos de faturamento obrigat�rios
      FWSalvar,                                  // N�o salvar configura��es de Web Services
      FWVisualizar,                              // N�o visualizar configura��es de Web Services
      FWAjustaAguardaConsultaRes,                // N�o ajustar aguarda consulta retorno
      FConfDFeOption,
      FEscPrinter,                               // Tipo de impressora (Daruma)
      FACBrPosPrinter,                           // Objeto TACBrPosPrinter (se j� tiver criado)
      FACBrNFeDANFeESCPOS,                       // Objeto TACBrNFeDANFeESCPOS (se j� tiver criado)
      FConfSSLLib,                               // Biblioteca SSL (Nenhuma)
      FConfSSLCryptLib,                          // Biblioteca de criptografia SSL (Nenhuma)
      FConfSSLHttpLib,                           // Biblioteca HTTP SSL (Nenhuma)
      FConfSSLXmlSignLib,                        // Biblioteca de assinatura XML SSL (Nenhuma)
      FConfSSLTipoCertificado,                   // Tipo de certificado SSL (Desconhecido)
      FConfSSLDgst,                              // Algoritmo de hash SSL (MD2)
      FConfSSLHashOutput,                        // Formato de sa�da de hash SSL (Hexadecimal)
      FConfSSLStoreLocation,                     // Local de armazenamento do certificado SSL (Mem�ria)
      FConfSSLType,                              // Tipo de SSL (Todos)
      FFFormatoAlerta,                           // Formato de alerta
      IDCSNFCe,                                  // ID do CSC NFCe
      CSNFCe,                                    // CSC NFCe
      FCertSenha,                                // Senha do certificado
      FCertArquivoPFX,                           // Arquivo PFX do certificado
      FCertNumeroSerie,                          // N�mero de s�rie do certificado
      TConfigACBRDFe.IfThen( not(GetSiglaUF(UFEmitente.ToInteger).IsEmpty), GetSiglaUF(UFEmitente.ToInteger), 'BA'),      // UF do emitente
      FAguardarConsultaRet,                      // Aguardar consulta de retorno
      FTentativas,                               // N�mero de tentativas
      FIntervaloTentativas,                      // Intervalo entre tentativas
      FProxyHost,                                // Host do proxy
      FProxyPort,                                // Porta do proxy
      FProxyUser,                                // Usu�rio do proxy
      FProxyPass,                                // Senha do proxy
      TConfigACBRDFe.IfThen( not(FNFePathSalvar.IsEmpty),  FNFePathSalvar, GetPathDFe(TConfNFe, TPathSalvar, FConfDefaultPath, FConfCustonPath)),             // Caminho de salvamento de arquivos NFe
      TConfigACBRDFe.IfThen( not(FNFePathSchemas.IsEmpty), FNFePathSchemas, GetPathDFe(TConfSchemas, TPachSchemasNFe, FConfDefaultPath, FConfCustonPath)),    // Caminho de esquemas NFe
      TConfigACBRDFe.IfThen( not(FNFePathNFe.IsEmpty),     FNFePathNFe, GetPathDFe(TConfNFe, TPathXML, FConfDefaultPath, FConfCustonPath)),                   // Caminho de armazenamento de NFe
      TConfigACBRDFe.IfThen( not(FNFePathInu.IsEmpty), FNFePathInu, GetPathDFe(TConfNFe, TPathInutil, FConfDefaultPath, FConfCustonPath)),                    // Caminho de armazenamento de Inutiliza��o de NFe
      TConfigACBRDFe.IfThen( not(FNFePathEvento.IsEmpty), FNFePathEvento, GetPathDFe(TConfNFe, TPathEvento, FConfDefaultPath, FConfCustonPath)),              // Caminho de armazenamento de eventos de NFe
      TConfigACBRDFe.IfThen( not(FNFCePathSalvar.IsEmpty), FNFCePathSalvar, GetPathDFe(TConfNFCe, TPathSalvar, FConfDefaultPath, FConfCustonPath)),           // Caminho de salvamento de arquivos NFCe
      TConfigACBRDFe.IfThen( not(FNFCePathSchemas.IsEmpty), FNFCePathSchemas, GetPathDFe(TConfSchemas, TPachSchemasNFe, FConfDefaultPath, FConfCustonPath)),  // Caminho de esquemas NFCe
      TConfigACBRDFe.IfThen( not(FNFCePathNFe.IsEmpty), FNFCePathNFe, GetPathDFe(TConfNFCe, TPathXML, FConfDefaultPath, FConfCustonPath)),                    // Caminho de armazenamento de NFCe
      TConfigACBRDFe.IfThen( not(FNFCePathInu.IsEmpty), FNFCePathInu, GetPathDFe(TConfNFCe, TPathInutil, FConfDefaultPath, FConfCustonPath)),                 // Caminho de armazenamento de Inutiliza��o de NFCe
      TConfigACBRDFe.IfThen( not(FNFCePathEvento.IsEmpty), FNFCePathEvento, GetPathDFe(TConfNFCe, TPathEvento, FConfDefaultPath, FConfCustonPath)),           // Caminho de armazenamento de eventos de NFCe
      TConfigACBRDFe.IfThen( not(FDFePathDownload.IsEmpty), FDFePathDownload, GetPathDFe(TConfNFe, TPathXMLRecebidos, FConfDefaultPath, FConfCustonPath)),    // Caminho de armazenamento de Download DFe
      FEscPrinterPORT,                           // Porta da impressora
      FEscPrinterBaud,                           // Baud rate da impressora
      FEscPrinterEspacoEntreLinhas,              // Espa�o entre linhas da impressora
      FEscPrinterLinhasEntreCupons,              // Linhas entre cupons da impressora
      FESCPOSLarguraBobina,                      // Largura da bobina na impressora
      FESCPOSMargemDireita,                      // Margem direita na impressora
      FESCPOSMargemEsquerda,                     // Margem esquerda na impressora
      FESCPOSMargemInferior,                     // Margem inferior na impressora
      FESCPOSMargemSuperior,                     // Margem superior na impressora
      FNomedoSistema,                            // Nome do sistema
      FFoneContato                               // Contato telef�nico
    );

  except

    on E: Exception do
    begin

      raise Exception.Create('Ocorreu um erro: ' + sLineBreak + E.Message);

    end;

  end;

end;

function GetPathDFe(AType: TConfTypeDFe; SubPath: TConfPatchDFe; AConfDefaultPath: TConfDefaultPath; AConfCustonPath: TConfCustonPath; YearMonthDay: string = ''; CustomDirectory: string = ''): string;
var
  Path: string;
begin

  try

    //if Config.SepararPorCNPJ then
    // CNPJ := TiraPontos(Config.Empresa.CNPJ);

    //if Config.SepararPorAnoMes then
    // AnoMes := FormatDateTime('yyyy', Now) + FormatDateTime('mm', Now);

    Path := ExtractFilePath(Application.ExeName);

    case AConfCustonPath of

      TCustonPathBefore:
      begin

        if CustomDirectory <> '' then
          Path := Path + CustomDirectory + '\';

        if YearMonthDay <> '' then
          Path := Path + YearMonthDay + '\';

      end;

    end;

    case AType of

      TConfNFe:          Path := Path + 'NFe\';
      TConfNFCe:         Path := Path + 'NFCe\';
      TConfCTe:          Path := Path + 'CTe\';
      TConfMDFe:         Path := Path + 'MDFe\';
      TConfCFe:          Path := Path + 'CFe\';
      TConfSchemas:      Path := Path + 'Schemas\';
      TConfDFe:          Path := Path + 'DFe\';

    end;

    case SubPath of

      TPathSalvar:             Path := Path + 'Salvar\';
      TPathEnviadas:           Path := Path + 'Enviadas\';
      TPathCancelamento:       Path := Path + 'Cancelamento\';
      TPathCCe:                Path := Path + 'CCe\';
      TPathInutil:             Path := Path + 'Inutilizados\';
      TPathDPEC:               Path := Path + 'DPEC\';
      TPathEvento:             Path := Path + 'Evento\';
      TPathPDF:                Path := Path + 'PDF\';
      TPathArquivos:           Path := Path + 'Arquivos\';
      TPathLogs:               Path := Path + 'Logs\';
      TPathXML:                Path := Path + 'XML\';
      TPathXMLRecebidos:       Path := Path + 'XMLRecebidos\';
      TPathXMLManifestados:    Path := Path + 'XMLManifestados\';
      TPathResponse:           Path := Path + 'Response\';
      TPathTemp:               Path := Path + 'Temp\';
      TPathBackup:             Path := Path + 'Backup\';
      TPathSchemasBPe:         Path := Path + 'BPe\';
      TPachSchemasCTe:         Path := Path + 'CTe\';
      TPachSchemasEsocial:     Path := Path + 'Esocial\';
      TPachSchemasGNRe:        Path := Path + 'GNRe\';
      TPachSchemasGTIN:        Path := Path + 'GTIN\';
      TPachSchemasMDFe:        Path := Path + 'MDFe\';
      TPachSchemasNF3e:        Path := Path + 'NF3e\';
      TPachSchemasNFCom:       Path := Path + 'NFCom\';
      TPachSchemasNFe:         Path := Path + 'NFe\';
      TPachSchemasNFSe:        Path := Path + 'NFSe\';
      TPachSchemasONE:         Path := Path + 'ONE\';
      TPachSchemasReinf:       Path := Path + 'Reinf\';

    end;

    case AConfCustonPath of

      TCustonPathAfter:
      begin

        if CustomDirectory <> '' then
          Path := Path + CustomDirectory + '\';

        if YearMonthDay <> '' then
          Path := Path + YearMonthDay + '\';

      end;

    end;

    case AConfDefaultPath of

      TCreateDefaultPath:
      begin

        if not DirectoryExists(Path) then
          ForceDirectories(Path);

        Result := Path;

      end;

      TNCreateDefaultPath: Result := Path;

    end;

  except

    on E: Exception do
    begin

      Result := '';
      raise Exception.Create('Ocorreu um erro: ' + sLineBreak + E.Message);

    end;

  end;

end;

function GetSiglaUF(IBGE: Integer): string;
begin

  case IBGE of

    12: Result := 'AC'; // Acre
    27: Result := 'AL'; // Alagoas
    13: Result := 'AM'; // Amazonas
    16: Result := 'AP'; // Amap�
    29: Result := 'BA'; // Bahia
    23: Result := 'CE'; // Cear�
    53: Result := 'DF'; // Distrito Federal
    32: Result := 'ES'; // Esp�rito Santo
    52: Result := 'GO'; // Goi�s
    21: Result := 'MA'; // Maranh�o
    31: Result := 'MG'; // Minas Gerais
    50: Result := 'MS'; // Mato Grosso do Sul
    51: Result := 'MT'; // Mato Grosso
    15: Result := 'PA'; // Par�
    25: Result := 'PB'; // Para�ba
    26: Result := 'PE'; // Pernambuco
    22: Result := 'PI'; // Piau�
    41: Result := 'PR'; // Paran�
    33: Result := 'RJ'; // Rio de Janeiro
    24: Result := 'RN'; // Rio Grande do Norte
    11: Result := 'RO'; // Rond�nia
    14: Result := 'RR'; // Roraima
    43: Result := 'RS'; // Rio Grande do Sul
    42: Result := 'SC'; // Santa Catarina
    28: Result := 'SE'; // Sergipe
    35: Result := 'SP'; // S�o Paulo
    17: Result := 'TO'; // Tocantins

  else

    Result := '';

  end;

end;

function GetIBGEBySiglaUF(const SiglaUF: string): Integer;
var
  SiglaToIBGEMap: TDictionary<string, Integer>;
begin

  // Inicialize o mapa de siglas para c�digos IBGE
  SiglaToIBGEMap := TDictionary<string, Integer>.Create;

  try

    SiglaToIBGEMap.Add('AC', 12); // Acre
    SiglaToIBGEMap.Add('AL', 27); // Alagoas
    SiglaToIBGEMap.Add('AM', 13); // Amazonas
    SiglaToIBGEMap.Add('AP', 16); // Amap�
    SiglaToIBGEMap.Add('BA', 29); // Bahia
    SiglaToIBGEMap.Add('CE', 23); // Cear�
    SiglaToIBGEMap.Add('DF', 53); // Distrito Federal
    SiglaToIBGEMap.Add('ES', 32); // Esp�rito Santo
    SiglaToIBGEMap.Add('GO', 52); // Goi�s
    SiglaToIBGEMap.Add('MA', 21); // Maranh�o
    SiglaToIBGEMap.Add('MG', 31); // Minas Gerais
    SiglaToIBGEMap.Add('MS', 50); // Mato Grosso do Sul
    SiglaToIBGEMap.Add('MT', 51); // Mato Grosso
    SiglaToIBGEMap.Add('PA', 15); // Par�
    SiglaToIBGEMap.Add('PB', 25); // Para�ba
    SiglaToIBGEMap.Add('PE', 26); // Pernambuco
    SiglaToIBGEMap.Add('PI', 22); // Piau�
    SiglaToIBGEMap.Add('PR', 41); // Paran�
    SiglaToIBGEMap.Add('RJ', 33); // Rio de Janeiro
    SiglaToIBGEMap.Add('RN', 24); // Rio Grande do Norte
    SiglaToIBGEMap.Add('RO', 11); // Rond�nia
    SiglaToIBGEMap.Add('RR', 14); // Roraima
    SiglaToIBGEMap.Add('RS', 43); // Rio Grande do Sul
    SiglaToIBGEMap.Add('SC', 42); // Santa Catarina
    SiglaToIBGEMap.Add('SE', 28); // Sergipe
    SiglaToIBGEMap.Add('SP', 35); // S�o Paulo
    SiglaToIBGEMap.Add('TO', 17); // Tocantins

    // Verifique se a sigla est� no mapa e retorne o c�digo IBGE correspondente
    if SiglaToIBGEMap.ContainsKey(UpperCase(SiglaUF)) then
      Result := SiglaToIBGEMap[UpperCase(SiglaUF)]
    else
      Result := 0; // Retorne 0 se a sigla n�o for encontrada

  finally

    SiglaToIBGEMap.Free;

  end;

end;

function OnlyNumbers(const S: string): string;
var
  i: Integer;
begin
  Result := '';
  for i := 1 to Length(S) do
  begin
    if CharInSet(S[i], ['0'..'9']) then
      Result := Result + S[i];
  end;
end;

function FormatDateTimeToString(const DateTimeParam: TDateTime; Format: string): string;
begin
  Result := FormatDateTime(Format, DateTimeParam);
end;

class function TConfigACBRDFe.IfThen(Condition: Boolean; VTrue, VFalse: Variant): Variant;
begin
  if Condition then
    Result := VTrue
  else
    Result := VFalse;
end;

class function TConfigACBRDFe.IfThen(Condition: Boolean; VTrue, VFalse: Integer): Integer;
begin
  if Condition then
    Result := VTrue
  else
    Result := VFalse;
end;

class function TConfigACBRDFe.IfThen(Condition: Boolean; VTrue, VFalse: string): string;
begin
  if Condition then
    Result := VTrue
  else
    Result := VFalse;
end;

class function TConfigACBRDFe.IfThen(Condition: Boolean; VTrue, VFalse: Boolean): Boolean;
begin
  if Condition then
    Result := VTrue
  else
    Result := VFalse;
end;

class function TConfigACBRDFe.IfThen(Condition: Boolean; VTrue, VFalse: Char): Char;
begin
  if Condition then
    Result := VTrue
  else
    Result := VFalse;
end;

class function TConfigACBRDFe.IfThen(Condition: Boolean; VTrue, VFalse: Double): Double;
begin
  if Condition then
    Result := VTrue
  else
    Result := VFalse;
end;

class procedure TConfigACBRDFe.ConfiguraNFe(
                                            ConfTypeDFe                   : TConfTypeDFe            ;
                                            FConfTypeAmbiente             : TConfTypeAmbiente       ;
                                            FConfVerDF                    : TConfVerDF              ;
                                            FConfTypeEmissao              : TConfTypeEmissao        ;
                                            FConfQRCode                   : TConfQRCode             ;
                                            FACBrNFe                      : TACBrNFe                ;
                                            FACBrDANFe                    : TComponent              ;
                                            FSalvar                       : TConfArquivos           ;
                                            FSepararPorMes                : TConfArquivos           ;
                                            FAdicionarLiteral             : TConfArquivos           ;
                                            FEmissaoPathNFe               : TConfArquivos           ;
                                            FSalvarEvento                 : TConfArquivos           ;
                                            FSepararPorCNPJ               : TConfArquivos           ;
                                            FSepararPorModelo             : TConfArquivos           ;
                                            FGSalvar                      : TConfGeral              ;
                                            FExibirErroSchema             : TConfGeral              ;
                                            FCamposFatObrigatorios        : TConfGeral              ;
                                            FWSalvar                      : TConfWebServices        ;
                                            FVisualizar                   : TConfWebServices        ;
                                            FAjustaAguardaConsultaRes     : TConfWebServices        ;
                                            FConfDFeOption                : TConfDFeOption          ;
                                            FEscPrinter                   : TEscPrinter             ;
                                            FACBrPosPrinter               : TACBrPosPrinter         ;
                                            FACBrNFeDANFeESCPOS           : TACBrNFeDANFeESCPOS     ;
                                            FConfSSLLib                   : TConfSSLLib             ;
                                            FConfSSLCryptLib              : TConfSSLCryptLib        ;
                                            FConfSSLHttpLib               : TConfSSLHttpLib         ;
                                            FConfSSLXmlSignLib            : TConfSSLXmlSignLib      ;
                                            FConfSSLTipoCertificado       : TConfSSLTipoCertificado ;
                                            FConfSSLDgst                  : TConfSSLDgst            ;
                                            FConfSSLHashOutput            : TConfSSLHashOutput      ;
                                            FConfSSLStoreLocation         : TConfSSLStoreLocation   ;
                                            FConfSSLType                  : TConfSSLType            ;
                                            FFFormatoAlerta               : String = TFFormatoAlerta;
                                            IDCSNFCe                      : String = ''             ;
                                            CSNFCe                        : String = ''             ;
                                            FCertSenha                    : String = ''             ;
                                            FCertArquivoPFX               : String = ''             ;
                                            FCertNumeroSerie              : String = ''             ;
                                            UFEmitente                    : String = 'BA'           ;
                                            FAguardarConsultaRet          : Integer = 1000          ;
                                            FTentativas                   : Integer = 0             ;
                                            FIntervaloTentativas          : Integer = 1000          ;
                                            FProxyHost                    : String = ''             ;
                                            FProxyPort                    : String = ''             ;
                                            FProxyUser                    : String = ''             ;
                                            FProxyPass                    : String = ''             ;
                                            FNFePathSalvar                : String = ''             ;
                                            FNFePathSchemas               : String = ''             ;
                                            FNFePathNFe                   : String = ''             ;
                                            FNFePathInu                   : String = ''             ;
                                            FNFePathEvento                : String = ''             ;
                                            FNFCePathSalvar               : String = ''             ;
                                            FNFCePathSchemas              : String = ''             ;
                                            FNFCePathNFe                  : String = ''             ;
                                            FNFCePathInu                  : String = ''             ;
                                            FNFCePathEvento               : String = ''             ;
                                            FDFePathDownload              : String = ''             ;
                                            FEscPrinterPORT               : String = 'COM1'         ;
                                            FEscPrinterBaud               : Integer = 9600          ;
                                            FEscPrinterEspacoEntreLinhas  : Integer = 9600          ;
                                            FEscPrinterLinhasEntreCupons  : Integer = 1             ;
                                            FESCPOSLarguraBobina          : Integer = 1             ;
                                            FESCPOSMargemDireita          : Double  = 0.5           ;
                                            FESCPOSMargemEsquerda         : Double  = 0.5           ;
                                            FESCPOSMargemInferior         : Double  = 0.5           ;
                                            FESCPOSMargemSuperior         : Double  = 0.5           ;
                                            FNomedoSistema                : String  = NomedoSistema ;
                                            FFoneContato                  : String  = FoneContato
                                           );
begin

  with FACBrNFe.Configuracoes.Geral do // configura��es gerais
  begin

    CamposFatObrigatorios := False;
    ExibirErroSchema      := True;
    Salvar                := True;
    FormatoAlerta         := FFFormatoAlerta;
    FormaEmissao          := TpcnTipoEmissao(FConfTypeEmissao);
    VersaoDF              := TpcnVersaoDF(FConfVerDF);

    case FConfTypeEmissao of

      TConfNormal       : FormaEmissao := TpcnTipoEmissao(FConfTypeEmissao);
      TConfContingencia : FormaEmissao := TpcnTipoEmissao(FConfTypeEmissao);
      TConfSCAN         : FormaEmissao := TpcnTipoEmissao(FConfTypeEmissao);
      TConfDPEC         : FormaEmissao := TpcnTipoEmissao(FConfTypeEmissao);
      TConfFSDA         : FormaEmissao := TpcnTipoEmissao(FConfTypeEmissao);
      TConfSVCAN        : FormaEmissao := TpcnTipoEmissao(FConfTypeEmissao);
      TConfSVCRS        : FormaEmissao := TpcnTipoEmissao(FConfTypeEmissao);
      TConfSVCSP        : FormaEmissao := TpcnTipoEmissao(FConfTypeEmissao);
      TConfOffLine      : FormaEmissao := TpcnTipoEmissao(FConfTypeEmissao);

    end;

    case FConfVerDF of

      TDF200: VersaoDF := TpcnVersaoDF(FConfVerDF);
      TDF300: VersaoDF := TpcnVersaoDF(FConfVerDF);
      TDF310: VersaoDF := TpcnVersaoDF(FConfVerDF);
      TDF400: VersaoDF := TpcnVersaoDF(FConfVerDF);

    end;

    case ConfTypeDFe of

      TConfTypeDFe.TConfNFCe:
      begin

        ModeloDF     := TpcnModeloDF(moNFCe);
        VersaoQRCode := TpcnVersaoQrCode(FConfQRCode);
        IdCSC        := IDCSNFCe;
        CSC          := CSNFCe;

      end;

      TConfTypeDFe.TConfNFe:
      begin

        ModeloDF     := TpcnModeloDF(moNFe);

      end;


    end;

    SSLLib               := TSSLLib(FConfSSLLib);
    SSLCryptLib          := TSSLCryptLib(FConfSSLCryptLib);
    SSLHttpLib           := TSSLHttpLib(FConfSSLHttpLib);
    SSLXmlSignLib        := TSSLXmlSignLib(FConfSSLXmlSignLib);
    FACBrNFe.SSL.SSLType := TSSLType(FConfSSLType);


  end;

  if not(FCertSenha.IsEmpty) then
    FACBrNFe.Configuracoes.Certificados.Senha       := FCertSenha;

  if not(FCertArquivoPFX.IsEmpty) then
    FACBrNFe.Configuracoes.Certificados.ArquivoPFX  := FCertArquivoPFX;

  if not(FCertNumeroSerie.IsEmpty) then
    FACBrNFe.Configuracoes.Certificados.NumeroSerie := FCertNumeroSerie;


  with FACBrNFe.Configuracoes.WebServices do
  begin

    UF       := UFEmitente;
    Ambiente := TpcnTipoAmbiente(FConfTypeAmbiente);

    Salvar                   := False;
    Visualizar               := False;
    AjustaAguardaConsultaRet := False;

    AguardarConsultaRet := TConfigACBRDFe.IfThen(FAguardarConsultaRet < 1000, FAguardarConsultaRet * 1000, FAguardarConsultaRet);
    Tentativas          := TConfigACBRDFe.IfThen(not(FTentativas = 0), FTentativas, 1);
    IntervaloTentativas := TConfigACBRDFe.IfThen(FIntervaloTentativas < 1000, FIntervaloTentativas * 1000, FIntervaloTentativas);

    ProxyHost := FProxyHost;
    ProxyPort := FProxyPort;
    ProxyUser := FProxyUser;
    ProxyPass := FProxyPass;

  end;

  with FACBrNFe.Configuracoes.Arquivos do
  begin

    case FSalvar of
      TConfArquivos.TSalvar: Salvar  := True;
      TConfArquivos.TNSalvar: Salvar := False;
    end;

    case FSepararPorMes of
      TConfArquivos.TSepararPorMes:  SepararPorMes := True;
      TConfArquivos.TNSepararPorMes: SepararPorMes := False;
    end;

    case FAdicionarLiteral of
      TConfArquivos.TAdicionarLiteral:  AdicionarLiteral := True;
      TConfArquivos.TNAdicionarLiteral: AdicionarLiteral := False;
    end;

    case FEmissaoPathNFe of
      TConfArquivos.TEmissaoPathNFe:  EmissaoPathNFe := True;
      TConfArquivos.TNEmissaoPathNFe: EmissaoPathNFe := False;
    end;

    case FSalvarEvento of
      TConfArquivos.TSalvarEvento:  SalvarEvento := True;
      TConfArquivos.TNSalvarEvento: SalvarEvento := False;
    end;

    case FSepararPorCNPJ of
      TConfArquivos.TSepararPorCNPJ:  SepararPorCNPJ := True;
      TConfArquivos.TNSepararPorCNPJ: SepararPorCNPJ := False;
    end;

    case FSepararPorModelo of
      TConfArquivos.TSepararPorModelo:  SepararPorModelo := True;
      TConfArquivos.TNSepararPorModelo: SepararPorModelo := False;
    end;

    case ConfTypeDFe of

      TConfTypeDFe.TConfNFe:
      begin
        PathSalvar  := FNFePathSalvar;
        PathSchemas := FNFePathSchemas;
        PathNFe     := FNFePathNFe;
        PathInu     := FNFePathInu;
        PathEvento  := FNFePathEvento;
      end;

      TConfTypeDFe.TConfNFCe:
      begin
        PathSalvar  := FNFCePathSalvar;
        PathSchemas := FNFCePathSchemas;
        PathNFe     := FNFCePathNFe;
        PathInu     := FNFCePathInu;
        PathEvento  := FNFCePathEvento;
      end;

    end;

    with DownloadDFe do
    begin

      DownloadDFe.PathDownload          := FDFePathDownload;

      case FConfDFeOption of

         TDFeSepararPorNome:  DownloadDFe.SepararPorNome        := True;
         TDFeNSepararPorNome: DownloadDFe.SepararPorNome        := False;

      end;


    end;

  end;

  TACBrNFe(FACBRNFe).DANFE := FACBrDANFe as TACBrNFeDANFEClass ;

  with (FACBrDANFe as TACBrNFeDANFEClass) do
  begin

    Sistema           := FNomedoSistema + ' | ' + FFoneContato ;
    Site              := SITE;
    TipoDANFE         := tiRetrato;
    MargemDireita     := 5;
    MargemEsquerda    := 7;
    MargemInferior    := 5;
    MargemSuperior    := 5;

  end;


  with FACBrPosPrinter do
  begin

    Desativar;

    Porta               := LowerCase(FEscPrinterPORT);
    Device.Baud         := FEscPrinterBaud;
    EspacoEntreLinhas   := FEscPrinterEspacoEntreLinhas;
    LinhasEntreCupons   := FEscPrinterLinhasEntreCupons;

    case FEscPrinter of

        TEscPrinter.TDARUMA:   modelo := ppEscDaruma;
        TEscPrinter.TBEMATECH: modelo := ppEscBematech;
        TEscPrinter.TELGIN:    modelo := ppEscPosEpson;
        TEscPrinter.TDIEBOLD:  modelo := ppEscDiebold;
        TEscPrinter.TEPSON:    modelo := ppEscPosEpson;
        TEscPrinter.TEPSON2:   modelo := ppEscEpsonP2;
        TEscPrinter.TVOX:      modelo := ppEscVox;
        TEscPrinter.TPOSSTAR:  modelo := ppEscPosStar;
        TEscPrinter.TJIANG:    modelo := ppEscZJiang;
        TEscPrinter.TGPRINTER: modelo := ppEscGPrinter;
        TEscPrinter.TTEXTO:    modelo := ppTexto;

    end;

  end;

  with FACBrNFeDANFeESCPOS do
  begin

    LarguraBobina     := FESCPOSLarguraBobina;
    MargemDireita     := FESCPOSMargemDireita;
    MargemEsquerda    := FESCPOSMargemEsquerda;
    MargemInferior    := FESCPOSMargemInferior;
    MargemSuperior    := FESCPOSMargemSuperior;
    ImprimeEmUmaLinha := true;
    ImprimeEmUmaLinha := false;
    Sistema           := FNomedoSistema + ' | ' + FFoneContato ;
    Site              := SITE;

  end;

end;

end.
