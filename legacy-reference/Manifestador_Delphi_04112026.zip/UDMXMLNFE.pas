unit UDMXMLNFE;

interface

uses
  SysUtils, Classes, ACBrBase, ACBrDFe, ACBrNFe, Controls, pcnConversao;

type

  TDMXMLNFE = class(TDataModule)
    ACBrNFe1: TACBrNFe;
  private

    { Private declarations }
    FNomeArquivoXML: String;
    FCNPJDestinado: String;
    FNSU: String;
    FIdManifestador: Integer;
    procedure SetNomeArquivoXML(const Value: String);
    procedure SetCNPJDestinado(const Value: String);
    procedure SetNSU(const Value: String);
    procedure SetIdManifestador(const Value: Integer);

  public

    { Public declarations }
    property NomeArquivoXML: String read FNomeArquivoXML write SetNomeArquivoXML;
    property CNPJDestinado: String read FCNPJDestinado write SetCNPJDestinado;
    property NSU: String read FNSU write SetNSU;
    property IdManifestador: Integer read FIdManifestador write SetIdManifestador;
    function Importar(IdNF: Integer): Boolean;

  end;

var
  DMXMLNFE: TDMXMLNFE;

implementation

uses ACBrNFe.Classes, ACBrNFeNotasFiscais, DB, uBDUtils;

{$R *.dfm}

{ TDMXMLNFE }

procedure TDMXMLNFE.SetNomeArquivoXML(const Value: String);
begin

  FNomeArquivoXML := Value;

end;

function TDMXMLNFE.Importar(IdNF: Integer): Boolean;
var
  i: integer;
  ST, CSOSN: Integer;
begin

  Result := False;

  if (not FileExists(FNomeArquivoXML)) then
    raise Exception.Create('Arquivo ' + FNomeArquivoXML + ' n�o encontrado.');

  try

    ACBrNFe1.NotasFiscais.Clear;
    ACBrNFe1.NotasFiscais.LoadFromFile(FNomeArquivoXML);

    // Atualiza os dados do cabe�alho da nota fiscal
    bdUtils.ExecutarSQL('UPDATE NF                                             ' +
                        '   SET TOTAL_PRODUTOS        = :TOTAL_PRODUTOS,       ' +
                        '       VALOR_FRETE           = :VALOR_FRETE,          ' +
                        '       VALOR_DESPESAS        = :VALOR_DESPESAS,       ' +
                        '       VALOR_DESCONTO        = :VALOR_DESCONTO,       ' +
                        '       VALOR_IPI             = :VALOR_IPI,            ' +
                        '       VALOR_ICMS            = :VALOR_ICMS,           ' +
                        '       VALOR_ICMSST          = :VALOR_ICMSST,         ' +
                        '       ENDERECO              = :ENDERECO,             ' +
                        '       ENDERECO_NUMERO       = :ENDERECO_NUMERO,      ' +
                        '       ENDERECO_COMPLEMENTO  = :ENDERECO_COMPLEMENTO, ' +
                        '       ENDERECO_BAIRRO       = :ENDERECO_BAIRRO,      ' +
                        '       ENDERECO_CEP          = :ENDERECO_CEP,         ' +
                        '       ENDERECO_CIDADE       = :ENDERECO_CIDADE,      ' +
                        '       ENDERECO_CODMUNICIPIO = :ENDERECO_CODMUNICIPIO,' +
                        '       TELEFONE              = :TELEFONE              '+
                        ' WHERE CODIGO = :CODIGO                               ',
                        [ACBrNFe1.NotasFiscais.Items[0].NFe.Total.ICMSTot.vProd,
                         ACBrNFe1.NotasFiscais.Items[0].NFe.Total.ICMSTot.vFrete,
                         ACBrNFe1.NotasFiscais.Items[0].NFe.Total.ICMSTot.vOutro,
                         ACBrNFe1.NotasFiscais.Items[0].NFe.Total.ICMSTot.vDesc,
                         ACBrNFe1.NotasFiscais.Items[0].NFe.Total.ICMSTot.vIPI,
                         ACBrNFe1.NotasFiscais.Items[0].NFe.Total.ICMSTot.vICMS,
                         ACBrNFe1.NotasFiscais.Items[0].NFe.Total.ICMSTot.vST,
                         ACBrNFe1.NotasFiscais.Items[0].NFe.Emit.EnderEmit.xLgr,
                         ACBrNFe1.NotasFiscais.Items[0].NFe.Emit.EnderEmit.nro,
                         ACBrNFe1.NotasFiscais.Items[0].NFe.Emit.EnderEmit.xCpl,
                         ACBrNFe1.NotasFiscais.Items[0].NFe.Emit.EnderEmit.xBairro,
                         ACBrNFe1.NotasFiscais.Items[0].NFe.Emit.EnderEmit.CEP,
                         ACBrNFe1.NotasFiscais.Items[0].NFe.Emit.EnderEmit.xMun,
                         ACBrNFe1.NotasFiscais.Items[0].NFe.Emit.EnderEmit.cMun,
                         ACBrNFe1.NotasFiscais.Items[0].NFe.Emit.EnderEmit.fone,
                         IdNF]);

    // Inclui os �tens da nota fiscal
    for i := 0 to ACBrNFe1.NotasFiscais.Items[0].NFe.Det.Count - 1 do
    begin

      ST := 00;

      case ACBrNFe1.NotasFiscais.Items[0].NFe.Det.Items[I].Imposto.ICMS.CST of

        cst00: ST := 00;
        cst10: ST := 10;
        cst20: ST := 20;
        cst30: ST := 30;
        cst40: ST := 40;
        cst41: ST := 41;
        cst45: ST := 45;
        cst50: ST := 50;
        cst51: ST := 51;
        cst60: ST := 60;
        cst70: ST := 70;
        cst80: ST := 80;
        cst81: ST := 81;
        cst90: ST := 90;

      end;

      CSOSN := 0;

      case ACBrNFe1.NotasFiscais.Items[0].NFe.Det.Items[I].Imposto.ICMS.CSOSN of

        csosnVazio: CSOSN := 0;
        csosn101: CSOSN := 101;
        csosn102: CSOSN := 102;
        csosn103: CSOSN := 103;
        csosn201: CSOSN := 201;
        csosn202: CSOSN := 202;
        csosn203: CSOSN := 203;
        csosn300: CSOSN := 300;
        csosn400: CSOSN := 400;
        csosn500: CSOSN := 500;
        csosn900: CSOSN := 900;

      end;

      bdUtils.ExecutarSQL('INSERT INTO ITENS        ' +
                          '           (NF,          ' +
                          '            ITEM,        ' +
                          '            CPROD,       ' +
                          '            XPROD,       ' +
                          '            NCM,         ' +
                          '            CFOP,        ' +
                          '            UCOM,        ' +
                          '            QCOM,        ' +
                          '            UTRIB,       ' +
                          '            QTRIB,       ' +
                          '            VUNTRIB,     ' +
                          '            ORIG,        ' +
                          '            CSOSN,       ' +
                          '            ST,          ' +
                          '            VBCICMS,     ' +
                          '            PICMS,       ' +
                          '            VICMS,       ' +
                          '            VICMSST,     ' +
                          '            VBCICMSST,   ' +
                          '            VIPI,        ' +
                          '            PIPI)        ' +
                          '    VALUES (:NF,         ' +
                          '            :ITEM,       ' +
                          '            :CPROD,      ' +
                          '            :XPROD,      ' +
                          '            :NCM,        ' +
                          '            :CFOP,       ' +
                          '            :UCOM,       ' +
                          '            :QCOM,       ' +
                          '            :UTRIB,      ' +
                          '            :QTRIB,      ' +
                          '            :VUNTRIB,    ' +
                          '            :ORIG,       ' +
                          '            :CSOSN,      ' +
                          '            :ST,         ' +
                          '            :VBCICMS,    ' +
                          '            :PICMS,      ' +
                          '            :VICMS,      ' +
                          '            :VICMSST,    ' +
                          '            :VBCICMSST,  ' +
                          '            :VIPI,       ' +
                          '            :PIPI)       ',
                          [IdNF,
                           ACBrNFe1.NotasFiscais.Items[0].NFe.Det.Items[I].Prod.nItem,
                           ACBrNFe1.NotasFiscais.Items[0].NFe.Det.Items[I].Prod.cProd,
                           ACBrNFe1.NotasFiscais.Items[0].NFe.Det.Items[I].Prod.xProd,
                           ACBrNFe1.NotasFiscais.Items[0].NFe.Det.Items[I].Prod.NCM,
                           ACBrNFe1.NotasFiscais.Items[0].NFe.Det.Items[I].Prod.CFOP,
                           ACBrNFe1.NotasFiscais.Items[0].NFe.Det.Items[I].Prod.uCom,
                           ACBrNFe1.NotasFiscais.Items[0].NFe.Det.Items[I].Prod.qCom,
                           ACBrNFe1.NotasFiscais.Items[0].NFe.Det.Items[I].Prod.uTrib,
                           ACBrNFe1.NotasFiscais.Items[0].NFe.Det.Items[I].Prod.qTrib,
                           ACBrNFe1.NotasFiscais.Items[0].NFe.Det.Items[I].Prod.vUnTrib,
                           Integer(ACBrNFe1.NotasFiscais.Items[0].NFe.Det.Items[I].Imposto.ICMS.orig),
                           CSOSN,
                           ST,
                           ACBrNFe1.NotasFiscais.Items[0].NFe.Det.Items[I].Imposto.ICMS.vBC,
                           ACBrNFe1.NotasFiscais.Items[0].NFe.Det.Items[I].Imposto.ICMS.pICMS,
                           ACBrNFe1.NotasFiscais.Items[0].NFe.Det.Items[I].Imposto.ICMS.vICMS,
                           ACBrNFe1.NotasFiscais.Items[0].NFe.Det.Items[I].Imposto.ICMS.vICMSST,
                           ACBrNFe1.NotasFiscais.Items[0].NFe.Det.Items[I].Imposto.ICMS.vBCST,
                           ACBrNFe1.NotasFiscais.Items[0].NFe.Det.Items[I].Imposto.IPI.vIPI,
                           ACBrNFe1.NotasFiscais.Items[0].NFe.Det.Items[I].Imposto.IPI.pIPI]);

    end;

    Result := True;

  except

    on E:Exception do
    begin

      raise Exception.Create(E.Message);

    end;

  end;

end;

procedure TDMXMLNFE.SetCNPJDestinado(const Value: String);
begin
  FCNPJDestinado := Value;
end;

procedure TDMXMLNFE.SetNSU(const Value: String);
begin
  FNSU := Value;
end;

procedure TDMXMLNFE.SetIdManifestador(const Value: Integer);
begin
  FIdManifestador := Value;
end;

end.
