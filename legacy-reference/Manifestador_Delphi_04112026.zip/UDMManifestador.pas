unit UDMManifestador;

interface

uses
  System.SysUtils, System.Classes,  ACBrNFeDANFEClass, ACBrNFeDANFeRLClass,
  ACBrBase, ACBrDFe, ACBrNFe, ACBrDFeSSL, pcnConversao, pcnConversaoNFe, Vcl.Forms,
  Vcl.Controls, Xml.xmldom, Xml.XMLIntf, Xml.XMLDoc, Data.DB, Vcl.ActnList,
  Vcl.Dialogs, Vcl.ExtCtrls, System.zip, ACBrMail,
  FireDAC.Stan.Intf, FireDAC.Stan.Option, FireDAC.Stan.Error, FireDAC.UI.Intf,
  FireDAC.Phys.Intf, FireDAC.Stan.Def, FireDAC.Stan.Pool, FireDAC.Stan.Async,
  FireDAC.Phys, FireDAC.VCLUI.Wait, FireDAC.Stan.ExprFuncs,
  FireDAC.Phys.SQLiteDef, FireDAC.Phys.SQLite, FireDAC.Comp.UI,
  FireDAC.Comp.Client, FireDAC.Stan.Param, FireDAC.DatS, FireDAC.DApt.Intf,
  FireDAC.DApt, FireDAC.Comp.DataSet, ACBrDFeReport, ACBrDFeDANFeReport,
  FireDAC.Phys.SQLiteWrapper.Stat, DateUtils, MemDS, DBAccess, Uni, UniProvider,
  SQLiteUniProvider, InterBaseUniProvider, ACBrPosPrinter, ACBrNFeDANFeESCPOS;

type

  TDMManifestador = class(TDataModule)

    ACBrNFe: TACBrNFe;
    ACBrNFeDANFeRL1: TACBrNFeDANFeRL;
    XMLDocument1: TXMLDocument;
    ACBrNFeImprimir: TACBrNFe;
    SaveDialogPDF: TSaveDialog;
    TimerVerificar: TTimer;
    ACBrMail1: TACBrMail;
    FDConnection1: TUniConnection;
    FDGUIxWaitCursor1: TFDGUIxWaitCursor;
    ZQueryCFG: TUniQuery;
    ZQueryNF: TUniQuery;
    ZQueryExisteNota: TUniQuery;
    ZQueryNSU: TUniQuery;
    ZQueryEmpresa: TUniQuery;
    ZQueryNF_LOG: TUniQuery;
    Firebird: TInterBaseUniProvider;
    ZQueryCFGCODIGO: TIntegerField;
    ZQueryCFGVERIFICAR_AUTOMATICO: TStringField;
    ZQueryCFGDOWNLOAD_AUTOMATICO: TStringField;
    ZQueryCFGTIMER: TIntegerField;
    ZQueryCFGSMTP: TStringField;
    ZQueryCFGSMTP_CONTA: TStringField;
    ZQueryCFGSMTP_REMETENTE: TStringField;
    ZQueryCFGSMTP_EMAIL: TStringField;
    ZQueryCFGSMTP_SENHA: TStringField;
    ZQueryCFGSMTP_PORTA: TStringField;
    ZQueryNFCODIGO: TIntegerField;
    ZQueryNFID_EMPRESA: TIntegerField;
    ZQueryNFNUMERO: TStringField;
    ZQueryNFSERIE: TStringField;
    ZQueryNFCNPJ: TStringField;
    ZQueryNFNOME: TStringField;
    ZQueryNFEMISSAO: TDateTimeField;
    ZQueryNFVALOR: TFloatField;
    ZQueryNFTIPO: TStringField;
    ZQueryNFSITUACAO: TStringField;
    ZQueryNFCHAVE: TStringField;
    ZQueryNFIE: TStringField;
    ZQueryNFPROTOCOLO: TStringField;
    ZQueryNFDATAREC: TDateTimeField;
    ZQueryNFMANIFESTACAO: TStringField;
    ZQueryNFDOWNLOAD: TStringField;
    ZQueryNFAMBIENTE: TStringField;
    ZQueryNFNSU: TStringField;
    ZQueryNFVISIVEL: TStringField;
    ZQueryNFTOTAL_PRODUTOS: TFloatField;
    ZQueryNFVALOR_FRETE: TFloatField;
    ZQueryNFVALOR_DESPESAS: TFloatField;
    ZQueryNFVALOR_DESCONTO: TFloatField;
    ZQueryNFVALOR_IPI: TFloatField;
    ZQueryNFVALOR_ICMS: TFloatField;
    ZQueryNFVALOR_ICMSST: TFloatField;
    ZQueryNFENDERECO: TStringField;
    ZQueryNFENDERECO_NUMERO: TStringField;
    ZQueryNFENDERECO_COMPLEMENTO: TStringField;
    ZQueryNFENDERECO_BAIRRO: TStringField;
    ZQueryNFENDERECO_CEP: TStringField;
    ZQueryNFENDERECO_CIDADE: TStringField;
    ZQueryNFENDERECO_CODMUNICIPIO: TStringField;
    ZQueryNFTELEFONE: TStringField;
    ZQueryNF_LOGCODIGO: TIntegerField;
    ZQueryNF_LOGID_NF: TIntegerField;
    ZQueryNF_LOGOPERACAO: TIntegerField;
    ZQueryNF_LOGDATAHORA: TDateTimeField;
    ZQueryNF_LOGHISTORICO: TStringField;
    Transaction: TUniTransaction;
    ZQueryEmpresaCODIGO: TIntegerField;
    ZQueryEmpresaCNPJ: TStringField;
    ZQueryEmpresaCERTIFICADO: TStringField;
    ZQueryEmpresaSENHA: TStringField;
    ZQueryEmpresaUF: TStringField;
    ZQueryEmpresaCAMINHO: TStringField;
    ZQueryEmpresaNOME: TStringField;
    ZQueryEmpresaNUMERO_SERIE: TStringField;
    ZQueryEmpresaCAMINHO_COPIA_XML: TStringField;
    ZQueryEmpresaDATA_MANIFESTACAO: TDateTimeField;
    ACBrPosPrinter: TACBrPosPrinter;
    ACBrNFeDANFeESCPOS: TACBrNFeDANFeESCPOS;
    ZQueryEmpresaCAMINHO_RESPONSE: TStringField;
    ZQueryNFXML: TBlobField;
    ZQueryNFXML_PATH: TStringField;
    procedure DataModuleCreate(Sender: TObject);
    procedure ZQueryNFAfterScroll(DataSet: TDataSet);
    procedure ZQueryNFAfterOpen(DataSet: TDataSet);
    procedure ZQueryCFGNewRecord(DataSet: TDataSet);
    procedure TimerVerificarTimer(Sender: TObject);
    procedure ZQueryNF_LOGBeforeOpen(DataSet: TDataSet);
    procedure FDConnection1BeforeConnect(Sender: TObject);
    procedure ZQueryNFNewRecord(DataSet: TDataSet);
    procedure FDConnection1AfterDisconnect(Sender: TObject);
    procedure ZQueryEmpresaNewRecord(DataSet: TDataSet);
    procedure ZQueryEmpresaAfterPost(DataSet: TDataSet);
    procedure ZQueryEmpresaBeforeCancel(DataSet: TDataSet);
    procedure ZQueryExisteNotaNewRecord(DataSet: TDataSet);
    procedure ZQueryNF_LOGNewRecord(DataSet: TDataSet);
    procedure ZQueryNSUNewRecord(DataSet: TDataSet);
    procedure ZQueryCFGBeforeCancel(DataSet: TDataSet);
    procedure ZQueryNFBeforeCancel(DataSet: TDataSet);
    procedure ZQueryExisteNotaBeforeCancel(DataSet: TDataSet);
    procedure ZQueryNF_LOGBeforeCancel(DataSet: TDataSet);
    procedure ZQueryNSUBeforeCancel(DataSet: TDataSet);
    procedure ZQueryNF_LOGAfterPost(DataSet: TDataSet);
    procedure ZQueryNSUAfterPost(DataSet: TDataSet);
    procedure ZQueryExisteNotaAfterPost(DataSet: TDataSet);
    procedure ZQueryNFAfterPost(DataSet: TDataSet);
    procedure ZQueryCFGAfterPost(DataSet: TDataSet);
    procedure FDConnection1AfterConnect(Sender: TObject);

  private

    { Private declarations }
    FActionManifestar: TAction;
    FActionDownload: TAction;
    FActionVisualizar: TAction;

    procedure SetActionManifestar(const Value: TAction);
    procedure SetActionDownload(const Value: TAction);
    procedure SetActionVisualizar(const Value: TAction);
    function ExisteNota(Chave: String): Boolean;
    procedure UpdateManifestar(CodigoNotaFiscal: Integer);
    procedure UpdateDownload(CodigoNotaFiscal: Integer; const XMLFileName: string);
    procedure ManifestacaoAutomatica;
    procedure DownloadAutomatico;

  public

    { Public declarations }
    procedure ConfigurarAcbr(FACBrNFe: TACBrNFe);
    procedure ConfigurarAcbrImprimir;
    procedure ListarNotas(Inicio, Fim: TDate; Baixadas, Manifestadas: Boolean);
    function ObterUltimoNSU(Ambiente: String): Integer;
    procedure Mensagem(Texto: string);
    procedure ExibirDialogoProcessamento;
    procedure OcultarDialogoProcessamento;
    procedure ObterNotas(TIPO: string = '');
    procedure Manifestar(CodigoNotaFiscal, TipoManifestacao: Integer; ChaveNF: String; Refresh: Boolean; Motivo: String = '');
    procedure Download(CodigoNotaFiscal: Integer; ChaveNF: String; Refresh: Boolean; NSU: string);
    procedure Visualizar(GerarPDF: Boolean);
    procedure ConfigurarTimer;
    procedure GerarZip(ZipFileName: String; FilesToZip: TStringList);
    procedure ConfigurarAcbrMail;
    procedure GerarLogNF(CodigoNotaFiscal, CodigoOperacao: Integer; Msg: String = '');
    procedure MainLoaderSystem;
    function Importar(CodigoNotaFiscal: Integer; ArquivoXML: String): Boolean;
    property ActionManifestar: TAction read FActionManifestar write SetActionManifestar;
    property ActionDownload: TAction read FActionDownload write SetActionDownload;
    property ActionVisualizar: TAction read FActionVisualizar write SetActionVisualizar;

  end;

var
  DMManifestador: TDMManifestador;

implementation

uses
  UfrmProcessamento,
  uBDUtils,
  uBDUtilsFactory,
  uBDUtilsDBExpress,
  UDMXMLNFE,
  uIdGenerator,
  uConfACBrDFe,
  ufrmPrincipal,
  uWKConnectionParams;

{%CLASSGROUP 'Vcl.Controls.TControl'}

{$R *.dfm}

procedure TDMManifestador.DataModuleCreate(Sender: TObject);
//var
// FConn: TWKConnectionClass;
begin

  {$REGION ' CHECAGEM DE PARAMETROS '}
    {
    FConn := TWKConnectionClass.Create;

    FParamsOptions.GetParamsOptions;
    }
  {$ENDREGION}

  {$REGION ' CONECTA BANCO DE DADOS '}
    {
    if FConn.Connect(FDConnection1, Transaction, Firebird) then
    begin

      try

        FDConnection1.Connected := True;

      except

        FConn.RunDBConfig;

      end;

    end
    else
    begin

      FConn.RunDBConfig;

    end;
    }
  {$ENDREGION}

   {
  // Instancia na mem�ria o formul�rio de exibi��o do processamento
  frmProcessamento := TfrmProcessamento.Create(Application);
  // Abre a query de configura��es gerais
  ZQueryCFG.Open;
  // Carrega as configura��es do timer
  ConfigurarTimer;
  // Abre a query EMPRESA
  zQueryEMPRESA.Open;
  // Configura o componente Acbr
  ConfigurarAcbr;
  }

  //MainLoaderSystem;

end;

procedure TDMManifestador.ConfigurarTimer;
begin

  if (ZQueryCFGVERIFICAR_AUTOMATICO.AsString = 'S') and (ZQueryCFGTIMER.AsInteger > 0) then
  begin

    TimerVerificar.Interval := ZQueryCFGTIMER.AsInteger * 60000;
    TimerVerificar.Enabled  := True;

  end;

end;

procedure TDMManifestador.ConfigurarAcbrImprimir;
begin

  if ZQueryEmpresa.IsEmpty then
    Exit;

  ConfigureACBR(
                TConfNFe, TConfProducao, TDF400, TConfNormal, TQR200, ACBrNFeImprimir, ACBrNFeDANFeRL1,
                TSalvar, TSepararPorMes, TNAdicionarLiteral, TEmissaoPathNFe, TSalvarEvento, TNSepararPorCNPJ, TNSepararPorModelo,
                TGSalvar, TExibirErroSchema, TCamposFatObrigatorios, TWSalvar, TVisualizar, TAjustaAguardaConsultaRes,
                TDFeNSepararPorNome, TNCreateDefaultPath, TCustonPathAfter, TTEXTO,
                ACBrPosPrinter, ACBrNFeDANFeESCPOS,
                TConfSSLLib(TConfigACBRDFe.IfThen( not(zQueryEMPRESACERTIFICADO.IsNull), 1, 1)),              // A1 ou A3 por Arquivo ou N�mero de S�rie,
                TConfSSLCryptLib(TConfigACBRDFe.IfThen( not(zQueryEMPRESACERTIFICADO.IsNull), 3, 3)), //1     // A1 ou A3 por Arquivo ou N�mero de S�rie,
                TConfSSLHttpLib(TConfigACBRDFe.IfThen( not(zQueryEMPRESACERTIFICADO.IsNull), 2, 2)),  //3     // A1 ou A3 por Arquivo ou N�mero de S�rie,
                TConfSSLXmlSignLib(TConfigACBRDFe.IfThen( not(zQueryEMPRESACERTIFICADO.IsNull), 4, 4)),       // A1 ou A3 por Arquivo ou N�mero de S�rie,
                TConfSSLTipoCertificado(TConfigACBRDFe.IfThen( not(zQueryEMPRESACERTIFICADO.IsNull),  2, 1)), // A1 ou A3 por Arquivo ou N�mero de S�rie,
                TDgstSHA, TOutHexa, TSlMemory, TLT_all, '%TAGNIVEL% ID:%ID%/%TAG%(%DESCRICAO%) - %MSG%.',
                ''{ID do CSC NFCe},''{CSC NFCe},
                TConfigACBRDFe.IfThen( not(zQueryEMPRESACERTIFICADO.IsNull),  zQueryEMPRESACERTIFICADO.AsString, ''),   // Senha do certificado
                TConfigACBRDFe.IfThen( not(zQueryEMPRESASENHA.IsNull),  zQueryEMPRESASENHA.AsString, ''),               // Arquivo PFX do certificado
                TConfigACBRDFe.IfThen( not(ZQueryEMPRESANUMERO_SERIE.IsNull),  ZQueryEMPRESANUMERO_SERIE.AsString, ''), // N�mero de s�rie do certificado
                ZQueryEmpresaUF.AsString,
                1000,                                    // Aguardar consulta de retorno
                1,                                       // N�mero de tentativas
                1000,                                    // Intervalo entre tentativas
                '',                                      // Host do proxy
                '',                                      // Porta do proxy
                '',                                      // Usu�rio do proxy
                '',                                      // Senha do proxy
                TConfigACBRDFe.IfThen( not(ZQueryEmpresaCAMINHO_RESPONSE.IsNull),  ZQueryEmpresaCAMINHO_RESPONSE.AsString,
                GetPathDFe(TConfNFe, TPathResponse, TCreateDefaultPath, TCustonPathAfter, '', ZQueryEmpresaNOME.AsString + ' - ' + OnlyNumbers(ZQueryEmpresaCNPJ.AsString))),    // Caminho de salvamento de arquivos NFe
                '',                                      // Caminho de esquemas NFe
                '',                                      // Caminho de armazenamento de NFe
                '',                                      // Caminho de armazenamento de Inutiliza��o de NFe
                '',                                      // Caminho de armazenamento de eventos de NFe
                '',                                      // Caminho de salvamento de arquivos NFCe
                '',                                      // Caminho de esquemas NFCe
                '',                                      // Caminho de armazenamento de NFCe
                '',                                      // Caminho de armazenamento de Inutiliza��o de NFCe
                '',                                      // Caminho de armazenamento de eventos de NFCe
                TConfigACBRDFe.IfThen( not(ZQueryEmpresaCAMINHO.IsNull),  ZQueryEmpresaCAMINHO.AsString,
                GetPathDFe(TConfNFe, TPathXMLRecebidos, TCreateDefaultPath, TCustonPathAfter, '', ZQueryEmpresaNOME.AsString + ' - ' + OnlyNumbers(ZQueryEmpresaCNPJ.AsString))), // Caminho de armazenamento de Download DFe
                'COM1',                                  // Porta da impressora
                9600,                                    // Baud rate da impressora
                9600,                                    // Espa�o entre linhas da impressora
                1,                                       // Linhas entre cupons da impressora
                1,                                       // Largura da bobina na impressora
                0.5,                                     // Margem direita na impressora
                0.5,                                     // Margem esquerda na impressora
                0.5,                                     // Margem inferior na impressora
                0.5,                                     // Margem superior na impressora
                'WWSoftware''s Tecnologia - DFE Manifestador', // Nome do sistema
                '75 98333-4153'                          // Contato telef�nico
               );

end;

procedure TDMManifestador.ConfigurarAcbr(FACBrNFe: TACBrNFe);
begin

  if ZQueryEmpresa.IsEmpty then
    Exit;

  ConfigureACBR(
                TConfNFe, TConfProducao, TDF400, TConfNormal, TQR200, FACBrNFe, ACBrNFeDANFeRL1,
                TSalvar, TSepararPorMes, TNAdicionarLiteral, TEmissaoPathNFe, TSalvarEvento, TNSepararPorCNPJ, TNSepararPorModelo,
                TGSalvar, TExibirErroSchema, TCamposFatObrigatorios, TWSalvar, TVisualizar, TAjustaAguardaConsultaRes,
                TDFeNSepararPorNome, TNCreateDefaultPath, TCustonPathAfter, TTEXTO,
                ACBrPosPrinter, ACBrNFeDANFeESCPOS,
                TConfSSLLib(TConfigACBRDFe.IfThen( not(zQueryEMPRESACERTIFICADO.IsNull), 1, 1)),              // A1 ou A3 por Arquivo ou N�mero de S�rie,
                TConfSSLCryptLib(TConfigACBRDFe.IfThen( not(zQueryEMPRESACERTIFICADO.IsNull), 3, 3)), //1     // A1 ou A3 por Arquivo ou N�mero de S�rie,
                TConfSSLHttpLib(TConfigACBRDFe.IfThen( not(zQueryEMPRESACERTIFICADO.IsNull), 2, 2)),  //3     // A1 ou A3 por Arquivo ou N�mero de S�rie,
                TConfSSLXmlSignLib(TConfigACBRDFe.IfThen( not(zQueryEMPRESACERTIFICADO.IsNull), 4, 4)),       // A1 ou A3 por Arquivo ou N�mero de S�rie,
                TConfSSLTipoCertificado(TConfigACBRDFe.IfThen( not(zQueryEMPRESACERTIFICADO.IsNull),  2, 1)), // A1 ou A3 por Arquivo ou N�mero de S�rie,
                TDgstSHA, TOutHexa, TSlMemory, TLT_all, '%TAGNIVEL% ID:%ID%/%TAG%(%DESCRICAO%) - %MSG%.',
                ''{ID do CSC NFCe},''{CSC NFCe},
                TConfigACBRDFe.IfThen( not(zQueryEMPRESACERTIFICADO.IsNull),  zQueryEMPRESACERTIFICADO.AsString, ''),   // Senha do certificado
                TConfigACBRDFe.IfThen( not(zQueryEMPRESASENHA.IsNull),  zQueryEMPRESASENHA.AsString, ''),               // Arquivo PFX do certificado
                TConfigACBRDFe.IfThen( not(ZQueryEMPRESANUMERO_SERIE.IsNull),  ZQueryEMPRESANUMERO_SERIE.AsString, ''), // N�mero de s�rie do certificado
                ZQueryEmpresaUF.AsString,
                1000,                                    // Aguardar consulta de retorno
                1,                                       // N�mero de tentativas
                1000,                                    // Intervalo entre tentativas
                '',                                      // Host do proxy
                '',                                      // Porta do proxy
                '',                                      // Usu�rio do proxy
                '',                                      // Senha do proxy
                TConfigACBRDFe.IfThen( not(ZQueryEmpresaCAMINHO_RESPONSE.IsNull),  ZQueryEmpresaCAMINHO_RESPONSE.AsString,
                GetPathDFe(TConfNFe, TPathResponse, TCreateDefaultPath, TCustonPathAfter, '', ZQueryEmpresaNOME.AsString + ' - ' + OnlyNumbers(ZQueryEmpresaCNPJ.AsString))),    // Caminho de salvamento de arquivos NFe
                '',                                      // Caminho de esquemas NFe
                '',                                      // Caminho de armazenamento de NFe
                '',                                      // Caminho de armazenamento de Inutiliza��o de NFe
                '',                                      // Caminho de armazenamento de eventos de NFe
                '',                                      // Caminho de salvamento de arquivos NFCe
                '',                                      // Caminho de esquemas NFCe
                '',                                      // Caminho de armazenamento de NFCe
                '',                                      // Caminho de armazenamento de Inutiliza��o de NFCe
                '',                                      // Caminho de armazenamento de eventos de NFCe
                TConfigACBRDFe.IfThen( not(ZQueryEmpresaCAMINHO.IsNull),  ZQueryEmpresaCAMINHO.AsString,
                GetPathDFe(TConfNFe, TPathXMLRecebidos, TCreateDefaultPath, TCustonPathAfter, '', ZQueryEmpresaNOME.AsString + ' - ' + OnlyNumbers(ZQueryEmpresaCNPJ.AsString))), // Caminho de armazenamento de Download DFe
                'COM1',                                  // Porta da impressora
                9600,                                    // Baud rate da impressora
                9600,                                    // Espa�o entre linhas da impressora
                1,                                       // Linhas entre cupons da impressora
                1,                                       // Largura da bobina na impressora
                0.5,                                     // Margem direita na impressora
                0.5,                                     // Margem esquerda na impressora
                0.5,                                     // Margem inferior na impressora
                0.5,                                     // Margem superior na impressora
                'WWSoftware''s Tecnologia - DFE Manifestador', // Nome do sistema
                '75 98333-4153'                          // Contato telef�nico
               );

  {$REGION ' Desabilitado '}
  {
  // Configura o componente ACBr
  ACBrNFe.Configuracoes.Geral.VersaoDF := ve400;

  // Configura��es para utiliza��o de comunica��o com webservice utilizando arquivo PFX
  if (zQueryEMPRESACERTIFICADO.AsString <> '') then
  begin

    // open ssl
    AcbrNfe.Configuracoes.Geral.SSLLib              := libOpenSSL;
    AcbrNfe.Configuracoes.Geral.SSLCryptLib         := cryOpenSSL;
    AcbrNfe.Configuracoes.Geral.SSLHttpLib          := httpOpenSSL;
    AcbrNfe.Configuracoes.Geral.SSLXmlSignLib       := xsLibXml2;
    //ACBrNFe.Configuracoes.Geral.SSLCryptLib       := cryWinCrypt;
    //ACBrNFe.Configuracoes.Geral.SSLHttpLib        := httpWinHttp;
    //ACBrNFe.Configuracoes.Geral.SSLXmlSignLib     := xsXmlSec;
    // Configura��o do certificado
    ACBrNFe.Configuracoes.Certificados.ArquivoPFX  := zQueryEMPRESACERTIFICADO.AsString;
    ACBrNFe.Configuracoes.Certificados.Senha       := zQueryEMPRESASENHA.AsString;
    ACBrNFe.Configuracoes.Certificados.NumeroSerie := '';

  end
  else
  // Configura��es para utiliza��o de comunica��o com webservice com a n�mero de s�rie
  if (ZQueryEMPRESANUMERO_SERIE.AsString <> '') then
  begin

    // Configura��es para utiliza��o de comunica��o com webservice com a wincrypt
    AcbrNfe.Configuracoes.Geral.SSLCryptLib := cryWinCrypt;
    AcbrNfe.Configuracoes.Geral.SSLHttpLib := httpWinHttp;
    AcbrNfe.Configuracoes.Geral.SSLXmlSignLib := xsLibXml2;

    //ACBrNFe.Configuracoes.Geral.SSLCryptLib := cryCapicom;
    //ACBrNFe.Configuracoes.Geral.SSLHttpLib := httpWinHttp;
    //ACBrNFe.Configuracoes.Geral.SSLXmlSignLib := xsMsXmlCapicom;
    // Configura��o do certificado
    ACBrNFe.Configuracoes.Certificados.NumeroSerie := ZQueryEMPRESANUMERO_SERIE.AsString;
    ACBrNFe.Configuracoes.Certificados.ArquivoPFX := '';
    ACBrNFe.Configuracoes.Certificados.Senha := '';

  end;
  // Ambiente do webservice: produ��o ou homologa��o
  ACBRNFe.Configuracoes.WebServices.Ambiente := taProducao;
  ACBrNFe.Configuracoes.Geral.FormaEmissao   := teNormal;
  ACBrNFe.Configuracoes.Arquivos.Salvar      := True;
  ACBrNFe.Configuracoes.Geral.Salvar         := True;

  // Se n�o est� configurado o caminho do xml ent�o salva na pasta "NotasFonnecedores" na pasta do App
  if (ZQueryEMPRESACAMINHO.AsString = '') then
  begin

    ACBrNFe.Configuracoes.Arquivos.PathSalvar := ExtractFilePath(Application.ExeName) +
                                                 'NotasFornecedores\' +
                                                 ZQueryEMPRESACNPJ.AsString +
                                                 '\Temp';
    ACBrNFe.Configuracoes.Arquivos.DownloadDFe.PathDownload := ExtractFilePath(Application.ExeName) +
                                                               'NotasFornecedores\' +
                                                               ZQueryEMPRESACNPJ.AsString;

  end
  else
  begin

    // Se usu�rio configurou caminho para o xml ent�o o utiliza
    ACBrNFe.Configuracoes.Arquivos.PathSalvar := ZQueryEMPRESACAMINHO.AsString + '' + ZQueryEMPRESACNPJ.AsString + '\Temp';
    ACBrNFe.Configuracoes.Arquivos.DownloadDFe.PathDownload := ZQueryEMPRESACAMINHO.AsString + '' + ZQueryEMPRESACNPJ.AsString;

  end;
  }
  {$ENDREGION}

end;

procedure TDMManifestador.ZQueryCFGAfterPost(DataSet: TDataSet);
begin
  GeneratorBuilder(TGenConfirm, DataSet, (DataSet as TUniQuery).Connection);
end;

procedure TDMManifestador.ZQueryCFGBeforeCancel(DataSet: TDataSet);
begin
  GeneratorBuilder(TGenCancel, DataSet, (DataSet as TUniQuery).Connection);
end;

procedure TDMManifestador.ZQueryCFGNewRecord(DataSet: TDataSet);
begin

  GeneratorBuilder(TGenInsert, DataSet, (DataSet as TUniQuery).Connection);

  ZQueryCFGVERIFICAR_AUTOMATICO.AsString := 'S';
  ZQueryCFGDOWNLOAD_AUTOMATICO.AsString := 'S';
  ZQueryCFGTIMER.AsInteger := 5;

end;

procedure TDMManifestador.ZQueryEmpresaAfterPost(DataSet: TDataSet);
begin
  GeneratorBuilder(TGenConfirm, DataSet, (DataSet as TUniQuery).Connection);
end;

procedure TDMManifestador.ZQueryEmpresaBeforeCancel(DataSet: TDataSet);
begin
  GeneratorBuilder(TGenCancel, DataSet, (DataSet as TUniQuery).Connection);
end;

procedure TDMManifestador.ZQueryEmpresaNewRecord(DataSet: TDataSet);
begin
  GeneratorBuilder(TGenInsert, DataSet, (DataSet as TUniQuery).Connection);
end;

procedure TDMManifestador.ZQueryExisteNotaAfterPost(DataSet: TDataSet);
begin
  GeneratorBuilder(TGenConfirm, DataSet, (DataSet as TUniQuery).Connection);
end;

procedure TDMManifestador.ZQueryExisteNotaBeforeCancel(DataSet: TDataSet);
begin
  GeneratorBuilder(TGenCancel, DataSet, (DataSet as TUniQuery).Connection);
end;

procedure TDMManifestador.ZQueryExisteNotaNewRecord(DataSet: TDataSet);
begin
  GeneratorBuilder(TGenInsert, DataSet, (DataSet as TUniQuery).Connection);
end;

procedure TDMManifestador.ZQueryNFAfterOpen(DataSet: TDataSet);
begin

  // Desabilita as Actions de manifesto, download e visualiza��o se n�o houver registros
  if (ZQueryNF.RecordCount = 0) then
  begin

    if (FActionManifestar <> nil) then
      FActionManifestar.Enabled := False;

    if (FActionDownload <> nil) then
      FActionDownload.Enabled := False;

    if (FActionVisualizar <> nil) then
      FActionVisualizar.Enabled := False;

  end;

end;

procedure TDMManifestador.ZQueryNFAfterPost(DataSet: TDataSet);
begin
  GeneratorBuilder(TGenConfirm, DataSet, (DataSet as TUniQuery).Connection);
end;

procedure TDMManifestador.ZQueryNFAfterScroll(DataSet: TDataSet);
begin

  // Habilita/desabilita a possibilidade de manifestar a nfe
  if (FActionManifestar <> nil) then
    FActionManifestar.Enabled := True;
  //  FActionManifestar.Enabled := (ZQueryNFMANIFESTACAO.AsString = 'N');


  // Habilita/desabilita a possibilidade de efetuar download nfe
  if (FActionDownload <> nil) then
    FActionDownload.Enabled := (ZQueryNFMANIFESTACAO.AsString = 'S') or (ZQueryNFDOWNLOAD.AsString = 'S');

  // Habilita/desabilita a possibilidade de visualizar a nfe
  if (FActionVisualizar <> nil) then
    FActionVisualizar.Enabled := True;

  ZQueryNF_LOG.Close;
  ZQueryNF_LOG.Open;

end;

procedure TDMManifestador.ZQueryNFBeforeCancel(DataSet: TDataSet);
begin
  GeneratorBuilder(TGenCancel, DataSet, (DataSet as TUniQuery).Connection);
end;

procedure TDMManifestador.ZQueryNFNewRecord(DataSet: TDataSet);
begin
  // Inicializa��o dos campos
  GeneratorBuilder(TGenInsert, DataSet, (DataSet as TUniQuery).Connection);

  zQueryNFMANIFESTACAO.AsString := 'N';
  zQueryNFDOWNLOAD.AsString := 'N';

  if (ACBRNFe.Configuracoes.WebServices.Ambiente = taProducao) then
    zQueryNFAMBIENTE.AsString := 'P'
  else
    zQueryNFAMBIENTE.AsString := 'H';

  zQueryNFDATAREC.AsDateTime := Date;
  ZQueryNFID_EMPRESA.AsInteger := ZQueryEMPRESACODIGO.AsInteger;

end;

procedure TDMManifestador.ZQueryNF_LOGAfterPost(DataSet: TDataSet);
begin
  GeneratorBuilder(TGenConfirm, DataSet, (DataSet as TUniQuery).Connection);
end;

procedure TDMManifestador.ZQueryNF_LOGBeforeCancel(DataSet: TDataSet);
begin
  GeneratorBuilder(TGenCancel, DataSet, (DataSet as TUniQuery).Connection);
end;

procedure TDMManifestador.ZQueryNF_LOGBeforeOpen(DataSet: TDataSet);
begin

  ZQueryNF_LOG.ParamByName('ID_NF').AsInteger := ZQueryNFCODIGO.AsInteger;

end;

procedure TDMManifestador.ZQueryNF_LOGNewRecord(DataSet: TDataSet);
begin
  GeneratorBuilder(TGenInsert, DataSet, (DataSet as TUniQuery).Connection);
end;

procedure TDMManifestador.ZQueryNSUAfterPost(DataSet: TDataSet);
begin
  GeneratorBuilder(TGenConfirm, DataSet, (DataSet as TUniQuery).Connection);
end;

procedure TDMManifestador.ZQueryNSUBeforeCancel(DataSet: TDataSet);
begin
  GeneratorBuilder(TGenCancel, DataSet, (DataSet as TUniQuery).Connection);
end;

procedure TDMManifestador.ZQueryNSUNewRecord(DataSet: TDataSet);
begin
  GeneratorBuilder(TGenInsert, DataSet, (DataSet as TUniQuery).Connection);
end;

procedure TDMManifestador.ListarNotas(Inicio, Fim: TDate; Baixadas, Manifestadas: Boolean);
begin

  // Lista as notas fiscais de acordo com o per�odo informado
  zQueryNF.Close;
  zQueryNF.ParamByName('ID_EMPRESA').AsInteger := ZQueryEMPRESACODIGO.AsInteger;
  zQueryNF.ParamByName('INICIO').AsDate := Inicio;
  zQueryNF.ParamByName('FIM').AsDate := Fim;

  if (Manifestadas) then
    zQueryNF.ParamByName('MANIFESTACAO').AsString := 'S'
  else
    zQueryNF.ParamByName('MANIFESTACAO').AsString := 'T';

  if (Baixadas) then
    zQueryNF.ParamByName('DOWNLOAD').AsString := 'S'
  else
    zQueryNF.ParamByName('DOWNLOAD').AsString := 'T';

  zQueryNF.Open;
  zQueryNF.Refresh;
end;

procedure TDMManifestador.Mensagem(Texto: string);
begin

  // Exibe o texto na ListboxMensagens do formul�rio de processamento
  frmProcessamento.ListBoxMensagens.Items.Add(FormatDateTime('dd/mm/yyyy hh:mm:ss', now) + ' - ' + Texto);
  frmProcessamento.ListBoxMensagens.ItemIndex := frmProcessamento.ListBoxMensagens.Items.Count - 1;
  Application.ProcessMessages;

end;

function TDMManifestador.ObterUltimoNSU(Ambiente: String): Integer;
begin

  // Retorna o �ltimo NSU conforme o ambiente "Produ��o" ou "Homologa��o"
  ZQueryNSU.Close;
  ZQueryNSU.ParamByName('AMBIENTE').AsString := Ambiente;
  ZQueryNSU.ParamByName('ID_EMPRESA').AsInteger := ZQueryEMPRESACODIGO.AsInteger;
  ZQueryNSU.Open;

  if (ZQueryNSU.FieldByName('NSU').AsString = '') then
    Result := 0
  else
    Result := ZQueryNSU.FieldByName('NSU').AsInteger;

end;

procedure TDMManifestador.ObterNotas(TIPO: string = '');
var
  IndNFe, IndEmi, ultNSU: string;
  i, Count, CountTotal: Integer;
  cStat: Integer;
  iConsultas: Integer;
  sAmbiente: String;
begin

  // Configura o componente acbr
  ConfigurarAcbr(ACBrNFe);

  // Inicializa contador de consultas ao webservice
  iConsultas := 0;
  CountTotal := 0;

  if (HoursBetween(now, ZQueryEmpresaDATA_MANIFESTACAO.AsDateTime) < 1) then
  begin
    if (TIPO.IsEmpty) or (TIPO = 'M') then
    ShowMessage('A verifica��o de novas notas poder� ser solicitada em ' +
                IntToStr(60 -  MinutesBetween(now, ZQueryEmpresaDATA_MANIFESTACAO.AsDateTime)) +
               ' minutos. Tente novamente mais tarde.');

    if (TIPO = 'A') then
    begin

      OcultarDialogoProcessamento;

      Mensagem(
                 'A verifica��o de novas notas poder� realizada em ' +
                  IntToStr(60 -  MinutesBetween(now, ZQueryEmpresaDATA_MANIFESTACAO.AsDateTime)) +
                 ' minutos.'
              );

      Mensagem('');

      Mensagem('O timer ser� ajustado autom�ticamente.');

      ExibirDialogoProcessamento;

      // Altera o cursor do mouse
      Screen.Cursor := crHourGlass;
      Application.ProcessMessages;

      OcultarDialogoProcessamento;

    end;

    Exit;

  end;

  // CStat 138 = resposta do webservice quando existem novas notas fiscais dispon�veis
  cStat := 138;
  zQueryNF.DisableControls;

  try

    // Oculta o di�logo para limpar os logs anteriores
    OcultarDialogoProcessamento;

    // Exibe o di�logo de processamento
    Mensagem('Consultando web service ...');
    ExibirDialogoProcessamento;

    // Altera o cursor do mouse
    Screen.Cursor := crHourGlass;
    Application.ProcessMessages;

    try

      // Efetua at� 20 consultas ao webservice enquanto o retorno do mesmo for 138
      while (cStat = 138) and (iConsultas < 20) do
      //while (cStat = 138) and (iConsultas < 1) do
      begin

        // Incrementa o n�mero de consultas efetuadas no webservice
        Inc(iConsultas);
        Mensagem('Consultando web service #' + IntToStr(iConsultas));

        // Verifica qual o ambiente do webservice  "Produ��o" ou "Homologa��o"
        if (ACBRNFe.Configuracoes.WebServices.Ambiente = taProducao) then
          sAmbiente := 'P'
        else
          sAmbiente := 'H';

        // Obt�m o n�mero do �ltimo NSU no banco de dados local
        ultNSU := IntToStr(ObterUltimoNSU(sAmbiente));

        {$REGION ' Desabilitado - Sefaz desativou o m�todo abaixo '}
        // Dispara a consulta ao webservice
        {
         Sefaz desativou o m�todo abaixo:
        ACBrNFe.DistribuicaoDFe(zQueryEMPRESAUF.AsInteger,
                                zQueryEMPRESACNPJ.AsString, //05778762000137
                                UltNSu,
                                '');
        }
        {$ENDREGION}

        ACBrNFe.DistribuicaoDFePorUltNSU(zQueryEMPRESAUF.AsInteger,
                                         zQueryEMPRESACNPJ.AsString, //05778762000137
                                         UltNSu);

        // Inicializa o contador de notas fiscais dispon�vels
        Count := 0;

        // Captura o cStat retornado pelo webservice
        cStat := ACBrNFe.WebServices.DistribuicaoDFe.retDistDFeInt.cStat;

        // 138 = Novas notas fiscais dispon�veis
        if (cStat = 138) then
        begin

          // Percorre a lista de NFe
          for i := 0 to ACBrNFe.WebServices.DistribuicaoDFe.retDistDFeInt.docZip.Count - 1 do
          begin

            // Armazena o NSU
            if (Trim(ACBrNFe.WebServices.DistribuicaoDFe.retDistDFeInt.docZip.Items[i].NSU) <> '') then
              ultNSU := ACBrNFe.WebServices.DistribuicaoDFe.retDistDFeInt.docZip.Items[i].NSU;

            //Mensagem('Chave NFE:' + zQueryNFCHAVE.AsString);
            Mensagem('Chave NFE: ' + ACBrNFe.WebServices.DistribuicaoDFe.retDistDFeInt.docZip.Items[i].resDFe.chDFe);

            // Verifica se tem NSU e Chave da NFe
            if (ACBrNFe.WebServices.DistribuicaoDFe.retDistDFeInt.docZip.Items[i].NSU <> '') and
               (ACBrNFe.WebServices.DistribuicaoDFe.retDistDFeInt.docZip.Items[i].resDFe.chDFe <> '') then
            begin

              // Incrementa contador de notas
              Inc(Count);

              // Inclui os dados de resumo da NFe no banco de dados
              zQueryNF.Append;
              ZQueryNFID_EMPRESA.AsInteger := ZQueryEmpresaCODIGO.AsInteger;
              zQueryNFNSU.AsString         := ACBrNFe.WebServices.DistribuicaoDFe.retDistDFeInt.docZip.Items[i].NSU;
              zQueryNFChave.AsString       := ACBrNFe.WebServices.DistribuicaoDFe.retDistDFeInt.docZip.Items[i].resDFe.chDFe;
              zQueryNFSerie.AsString       := Copy(zQueryNFChave.AsString, 23, 3);
              zQueryNFNumero.AsString      := Copy(zQueryNFChave.AsString, 26, 9);
              zQueryNFCNPJ.AsString        := ACBrNFe.WebServices.DistribuicaoDFe.retDistDFeInt.docZip.Items[i].resDFe.CNPJCPF;
              zQueryNFNome.AsString        := ACBrNFe.WebServices.DistribuicaoDFe.retDistDFeInt.docZip.Items[i].resDFe.xNome;
              zQueryNFIE.AsString          := ACBrNFe.WebServices.DistribuicaoDFe.retDistDFeInt.docZip.Items[i].resDFe.IE;
              zQueryNFEmissao.AsDateTime   := ACBrNFe.WebServices.DistribuicaoDFe.retDistDFeInt.docZip.Items[i].resDFe.dhEmi;
              zQueryNFValor.AsCurrency     := ACBrNFe.WebServices.DistribuicaoDFe.retDistDFeInt.docZip.Items[i].resDFe.vNF;
              zQueryNFDataRec.AsDateTime   := ACBrNFe.WebServices.DistribuicaoDFe.retDistDFeInt.docZip.Items[i].resDFe.dhRecbto;
              zQueryNFProtocolo.AsString   := ACBrNFe.WebServices.DistribuicaoDFe.retDistDFeInt.docZip.Items[i].resDFe.nProt;
              //ZQueryNFXML.AsString         := ACBrNFe.WebServices.DistribuicaoDFe.retDistDFeInt.docZip.Items[i].XML;
              //ZQueryNFXML_PATH.AsString    := ACBrNFe.WebServices.DistribuicaoDFe.retDistDFeInt.docZip.Items[i].NomeArq;

              // Verifica se � uma NFe de Entrada ou Sa�da
              case ACBrNFe.WebServices.DistribuicaoDFe.retDistDFeInt.docZip.Items[i].resDFe.tpNF of

                tnEntrada: zQueryNFTipo.AsString := 'Entrada';
                tnSaida:   zQueryNFTipo.AsString := 'Sa�da';

              end;

              // Verifica qual � a situa��o da NFe
              case ACBrNFe.WebServices.DistribuicaoDFe.retDistDFeInt.docZip.Items[i].resDFe.cSitDFe of

                snAutorizado: zQueryNFSituacao.AsString  := 'Autorizado';
                snDenegado:   zQueryNFSituacao.AsString  := 'Denegado';
                snCancelado:  zQueryNFSituacao.AsString  := 'Cancelado';
                snEncerrado:   zQueryNFSituacao.AsString := 'Encerrado';

              end;

              if ExisteNota(ZQueryNFCHAVE.AsString) then
                ZQueryNFVISIVEL.AsString := 'N'
              else
                ZQueryNFVISIVEL.AsString := 'S';

              zQueryNF.Post;
              Mensagem('Retornando resumo da nota fiscal ' + zQueryNFCHAVE.AsString);
              Application.ProcessMessages;


            end
            else
            begin

              // Alguns registros retornados pelo webservice de distribui��o de NFe
              // n�o cont�m dados de resumos das notas fiscias ent�o aqui estou
              // gravando esses casos apenas para controle do NSU
              zQueryNF.Append;
              zQueryNFNSU.AsString         := ACBrNFe.WebServices.DistribuicaoDFe.retDistDFeInt.docZip.Items[i].NSU;
              zQueryNFChave.AsString       := 'Chave de acesso';
              zQueryNFSerie.AsString       := '0';
              zQueryNFNumero.AsString      := '0';
              zQueryNFCNPJ.AsString        := 'CNPJ';
              zQueryNFNome.AsString        := 'Nome';
              zQueryNFIE.AsString          := 'IE';
              zQueryNFEmissao.AsDateTime   := 0;
              zQueryNFValor.AsCurrency     := 0;
              zQueryNFDataRec.AsDateTime   := 0;
              zQueryNFProtocolo.AsString   := '0';

              case ACBrNFe.WebServices.DistribuicaoDFe.retDistDFeInt.docZip.Items[i].resDFe.tpNF of

                tnEntrada: zQueryNFTipo.AsString := 'Entrada';
                tnSaida:   zQueryNFTipo.AsString := 'Sa�da';
              else

                zQueryNFTipo.AsString := 'tpNF';

              end;

              case ACBrNFe.WebServices.DistribuicaoDFe.retDistDFeInt.docZip.Items[i].resDFe.cSitDFe of

                snAutorizado: zQueryNFSituacao.AsString  := 'Autorizado';
                snDenegado:   zQueryNFSituacao.AsString  := 'Denegado';
                snCancelado:  zQueryNFSituacao.AsString  := 'Cancelado';
                snEncerrado:   zQueryNFSituacao.AsString := 'Encerrado';

              else

                zQueryNFSituacao.AsString := 'cSitNFe';

              end;

              ZQueryNFVISIVEL.AsString := 'N';
              zQueryNF.Post;
              Application.ProcessMessages;

            end;


          end;

          zQueryNF.First;
          Mensagem('Foram encontradas ' + IntToStr(Count) + ' novas nota(s) fiscal(s).');
          CountTotal := CountTotal + Count;

        end
        else
        begin

          // Nenhum Documento Localizado para o Destinat�rio
          if (ACBrNFe.WebServices.DistribuicaoDFe.retDistDFeInt.cStat = 137) then
            Mensagem('Nenhum documento foi localizado.')
          else
            Mensagem(' N�o foi poss�vel realizar a consulta. cStat:' + IntToStr(ACBrNFe.WebServices.DistribuicaoDFe.retDistDFeInt.cStat)  +
                     ' - Motivo: ' + ACBrNFe.WebServices.DistribuicaoDFe.retDistDFeInt.xMotivo);

        end;

      end;

      Mensagem('Fim do processamento: no total foram encontradas ' + IntToStr(CountTotal) + ' novas nota(s) fiscal(s).');

      // Atualiza data/hora da �ltima verifica��o
      ZQueryEmpresa.Edit;
      ZQueryEmpresaDATA_MANIFESTACAO.AsDateTime := Now;
      ZQueryEmpresa.Post;

      // Atualiza os dados
      zQueryNF.Refresh;

    except

      on E:Exception do
      begin

        Mensagem(E.Message);

      end;

    end;

  finally

    Screen.Cursor := crDefault;
    zQueryNF.EnableControls;

  end;

end;

procedure TDMManifestador.Manifestar(CodigoNotaFiscal, TipoManifestacao: Integer; ChaveNF: String; Refresh: Boolean; Motivo: String = '');
var
  i, IdLote: Integer;
begin
               {$REGION ' Desabilitado '}
            {$ENDREGION}
  // Configura o componente acbr
  ConfigurarAcbr(ACBrNFe);

  GerarLogNF(CodigoNotaFiscal, 1);
  // Oculta o di�logo para limpar os logs anteriores
  OcultarDialogoProcessamento;
  // Inicializa��o do n�mero do lote
  IdLote := 0;
  Mensagem('Enviando evento para o web service da receita ...');
  ExibirDialogoProcessamento;
  //zQueryNF.DisableControls;
  ACBrNFe.EventoNFe.Evento.Clear;
  Application.ProcessMessages;

  try

    Mensagem('Adicinado ao lote a NF ' + ChaveNF);

    // Gera o n�mero de lote
    if (ACBrNFe.EventoNFe.idLote = 0) then
    begin

      IdLote := CodigoNotaFiscal;
      ACBrNFe.EventoNFe.idLote := IdLote;

    end;

    // Cria o evendo de manifesta��o
    with ACBrNFe.EventoNFe.Evento.Add do
    begin

      // Chave da NFe
      infEvento.chNFe    := ChaveNF;
      // CNPJ da empressa destinada
      infEvento.CNPJ     := zQueryEMPRESACNPJ.AsString;
      // data e hora
      infEvento.dhEvento := now;
      // �rgao 91 fixo
      infEvento.cOrgao   := 91;

      case TipoManifestacao of

        //Confirma��o de opera��o
        0: infEvento.tpEvento:= teManifDestConfirmacao;
        //Ci�ncia da opera��o
        1: infEvento.tpEvento := teManifDestCiencia;
        //Opera��o n�o realizada
        2: infEvento.tpEvento := teManifDestOperNaoRealizada;
        //Desconhecimento da opera��o
        3: infEvento.tpEvento := teManifDestDesconhecimento;

      end;

      if (Motivo <> '') then
        infEvento.detEvento.xJust := Motivo;

    end;

    Mensagem('Enviando lote para web service da receita ...');
    Application.ProcessMessages;
    // Envia o lote de manifesto para o webservice
    ACBrNFe.EnviarEvento(IdLote);
    Mensagem('Processando o retorno do webservice...');

    // Captura os retornos do webservice
    for i := 0 to ACBrNFe.WebServices.EnvEvento.EventoRetorno.retEvento.Count - 1 do
    begin

      // Seta o ponteiro da query zQueryNF apontando para a nota retornada pelo webservice
      // (zQueryNF.Locate('CHAVE', ACBrNFe.WebServices.EnvEvento.EventoRetorno.retEvento.Items[i].RetInfEvento.chNFe, [])) then
      //gin

        // Exbibe no log para o usu�rio o cStat e o xMotivo do webservice
        Mensagem('NF: ' + zQueryNFCHAVE.AsString +
                ' - CSTAT: ' +  IntToStr(ACBrNFe.WebServices.EnvEvento.EventoRetorno.retEvento.Items[i].RetInfEvento.cStat) +
                ' - ' + ACBrNFe.WebServices.EnvEvento.EventoRetorno.retEvento.Items[i].RetInfEvento.xMotivo);

        // Atualiza no banco de dados local caso a nota tenha sido manifestada com sucesso
        if (ACBrNFe.WebServices.EnvEvento.EventoRetorno.retEvento.Items[i].RetInfEvento.cStat = 135) or    // Evento vinculado
           (ACBrNFe.WebServices.EnvEvento.EventoRetorno.retEvento.Items[i].RetInfEvento.cStat = 655) or    // Manifesta��o ap�s final da opera��o
           (ACBrNFe.WebServices.EnvEvento.EventoRetorno.retEvento.Items[i].RetInfEvento.cStat = 573) then  // Duplicidade de evento (j� manifestada)
        begin

          UpdateManifestar(CodigoNotaFiscal);
          GerarLogNF(CodigoNotaFiscal, 3);

        end;

      //d;

    end;

    // Atualiza dados da query
    if (Refresh) then
      zQueryNF.Refresh;

  except

    on E:Exception do
    begin

      GerarLogNF(CodigoNotaFiscal, 5, E.Message);
      Mensagem('Erro: ' + E.Message);

    end;

  end;

end;

procedure TDMManifestador.Download(CodigoNotaFiscal: Integer; ChaveNF: String; Refresh: Boolean; NSU: string);
var
  i: Integer;
  ArqXML: TStringStream;
  PathTemp, PathSave: string;
begin

  // Configura o componente acbr
  ConfigurarAcbr(ACBrNFe);

  try

    // Oculta o di�logo para limpar os logs anteriores
    OcultarDialogoProcessamento;
    Screen.Cursor := crHourGlass;
    Mensagem('Efetuando conex�o no webservice da receita ...');
    ExibirDialogoProcessamento;

    try

      GerarLogNF(CodigoNotaFiscal, 2);
      Mensagem('Efetuando download da NFe Chave: ' + ChaveNF);
      // Efetua o download pelo webservice
      AcbrNFe.DistribuicaoDFePorChaveNFe(zQueryEMPRESAUF.AsInteger, zQueryEMPRESACNPJ.AsString, ChaveNF);
      //AcbrNFe.DistribuicaoDFePorNSU(zQueryEMPRESAUF.AsInteger, zQueryEMPRESACNPJ.AsString, ZQueryNFNSU.AsString);
      //AcbrNFe.DistribuicaoDFePorUltNSU(zQueryEMPRESAUF.AsInteger, zQueryEMPRESACNPJ.AsString, ZQueryNFNSU.AsString);
      AcbrNFe.WebServices.DistribuicaoDFe.Executar;

      with AcbrNFe.WebServices.DistribuicaoDFe.retDistDFeInt do
      begin

        // Download efetuado
        if (cStat = 138) then
        begin

          for i := 0 to docZip.Count - 1 do
          begin

            // Verifica se o arquivo � o xml da NFE (-nfe.xml)
            if docZip.Items[i].schema = schprocNFe then
            begin

              // Extrai o arquivo xml
              ArqXML := TStringStream.Create(docZip.Items[i].XML);
              XMLDocument1.LoadFromStream(ArqXML);

              PathTemp :=
              GetPathDFe(
                          TConfNFe,TPathTemp,TCreateDefaultPath,TCustonPathAfter,FormatDateTimeToString(ZQueryNFEMISSAO.AsDateTime, 'YYYYMM'),
                          ZQueryEmpresaNOME.AsString + ' - ' + OnlyNumbers(ZQueryEmpresaCNPJ.AsString)
                        );

              PathSave :=
              GetPathDFe(
                          TConfNFe,TPathBackup,TCreateDefaultPath,TCustonPathAfter,FormatDateTimeToString(ZQueryNFEMISSAO.AsDateTime, 'YYYYMM'),
                          ZQueryEmpresaNOME.AsString + ' - ' + OnlyNumbers(ZQueryEmpresaCNPJ.AsString)
                        );

              {$REGION ' Desabilitado '}
              //PathTemp := PathTemp + OnlyNumbers(ZQueryNFCNPJ.AsString) + '\' +
              //            FormatDateTimeToString(ZQueryNFEMISSAO.AsDateTime, 'YYYYMM') + '\';

              // Salva o xml no disco
              {
              XMLDocument1.SaveToFile(ACBrNFe.Configuracoes.Arquivos.DownloadDFe.PathDownload + 'Temp' + '\' +
                                      OnlyNumbers(ZQueryNFCNPJ.AsString) + '\' +
                                      FormatDateTimeToString(ZQueryNFEMISSAO.AsDateTime, 'YYYYMM') + '\' +
                                      ChaveNF);
              }
              {$ENDREGION}

              XMLDocument1.SaveToFile(PathTemp + ChaveNF);
              //
              // Backup do xml
              if (ZQueryEMPRESACAMINHO_COPIA_XML.AsString <> '') then
              begin

                {$REGION ' Desabilitado '}
                {

                Mensagem('Copiando ' + ZQueryEMPRESACAMINHO_COPIA_XML.AsString +
                          OnlyNumbers(ZQueryNFCNPJ.AsString) + '\' +
                          FormatDateTimeToString(ZQueryNFEMISSAO.AsDateTime, 'YYYYMM') + '\' +
                          ChaveNF + '-nfe.xml'
                        );

                XMLDocument1.SaveToFile(ZQueryEMPRESACAMINHO_COPIA_XML.AsString +
                                        OnlyNumbers(ZQueryNFCNPJ.AsString) + '\' +
                                        FormatDateTimeToString(ZQueryNFEMISSAO.AsDateTime, 'YYYYMM') + '\' +
                                        ChaveNF + '-nfe.xml'
                                       );

                }
                {$ENDREGION}

                Mensagem('Copiando ' + PathSave + ChaveNF + '-nfe.xml');
                XMLDocument1.SaveToFile(PathSave + ChaveNF + '-nfe.xml');


              end;

              ArqXML.Free;

              // Download disponibilizado
              if (cStat = 138) then
              begin

                // Atualiza o banco de dados local informando que foi efetuado download
                UpdateDownload(CodigoNotaFiscal, PathSave + ChaveNF + '-nfe.xml');
                GerarLogNF(CodigoNotaFiscal, 4);
                Mensagem('Download efetuado -> NF ' + ChaveNF  + ' CSTAT: ' + IntToStr(cStat) + ' - ' + xMotivo);

                // Atualiza dados da query
                if (Refresh) then
                  zQueryNF.Refresh;

              end
              else
              begin

                Mensagem('Download n�o efetuado efetuado -> NF ' + ChaveNF  + ' CSTAT: ' + IntToStr(cStat) + ' - ' + xMotivo);
                GerarLogNF(CodigoNotaFiscal, 6, ' CSTAT: ' + IntToStr(cStat) + ' - ' + xMotivo);

              end;

            end;

          end;

        end
        else
        begin

          Mensagem('Download n�o efetuado efetuado -> NF ' + ChaveNF  + ' CSTAT: ' + IntToStr(AcbrNFe.WebServices.DistribuicaoDFe.retDistDFeInt.cStat) + ' - ' + AcbrNFe.WebServices.DistribuicaoDFe.retDistDFeInt.xMotivo);
          GerarLogNF(CodigoNotaFiscal, 6, ' CSTAT: ' + IntToStr(cStat) + ' - ' + xMotivo);

        end;

      end;

    except

      on E:Exception do
      begin

        GerarLogNF(CodigoNotaFiscal, 6, E.Message);
        Mensagem('N�o foi poss�vel efetuar o download do XML desta nota fiscal, motivo ->  ' + E.Message);

      end;

    end;

  finally

    Screen.Cursor := crDefault;

  end;

end;

procedure TDMManifestador.Visualizar(GerarPDF: Boolean);
var
  xml: string;
begin

  ConfigurarAcbr(ACBrNFeImprimir);

  ACBrNFeImprimir.DANFE.Cancelada := false;

  if ZQueryNFSITUACAO.AsString = 'Cancelado' then
    ACBrNFeImprimir.DANFE.Cancelada := true;

  try

    if (ZQueryNF.RecordCount = 0) then
      Exit;

    if (ZQueryNF.State = dsEdit) then
      ZQueryNF.Post;

    // Limpa a cole��o de notas fiscais
    ACBrNFeImprimir.NotasFiscais.Clear;

    // Seta o caminho do xml
    //xml := ExtractFilePath(Application.ExeName) + 'NotasFornecedores\' + ZQueryNFCHAVE.AsString + '-nfe.xml';
    //xml := ZQueryEMPRESACAMINHO.AsString + '' + ZQueryEMPRESACNPJ.AsString + '\' + ZQueryNFCHAVE.AsString + '-nfe.xml';

    XML :=
    TConfigACBRDFe.IfThen(not(ZQueryNFXML_PATH.AsString = EmptyStr), ZQueryNFXML_PATH.AsString, '');

    if XML.IsEmpty then
    XML :=
    TConfigACBRDFe.IfThen(
                          not(ZQueryEmpresaCAMINHO.IsNull),
                          ZQueryEmpresaCAMINHO.AsString + FormatDateTimeToString(ZQueryNFEMISSAO.AsDateTime, 'YYYYMM') + '\' + ZQueryNFCHAVE.AsString + '-nfe.xml',
                          GetPathDFe(
                                      TConfNFe, TPathXMLRecebidos, TCreateDefaultPath, TCustonPathAfter,
                                      FormatDateTimeToString(ZQueryNFEMISSAO.AsDateTime, 'YYYYMM'),
                                      ZQueryEmpresaNOME.AsString + ' - ' + OnlyNumbers(ZQueryEmpresaCNPJ.AsString)) + ZQueryNFCHAVE.AsString + '-nfe.xml'
                         );

    if not(ZQueryNFXML.IsNull) or
       not(ZQueryNFXML.AsString = EmptyStr)
    then
    begin
      ACBrNFeImprimir.NotasFiscais.LoadFromString(ZQueryNFXML.AsString);
    end else
    if not FileExists(xml) then
    begin
      // Verifica se o xml existe no disco e carrega para o componente acbr
      if (ZQueryNFMANIFESTACAO.AsString = 'S') then
        raise Exception.Create('Arquivo ' + xml + ' n�o encontrado.')
      else
        raise Exception.Create('Arquivo ' + xml + ' n�o encontrado. Efetue a manifesta��o da NFe e efetue o download!');

    end
    else
      ACBrNFeImprimir.NotasFiscais.LoadFromFile(xml);

    // Exibe a visualiza��o do Danfe
    if (GerarPDF) then
    begin

      SaveDialogPDF.FileName := ZQueryNFCHAVE.AsString + '-nfe.pdf';

      if (SaveDialogPDF.Execute) then
      begin

        ACBrNFeImprimir.DANFE.PathPDF := ExtractFilePath(SaveDialogPDF.FileName);
        ACBrNFeImprimir.NotasFiscais.ImprimirPDF;

      end;

    end
    else
      ACBrNFeImprimir.NotasFiscais.Imprimir;

  except

    on E:Exception do
    begin

      raise Exception.Create(E.Message)

    end;

  end;

end;

function TDMManifestador.ExisteNota(Chave: String): Boolean;
begin

  // Verifica se j� existe a nota fiscal na base de dados pela chave de acesso
  with ZQueryExisteNota do
  begin

    Close;
    ParamByName('CHAVE').AsString := Chave;
    Open;

  end;

  Result := ZQueryExisteNota.FieldByName('TOTAL').AsInteger > 0;

end;

procedure TDMManifestador.FDConnection1BeforeConnect(Sender: TObject);
begin

  // Seta o caminho da conex�o com o banco de dados que deve estar na mesma pasta do App
  {
  if (FileExists(ExtractFilePath(Application.ExeName) + 'manifestador.db')) then
    FDConnection1.Params[0] := 'Database=' + ExtractFilePath(Application.ExeName) + 'manifestador.db'
  else
    raise Exception.Create('N�o foi encontrado o arquivo: ' + ExtractFilePath(Application.ExeName) + 'manifestador.db');
  }
  bdUtils := TBDUtilsFactory.BuildBDUtils(bdutDBExpress);
  bdUtils.Conexao := Self.FDConnection1;

end;

procedure TDMManifestador.FDConnection1AfterConnect(Sender: TObject);
begin
  //MainLoaderSystem;
end;

procedure TDMManifestador.FDConnection1AfterDisconnect(Sender: TObject);
begin

  if Assigned(bdUtils) then
    FreeAndNil(bdUtils);

end;


procedure TDMManifestador.GerarZip(ZipFileName: String; FilesToZip: TStringList);
var
  ZipFile: TZipFile;
  i: Integer;
begin

  ZipFile := TZipFile.Create;

  try

    try

      ZipFile.Open(ZipFileName, zmWrite);

      for i := 0 to FilesToZip.Count - 1 do
      begin

        if (FileExists(FilesToZip[i])) then
          ZipFile.Add(FilesToZip[i]);

      end;

      ZipFile.Close;


    except

      on E:Exception do
      begin

        raise Exception.Create(' N�o foi poss�vel gerar o arquivo ' + ZipFileName + ' -> ' + E.Message);

      end;

    end;

  finally

    ZipFile.Free;

  end;

end;

function TDMManifestador.Importar(CodigoNotaFiscal: Integer; ArquivoXML: String): Boolean;
begin

  try

    // Importa dados do xml
    DMXMLNFE.NomeArquivoXML := ArquivoXML;
    Result := DMXMLNFE.Importar(CodigoNotaFiscal);

  except

    on E:Exception do
    begin

      raise Exception.Create(' N�o foi poss�vel gerar importar a nota fiscal -> ' + E.Message);

    end;

  end;

end;

procedure TDMManifestador.TimerVerificarTimer(Sender: TObject);
var
  CodEmpresa: Integer;
begin

  with ZQueryEMPRESA do
  begin

    // Verifica se pode disparar a verifica��o autom�tica das notas
    if (State in [dsInsert, dsEdit]) then
      Exit;

    // Verifica em qual empresa est� posicionado
    CodEmpresa := ZQueryEMPRESACODIGO.AsInteger;
    First;

    // Percorre todas as empresas
    while not Eof do
    begin

      // Obtem novas notas
      if (HoursBetween(now, ZQueryEmpresaDATA_MANIFESTACAO.AsDateTime) < 1) then
      begin

        ObterNotas('A');

      end else
      begin

        OcultarDialogoProcessamento;

        Mensagem(
                   'A verifica��o de novas notas ser� realizada em ' +
                    IntToStr(60 -  MinutesBetween(now, ZQueryEmpresaDATA_MANIFESTACAO.AsDateTime)) +
                   ' minutos.'
                );

        Mensagem('Para a Enpresa: ' + ZQueryEmpresaNOME.AsString);

        Mensagem('O timer ser� ajustado autom�ticamente.');

        ExibirDialogoProcessamento;

        // Altera o cursor do mouse
        Screen.Cursor := crHourGlass;
        Application.ProcessMessages;

        OcultarDialogoProcessamento;

      end;

      Next;

    end;

    if (ZQueryCFGDOWNLOAD_AUTOMATICO.AsString = 'S') then
    begin

      First;
      // Percorre todas as empresas
      while not Eof do
      begin

        // Manfesta��o autom�tica
         ManifestacaoAutomatica;
        Next;

      end;

      First;

      // Percorre todas as empresas
      while not Eof do
      begin

        // Download Automatico
        DownloadAutomatico;
        Next;

      end;

    end;

    // Reposiciona na empresa selecionada
    ZQueryEMPRESA.Locate('CODIGO', CodEmpresa, []);

  end;

end;

procedure TDMManifestador.MainLoaderSystem;
begin

  // Instancia na mem�ria o formul�rio de exibi��o do processamento
  if not(Assigned(frmProcessamento)) then
  frmProcessamento := TfrmProcessamento.Create(Application);
  // Abre a query de configura��es gerais
  ZQueryCFG.Open;
  // Carrega as configura��es do timer
  ConfigurarTimer;
  // Abre a query EMPRESA
  zQueryEMPRESA.Open;
  // Configura o componente Acbr
  ConfigurarAcbr(ACBrNFe);

  //ListarNotas(Date - 90, Date, False, False);


end;

procedure TDMManifestador.ManifestacaoAutomatica;
var
  zQuery: TUniQuery;
begin

  zQuery := TUniQuery.Create(Self);

  try

    try

      zQuery.Connection := FDConnection1;
      zQuery.SQL.Add('SELECT FIRST 1 NF.CODIGO,                    ');
      zQuery.SQL.Add('       NF.CHAVE                              ');
      zQuery.SQL.Add('  FROM NF                                    ');
      zQuery.SQL.Add(' WHERE NF.ID_EMPRESA   = :ID_EMPRESA         ');
      zQuery.SQL.Add('   AND NF.MANIFESTACAO = ''N''               ');
      zQuery.SQL.Add('   AND NF.VISIVEL      = ''S''               ');
      zQuery.SQL.Add('   AND NOT EXISTS (SELECT 1                  ');
      zQuery.SQL.Add('          FROM NF_LOG                        ');
      zQuery.SQL.Add('         WHERE NF_LOG.ID_NF = NF.CODIGO)     ');
      zQuery.SQL.Add(' ORDER BY NF.EMISSAO                         ');
      zQuery.ParamByName('ID_EMPRESA').AsInteger := ZQueryEMPRESACODIGO.AsInteger;
      zQuery.Open;

      {$REGION ' DESABILITADO '}
      {
      zQuery.Connection := FDConnection1;
      zQuery.SQL.Add('SELECT NF.CODIGO,                            ');
      zQuery.SQL.Add('       NF.CHAVE                              ');
      zQuery.SQL.Add('  FROM NF                                    ');
      zQuery.SQL.Add(' WHERE NF.ID_EMPRESA   = :ID_EMPRESA         ');
      zQuery.SQL.Add('   AND NF.MANIFESTACAO = ''N''               ');
      zQuery.SQL.Add('   AND NF.VISIVEL      = ''S''               ');
      zQuery.SQL.Add('   AND (SELECT COUNT (*)                     ');
      zQuery.SQL.Add('          FROM NF_LOG                        ');
      zQuery.SQL.Add('         WHERE NF_LOG.ID_NF = NF.CODIGO) = 0 ');
      zQuery.SQL.Add(' ORDER BY NF.EMISSAO                         ');
      zQuery.SQL.Add(' LIMIT 1                                     ');
      zQuery.ParamByName('ID_EMPRESA').AsInteger := ZQueryEMPRESACODIGO.AsInteger;
      zQuery.Open;
      }
      {$ENDREGION}

      if (not zQuery.Eof) then
        Manifestar(zQuery.FieldByName('CODIGO').AsInteger , 1, zQuery.FieldByName('CHAVE').AsString, True);

    except

      on E:Exception do
      begin

        raise Exception.Create('TDMManifestador.UpdateManifestar -> ' + E.Message);

      end;

    end;

  finally

    zQuery.Free;

  end;

end;

procedure TDMManifestador.DownloadAutomatico;
var
  zQuery: TUniQuery;
begin

  zQuery := TUniQuery.Create(Self);

  try

    try

      zQuery.Connection := FDConnection1;
      zQuery.SQL.Add('SELECT FIRST 1 CODIGO,           ');
      zQuery.SQL.Add('       CHAVE,                    ');
      zQuery.SQL.Add('       NSU                       ');
      zQuery.SQL.Add('  FROM NF                        ');
      zQuery.SQL.Add(' WHERE ID_EMPRESA = :ID_EMPRESA  ');
      zQuery.SQL.Add('   AND DOWNLOAD   = ''N''        ');
      zQuery.SQL.Add('   AND VISIVEL    = ''S''        ');
      zQuery.SQL.Add(' ORDER BY EMISSAO                ');
      zQuery.ParamByName('ID_EMPRESA').AsInteger := ZQueryEMPRESACODIGO.AsInteger;
      zQuery.Open;

      {$REGION ' Desabilitado '}
      {
      zQuery.Connection := FDConnection1;
      zQuery.SQL.Add('SELECT CODIGO,                   ');
      zQuery.SQL.Add('       CHAVE,                    ');
      zQuery.SQL.Add('       NSU                       ');
      zQuery.SQL.Add('  FROM NF                        ');
      zQuery.SQL.Add(' WHERE ID_EMPRESA = :ID_EMPRESA  ');
      zQuery.SQL.Add('   AND DOWNLOAD   = ''N''        ');
      zQuery.SQL.Add('   AND VISIVEL    = ''S''        ');
      zQuery.SQL.Add(' ORDER BY EMISSAO                ');
      zQuery.SQL.Add(' LIMIT 1                         ');
      zQuery.ParamByName('ID_EMPRESA').AsInteger := ZQueryEMPRESACODIGO.AsInteger;
      zQuery.Open;
      }
      {$ENDREGION}

      if (not zQuery.Eof) then
        Download(zQuery.FieldByName('CODIGO').AsInteger, zQuery.FieldByName('CHAVE').AsString, True, zQuery.FieldByName('NSU').AsString);

    except

      on E:Exception do
      begin

        raise Exception.Create('TDMManifestador.UpdateManifestar -> ' + E.Message);

      end;

    end;

  finally

    zQuery.Free;

  end;

end;


procedure TDMManifestador.UpdateManifestar(CodigoNotaFiscal: Integer);
var
  zQuery: TUniQuery;
begin

  zQuery := TUniQuery.Create(Self);

  try

    try

      zQuery.Connection := FDConnection1;
      zQuery.SQL.Add('UPDATE NF                   ');
      zQuery.SQL.Add('   SET MANIFESTACAO = ''S'' ');
      zQuery.SQL.Add(' WHERE CODIGO = :CODIGO     ');
      zQuery.ParamByName('CODIGO').AsInteger := CodigoNotaFiscal;
      zQuery.ExecSQL;

    except

      on E:Exception do
      begin

        raise Exception.Create('TDMManifestador.UpdateManifestar -> ' + E.Message);

      end;

    end;

  finally

    zQuery.Free;

  end;

end;

procedure TDMManifestador.UpdateDownload(CodigoNotaFiscal: Integer; const XMLFileName: string);
var
  Stream: TMemoryStream;
  zQuery: TUniQuery;
begin
  zQuery := TUniQuery.Create(nil);
  Stream := TMemoryStream.Create;
  try
    try
      zQuery.Connection := FDConnection1;
      zQuery.SQL.Text := 'UPDATE NF ' +
                         'SET DOWNLOAD = ''S'', ' +
                         '    XML = :XMLContent, ' +
                         '    XML_PATH = :XMLPath ' +
                         'WHERE CODIGO = :CODIGO';
      // Carregar o arquivo XML para um stream de mem�ria
      Stream.LoadFromFile(XMLFileName);
      // Atribuir o stream ao par�metro BLOB
      zQuery.ParamByName('XMLContent').LoadFromStream(Stream, ftBlob);
      // Atribuir o caminho do arquivo XML ao par�metro XML_PATH
      zQuery.ParamByName('XMLPath').AsString := XMLFileName;
      zQuery.ParamByName('CODIGO').AsInteger := CodigoNotaFiscal;
      zQuery.ExecSQL;
    except

      on E: Exception do
        raise Exception.Create('TDMManifestador.UpdateDownload -> ' + E.Message);

    end;

  finally

    zQuery.Free;
    Stream.Free;

  end;

end;

{
procedure TDMManifestador.UpdateDownload(CodigoNotaFiscal: Integer; XML: String);
var
  zQuery: TUniQuery;
begin

  zQuery := TUniQuery.Create(Self);

  try

    try

      zQuery.Connection := FDConnection1;
      zQuery.SQL.Add('UPDATE NF                  ');
      zQuery.SQL.Add('   SET DOWNLOAD = ''S''    ');
      zQuery.SQL.Add('   SET XML      =:XML      ');
      zQuery.SQL.Add('   SET XML_PATH =:XML_PATH ');
      zQuery.SQL.Add(' WHERE CODIGO   =:CODIGO   ');
      zQuery.ParamByName('XML').LoadFromFile(XML, ftBlob);
      zQuery.ParamByName('XML_PATH').Value      := XML;
      zQuery.ParamByName('CODIGO').AsInteger    := CodigoNotaFiscal;
      zQuery.ExecSQL;

    except

      on E:Exception do
      begin

        raise Exception.Create('TDMManifestador.UpdateDownload -> ' + E.Message);

      end;

    end;

  finally

    zQuery.Free;

  end;

end;
}

procedure TDMManifestador.ConfigurarAcbrMail;
begin

  ACBrMail1.Host := ZQueryCFGSMTP.AsString;
  ACBrMail1.Username := ZQueryCFGSMTP_CONTA.AsString;
  ACBrMail1.Password := ZQueryCFGSMTP_SENHA.AsString;
  ACBrMail1.From := ZQueryCFGSMTP_EMAIL.AsString;
  ACBrMail1.FromName := ZQueryCFGSMTP_REMETENTE.AsString;
  ACBrMail1.Port := ZQueryCFGSMTP_PORTA.AsString;
  ACBrMail1.SetSSL := True;
  ACBrMail1.SetTLS := False;
  ACBrMail1.Subject := 'Notas fiscais de fornecedores';
  ACBrMail1.AltBody.Text := 'Segue em anexo notas fiscais recebidas de fornecedores';

end;

procedure TDMManifestador.GerarLogNF(CodigoNotaFiscal, CodigoOperacao: Integer; Msg: String = '');
var
  zQuery: TUniQuery;
begin

  zQuery := TUniQuery.Create(Self);

  try

    try

      zQuery.Connection := FDConnection1;
      zQuery.SQL.Add('INSERT INTO NF_LOG      ');
      zQuery.SQL.Add('          (ID_NF,       ');
      zQuery.SQL.Add('           OPERACAO,    ');
      zQuery.SQL.Add('           HISTORICO,   ');
      zQuery.SQL.Add('           DATAHORA)    ');
      zQuery.SQL.Add('   VALUES (:ID_NF,      ');
      zQuery.SQL.Add('           :OPERACAO,   ');
      zQuery.SQL.Add('           :HISTORICO,  ');
      zQuery.SQL.Add('           :DATAHORA)   ');
      zQuery.ParamByName('ID_NF').AsInteger := CodigoNotaFiscal;
      zQuery.ParamByName('OPERACAO').AsInteger := CodigoOperacao;

      case CodigoOperacao of

        1: zQuery.ParamByName('HISTORICO').AsString := 'Enviado evento de manifesta��o ';
        2: zQuery.ParamByName('HISTORICO').AsString := 'Solicitado download do arquivo xml';
        3: zQuery.ParamByName('HISTORICO').AsString := 'Manifesta��o efetuada com sucesso';
        4: zQuery.ParamByName('HISTORICO').AsString := 'Download do arquivo xml efetuado com sucesso';
        5: zQuery.ParamByName('HISTORICO').AsString := 'Erro -> ' + Copy(Msg, 1, 70);
        6: zQuery.ParamByName('HISTORICO').AsString := 'Erro -> ' + Copy(Msg, 1, 70);

      end;

      zQuery.ParamByName('DATAHORA').AsDateTime := Now;
      zQuery.ExecSQL;

    except

      on E:Exception do
      begin

        raise Exception.Create('TDMManifestador.GerarLogNF -> ' + E.Message);

      end;

    end;

  finally

    zQuery.Free;

  end;

end;

procedure TDMManifestador.ExibirDialogoProcessamento;
begin

  frmProcessamento.Show;
  frmProcessamento.BringToFront;

end;

procedure TDMManifestador.OcultarDialogoProcessamento;
begin

  frmProcessamento.ListBoxMensagens.Items.Clear;
  frmProcessamento.Hide;

end;


procedure TDMManifestador.SetActionManifestar(const Value: TAction);
begin

  FActionManifestar := Value;

end;

procedure TDMManifestador.SetActionDownload(const Value: TAction);
begin

  FActionDownload := Value;

end;

procedure TDMManifestador.SetActionVisualizar(const Value: TAction);
begin

  FActionVisualizar := Value;

end;

end.
