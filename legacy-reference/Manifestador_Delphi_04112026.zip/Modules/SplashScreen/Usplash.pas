unit Usplash;
interface
uses
  Winapi.Windows, wininet, Winapi.Messages, System.SysUtils, System.Variants,
  System.Classes, Vcl.Graphics,
  Vcl.Controls, Vcl.Forms, Vcl.Dialogs, Vcl.ExtCtrls, Vcl.StdCtrls,
  Vcl.ComCtrls, dxGDIPlusClasses, inifiles,
  JvMTComponents, JvComponentBase, JvThread, TLHelp32, JvExControls,
  JvAnimatedImage, JvGIFCtrl, acPNG, Vcl.Samples.Gauges;
type
  Tfrmsplash = class(TForm)
    Image1: TImage;
    ProgressBar: TProgressBar;
    Timer1: TTimer;
    Label1: TLabel;
    imgDll: TImage;
    imgBancodeDados: TImage;
    imgConfiguracoes: TImage;
    imgIniciando: TImage;
    Image3: TImage;
    Timer2: TTimer;
    ProgressBar1: TGauge;
    procedure FormCreate(Sender: TObject);
    procedure Timer1Timer(Sender: TObject);
    procedure Timer2Timer(Sender: TObject);
  private
    procedure CreateFlatRoundRgn;
      protected
    procedure CreateParams(var Params: TCreateParams); override;
    procedure AtualizarStatus( Mensagem : string ; imagem :Timage );
  public
    { Public declarations }
  end;
var
  frmsplash: Tfrmsplash;
implementation
{$R *.dfm}
uses
  UfrmPrincipal,
  Encriptacao,
  Winapi.CommCtrl;

procedure ExcludeRectRgn(var Rgn: HRGN; LeftRect, TopRect, RightRect, BottomRect: Integer);
var
  RgnEx: HRGN;
begin
  RgnEx := CreateRectRgn(LeftRect, TopRect, RightRect, BottomRect);
  CombineRgn(Rgn, Rgn, RgnEx, RGN_OR);
  DeleteObject(RgnEx);
end;

procedure Tfrmsplash.AtualizarStatus(Mensagem: string; imagem: Timage);
begin
    Label1.Caption := Mensagem;
    Imagem.Visible := true;
end;

procedure Tfrmsplash.CreateFlatRoundRgn;
const
  CORNER_SIZE = 6;
var
  Rgn: HRGN;
begin
  with BoundsRect do
  begin
    Rgn := CreateRoundRectRgn(0, 0, Right - Left + 1, Bottom - Top + 1, CORNER_SIZE, CORNER_SIZE);
    // exclude left-bottom corner
    ExcludeRectRgn(Rgn, 0, Bottom - Top - CORNER_SIZE div 2, CORNER_SIZE div 2, Bottom - Top + 1);
    // exclude right-bottom corner
    ExcludeRectRgn(Rgn, Right - Left - CORNER_SIZE div 2, Bottom - Top - CORNER_SIZE div 2, Right - Left , Bottom - Top);
  end;
  // the operating system owns the region, delete the Rgn only SetWindowRgn fails
  if SetWindowRgn(Handle, Rgn, True) = 0 then
    DeleteObject(Rgn);
end;

procedure Tfrmsplash.CreateParams(var Params: TCreateParams);
const
  CS_DROPSHADOW = $00020000;
begin
  inherited CreateParams(Params);
  with Params do
  begin
    Style := WS_POPUP;
    WindowClass.Style := WindowClass.Style or CS_DROPSHADOW;
  end;
end;

procedure Tfrmsplash.FormCreate(Sender: TObject);
begin

  Caption := Application.Title;

  BorderStyle := bsNone;
  CreateFlatRoundRgn;

end;

procedure Tfrmsplash.Timer1Timer(Sender: TObject);
begin
  alphablendvalue   :=  AlphaBlendValue + 3;

  if AlphaBlendValue=255  then
  begin
    Timer1.Enabled  := False;
    timer2.Enabled  :=  True;
    //close;
  end;
end;

procedure Tfrmsplash.Timer2Timer(Sender: TObject);
begin

  if ProgressBar1.Progress<=100 then
  begin

     ProgressBar1.Progress := ProgressBar1.Progress + 1;

     case ProgressBar1.Progress of

        10: AtualizarStatus('Carregando dependencias...',imgdll);
        25: AtualizarStatus('Conectando ao Banco de Dados...',imgBancodeDados);
        45: AtualizarStatus('Carregando as configura��es do Sistema...',imgconfiguracoes);
        75: AtualizarStatus('Iniciando Sistema...',imgIniciando);

     end;

  end;



  if ProgressBar1.Progress=100 then
  begin

      Timer2.Enabled:=false;
      frmsplash.Hide;
      close;

  end;

end;

end.
