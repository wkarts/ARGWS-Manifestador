unit uRibbonSettings;

interface

uses
  IniFiles,
  Forms,
  Graphics,
  System.StrUtils,
  System.SysUtils,
  dxRibbonSkins,
  dxRibbon;

type
  TUserData = record
    vUsuario: string;
  end;

type
  TGetSetResources = record
    vGetSetObjetct : string;
  end;

type
  TGetHexColor = record
    vGetHexColor : TColor;
  end;

type
 TMethodTheme = (TGetTheme, TSetTheme, TGetThemeColor, TSetThemeColor, TGetRibbonMinimize, TSetRibbonMinimize);

type
  TRibbonSettings = class
  private
    class function GetIniFilePath(const FileName, UserName: string): string;
    class function HtmlToTColor(sColor : string) : TColor;
  public
    class procedure SaveRibbonColor(COLOR: Integer; const UserData: TUserData);
    class procedure GetRibbonColor(dxRibbon: TdxRibbon; const UserData: TUserData);

    class procedure SaveRibbonMinimize(estado: string; const UserData: TUserData);
    class procedure GetRibbonMinimize(dxRibbon: TdxRibbon; const UserData: TUserData);

    class procedure SaveRibbonTheme(Theme: Integer; const UserData: TUserData);
    class procedure GetRibbonTheme(dxRibbon: TdxRibbon; const UserData: TUserData);
  end;

type
  TRibbonGetSet = class
  private

  public
    class procedure ThemeRibbonConfig(GetOrSet: TMethodTheme; Ribbon: TdxRibbon; User: String; CODE: Integer);
 end;

  {$REGION ' Finalidade da Classe ThemeRibbonConfig '}
    (*

      A classe TRibbonSettings � uma implementa��o em Delphi destinada a facilitar a gest�o e personaliza��o das
      configura��es visuais do componente TdxRibbon, proveniente da biblioteca DevExpress VCL.

      Essa classe visa simplificar a manipula��o de atributos como cor, tema e estado de minimiza��o do ribbon
      (barra de ferramentas estilo fita) para diferentes usu�rios em um aplicativo.

      O principal prop�sito da classe � oferecer m�todos que permitem salvar e recuperar as prefer�ncias visuais de
      cada usu�rio, proporcionando uma experi�ncia personalizada durante a intera��o com a interface do usu�rio.

      Dessa forma, � poss�vel adaptar a apar�ncia do ribbon conforme as prefer�ncias individuais, contribuindo para
      uma experi�ncia de usu�rio mais amig�vel e ajustada �s necessidades de cada pessoa.

      A classe TRibbonSettings utiliza arquivos INI para armazenar as configura��es do ribbon de forma persistente
      entre as sess�es do aplicativo.

      Ela oferece m�todos espec�ficos para salvar e recuperar informa��es sobre a cor, o tema e o estado de minimiza��o
      do ribbon associados a um usu�rio espec�fico.

      Al�m disso, a classe TRibbonGetSet proporciona um m�todo centralizado chamado ThemeRibbonConfig para facilitar a
      aplica��o e obten��o dessas configura��es.

      Este m�todo utiliza enumera��es para indicar a opera��o desejada (obter ou definir configura��es) e recebe par�metros,
      como o componente TdxRibbon, o nome do usu�rio e c�digos que representam cor, tema e estado de minimiza��o.

      Em resumo, a classe TRibbonSettings tem como finalidade simplificar a gest�o das prefer�ncias visuais do TdxRibbon,
      contribuindo para um design mais flex�vel e personalizado em aplica��es Delphi que fazem uso da biblioteca DevExpress VCL.

    *)
  {$ENDREGION}

  {$REGION ' Informa��es da ThemeRibbonConfig '}
    (*

      Autor:              [Wallce Kleiton]
      Email:              [wkarts@gmail.com]
      Whatsapp:           [5575988449231]
      Vers�o:             [1.6]
      Data de Cria��o:    [26/01/2024]
      �ltima Modifica��o: [29/01/2024]

      Logs da Vers�o:
        - [Log da Vers�o 1.0] 26/01/2024
           #Vers�o incial

        - [Log da Vers�o 1.1] 27/01/2024
           #Inclu�do m�todo de Utiliza��o da Classe

        - [Log da Vers�o 1.2] 28/01/2024
           #Melhorias no M�todo de Utiliza��o da Classe

        - [Log da Vers�o 1.3] 28/01/2024
           #Melhorias no M�todo de Utiliza��o da Classe
           #Inclu�do Instru��es de Utiliza��o da Classe
           #Melhorias no M�todod e utiliza��o
           #Inclu�do Record  TGetHexColor.vGetHexColor para armazenar uma
            Cor Hexa Decimal para que possa ser utilizada de alguma forma
            e aplicar aos demais objetos do sistema que queira alter a cor
            de acordo com o Thema do Sistema.

        - [Log da Vers�o 1.4] 28/01/2024
           #Melhoriar para o Record TGetHexColor.vGetHexColor agoara Passa
            a Ser do tipo TColor para obter Melhor resultado ao aplicar a
            cor.
           #Inclu�do novo m�todo:  class function HtmlToTColor(sColor : string) : TColor;
            capaz de converter uma string com o c�digo da cor html em TColor.
           #Agora as cores Definidas na em TGetHexColor.vGetHexColor s�o
            as mesma cores RGB da dxRibbon.

        - [Log da Vers�o 1.5] 28/01/2024
           #Inclu�do Exemplo de utiliza��o de Minimiza��o da dxRibbon

        - [Log da Vers�o 1.6] 28/01/2024
           #Corre��o no Par�metro "TSetRibbonMinimize" contornando o erro de n�o minimizar a dxribbon

    *)
  {$ENDREGION}

  {$REGION ' Instru��es de Uso ThemeRibbonConfig '}
    (*
      Instru��es de Uso do M�todo ThemeRibbonConfig:

      Para utilizar o m�todo ThemeRibbonConfig, siga estes passos:

      1. Inclua a unit `uRibbonSettings` em sua cl�usula `uses`.
      2. Crie uma inst�ncia do componente `TdxRibbon` que deseja configurar.
      3. Chame o m�todo `ThemeRibbonConfig`, passando os seguintes par�metros:
         - `GetOrSet`: Tipo de opera��o desejada (`TGetTheme` para obter configura��es existentes, `TSetTheme` para definir novas configura��es).
         - `Ribbon`: Inst�ncia do componente `TdxRibbon` que ser� configurado.
         - `User`: Nome do usu�rio para o qual as configura��es ser�o aplicadas.
         - `CODE`: C�digo espec�fico da opera��o (�ndice da cor, tema ou estado de minimiza��o).

      C�digos para opera��es espec�ficas:
      - `TGetTheme`: Obt�m as configura��es de tema existentes.
      - `TSetTheme`: Define um novo tema.
      - `TGetThemeColor`: Obt�m a cor atual.
      - `TSetThemeColor`: Define uma nova cor.
      - `TGetRibbonMinimize`: Obt�m o estado de minimiza��o.
      - `TSetRibbonMinimize`: Define um novo estado de minimiza��o.

      C�digos para cores dispon�veis:
      - 0: Amarelo
      - 1: Azul
      - 2: Verde
      - 3: Laranja
      - 4: Roxo

      C�digos para temas dispon�veis:
      - 0: 2007 - Black
      - 1: 2007 - Blue
      - 2: 2007 - Silver
      - 3: 2010 - Black
      - 4: 2010 - Blue
      - 5: 2010 - Silver
      - 6: 2013 - DarkGray
      - 7: 2013 - LightGray
      - 8: 2013 - White
      - 9: 2016 - Colorful
      - 10: 2016 Tablet - Colorful
      - 11: 2019 - Colorful

      C�digos para estados de minimiza��o:
      - 0: False (N�o minimizado)
      - 1: True (Minimizado)

      Exemplos de uso:

      - Obter configura��es existentes:
        ```delphi
        TRibbonGetSet.ThemeRibbonConfig(TGetTheme, DxRibbon1, 'Joao', 0);
        ```

      - Definir novo tema:
        ```delphi
        TRibbonGetSet.ThemeRibbonConfig(TSetTheme, DxRibbon1, 'Maria', 1);
        ```

      - Obter cor atual:
        ```delphi
        TRibbonGetSet.ThemeRibbonConfig(TGetThemeColor, DxRibbon1, 'Jos�', 0);
        ```

      - Definir nova cor:
        ```delphi
        TRibbonGetSet.ThemeRibbonConfig(TSetThemeColor, DxRibbon1, 'Ana', 2);
        ```

      - Obter estado de minimiza��o:
        ```delphi
        TRibbonGetSet.ThemeRibbonConfig(TGetRibbonMinimize, DxRibbon1, 'Carlos', 0);
        ```

      Exemplo de uso para pegar as Defini��es do Usu�rio ap�s o Login:

      ```delphi
      procedure TFormPrincipal.FormCreate(Sender: TObject);
      begin

        {$REGION ' Carregamento do Thema do Usu�rio '}

          // Substitua USER pelo nome do usu�rio desejado
          TRibbonGetSet.ThemeRibbonConfig(TGetTheme,          DxRibbon1, USER, 0);
          TRibbonGetSet.ThemeRibbonConfig(TGetThemeColor,     DxRibbon1, USER, 0);
          TRibbonGetSet.ThemeRibbonConfig(TGetRibbonMinimize, DxRibbon1, USER, 0);

        {$ENDREGION}

      end;
      ```

      Exemplo de uso para Definir Estado de Minimiza��o da DxRibbon:

      ```delphi
      procedure TfrmPrincipal.dxRibbonMinimizedChanged(Sender: TdxCustomRibbon);
      begin

        if (dxRibbon.ShowTabGroups) then
           TRibbonGetSet.ThemeRibbonConfig(TSetRibbonMinimize, DxRibbon, Dados.vUsuario, 1)
        else
           TRibbonGetSet.ThemeRibbonConfig(TSetRibbonMinimize, DxRibbon, Dados.vUsuario, 0);
      end;
      ```
    *)
  {$ENDREGION}

var
 FGetSetResources :TGetSetResources;
 FGetHexColor : TGetHexColor;

implementation

{ TRibbonSettings }

  {$REGION ' TRibbonSettings '}

    class function TRibbonSettings.HtmlToTColor(sColor : string) : TColor;
    var
      HexValue: string;
      Red, Green, Blue: Byte;
    begin
      // Remover o caractere '#' se estiver presente
      HexValue := StringReplace(sColor, '#', '', [rfReplaceAll]);

      // Certificar-se de que temos exatamente 6 caracteres
      if Length(HexValue) = 6 then
      begin
        // Converter os componentes hexadecimais para decimal
        Red := StrToInt('$' + Copy(HexValue, 1, 2));
        Green := StrToInt('$' + Copy(HexValue, 3, 2));
        Blue := StrToInt('$' + Copy(HexValue, 5, 2));

        // Criar a cor TColor usando a fun��o RGB global
        Result := (Blue shl 16) or (Green shl 8) or Red;
      end
      else
      begin
        // Se o valor hexadecimal n�o estiver no formato esperado, definir como preto
        Result := clBlack;
      end;
    end;

    class function TRibbonSettings.GetIniFilePath(const FileName, UserName: string): string;
    begin
      Result := ExtractFilePath(Application.ExeName) + '\' + FileName + '_' + UserName + '.ini';
    end;

    class procedure TRibbonSettings.SaveRibbonColor(COLOR: Integer; const UserData: TUserData);
    var
      ArquivoIni: TIniFile;
    begin
      ArquivoIni := TIniFile.Create(GetIniFilePath('ribboncolor', UserData.vUsuario));
      try
        ArquivoIni.WriteString(UserData.vUsuario, 'USER', UserData.vUsuario);
        ArquivoIni.WriteInteger(UserData.vUsuario, 'COLOR', COLOR);
      finally
        ArquivoIni.Free;
      end;
    end;

    class procedure TRibbonSettings.GetRibbonColor(dxRibbon: TdxRibbon; const UserData: TUserData);
    var
      ArquivoIni: TIniFile;
      USER: String;
      COLOR: Integer;
    begin

      ArquivoIni := TIniFile.Create(GetIniFilePath('ribboncolor', UserData.vUsuario));
      try
        USER := ArquivoIni.ReadString(UserData.vUsuario, 'USER', UserData.vUsuario);
        if USER = UserData.vUsuario then
          COLOR := ArquivoIni.ReadInteger(UserData.vUsuario, 'COLOR', 1);
      finally
        ArquivoIni.Free;
      end;

      // Set dxRibbon.ColorSchemeAccent based on COLOR
      case COLOR of
        0:
        begin
          dxRibbon.ColorSchemeAccent := rcsaYellow;
          FGetHexColor.vGetHexColor  := HtmlToTColor('#EAA53E'); //$00FFB90F; //DarkGoldenrod1
        end;
        1:
        begin
          dxRibbon.ColorSchemeAccent := rcsaBlue;
          FGetHexColor.vGetHexColor  := HtmlToTColor('#2B579A'); //$009A572B; //Blue Desconhecido
        end;
        2:
        begin
          dxRibbon.ColorSchemeAccent := rcsaGreen;
          FGetHexColor.vGetHexColor  := HtmlToTColor('#217346'); //$00008B45; //SpringGreen4 //$002E8B57; //SeaGreen Color  - //$00006400; //DarkGreen html color
        end;
        3:
        begin
          dxRibbon.ColorSchemeAccent := rcsaOrange;
          FGetHexColor.vGetHexColor  := HtmlToTColor('#B7472A'); //$00CD4F39; //Tomato3
        end;
        4:
        begin
          dxRibbon.ColorSchemeAccent := rcsaPurple;
          FGetHexColor.vGetHexColor  := HtmlToTColor('#80397B'); //$008B4789; //Orchid4
        end;
      end;

    end;

    class procedure TRibbonSettings.SaveRibbonMinimize(estado: string; const UserData: TUserData);
    var
      ArquivoIni: TIniFile;
    begin
      ArquivoIni := TIniFile.Create(GetIniFilePath('ribbon', UserData.vUsuario));
      try
        ArquivoIni.WriteString(UserData.vUsuario, 'MINIMIZE', estado);
        ArquivoIni.WriteString(UserData.vUsuario, 'USER', UserData.vUsuario);
      finally
        ArquivoIni.Free;
      end;
    end;

    class procedure TRibbonSettings.GetRibbonMinimize(dxRibbon: TdxRibbon; const UserData: TUserData);
    var
      ArquivoIni: TIniFile;
      estado, USER: String;
    begin
      ArquivoIni := TIniFile.Create(GetIniFilePath('ribbon', UserData.vUsuario));
      try
        USER := ArquivoIni.ReadString(UserData.vUsuario, 'USER', UserData.vUsuario);
        if USER = UserData.vUsuario then
          estado := ArquivoIni.ReadString(UserData.vUsuario, 'MINIMIZE', 'true');
      finally
        ArquivoIni.Free;
      end;

      dxRibbon.ShowTabGroups := (estado = 'true');
    end;

    class procedure TRibbonSettings.SaveRibbonTheme(Theme: Integer; const UserData: TUserData);
    var
      ArquivoIni: TIniFile;
    begin
      ArquivoIni := TIniFile.Create(GetIniFilePath('ribbontheme', UserData.vUsuario));
      try
        ArquivoIni.WriteString(UserData.vUsuario, 'USER', UserData.vUsuario);
        ArquivoIni.WriteInteger(UserData.vUsuario, 'THEME', Theme);
      finally
        ArquivoIni.Free;
      end;
    end;

    class procedure TRibbonSettings.GetRibbonTheme(dxRibbon: TdxRibbon; const UserData: TUserData);
    var
      ArquivoIni: TIniFile;
      USER: String;
      THEME: Integer;
    begin
      ArquivoIni := TIniFile.Create(GetIniFilePath('ribbontheme', UserData.vUsuario));
      try
        USER := ArquivoIni.ReadString(UserData.vUsuario, 'USER', UserData.vUsuario);
        if USER = UserData.vUsuario then
          THEME := ArquivoIni.ReadInteger(UserData.vUsuario, 'THEME', 9);
      finally
        ArquivoIni.Free;
      end;

      // Set dxRibbon properties based on THEME
      case THEME of
        0: begin
             dxRibbon.Style := rs2007;
             dxRibbon.ColorSchemeName := 'Black';
             dxRibbon.ColorSchemeAccent := rcsaBlue;
           end;
        1: begin
             dxRibbon.Style := rs2007;
             dxRibbon.ColorSchemeName := 'Blue';
             dxRibbon.ColorSchemeAccent := rcsaBlue;
           end;
        2: begin
             dxRibbon.Style := rs2007;
             dxRibbon.ColorSchemeName := 'Silver';
             dxRibbon.ColorSchemeAccent := rcsaBlue;
           end;
        3: begin
             dxRibbon.Style := rs2010;
             dxRibbon.ColorSchemeName := 'Black';
             dxRibbon.ColorSchemeAccent := rcsaBlue;
           end;
        4: begin
             dxRibbon.Style := rs2010;
             dxRibbon.ColorSchemeName := 'Blue';
             dxRibbon.ColorSchemeAccent := rcsaBlue;
           end;
        5: begin
             dxRibbon.Style := rs2010;
             dxRibbon.ColorSchemeName := 'Silver';
             dxRibbon.ColorSchemeAccent := rcsaBlue;
           end;
        6: begin
             dxRibbon.Style := rs2013;
             dxRibbon.ColorSchemeName := 'DarkGray';
             dxRibbon.ColorSchemeAccent := rcsaBlue;
           end;
        7: begin
             dxRibbon.Style := rs2013;
             dxRibbon.ColorSchemeName := 'LightGray';
             dxRibbon.ColorSchemeAccent := rcsaBlue;
           end;
        8: begin
             dxRibbon.Style := rs2013;
             dxRibbon.ColorSchemeName := 'White';
             dxRibbon.ColorSchemeAccent := rcsaBlue;
           end;
        9: begin
             dxRibbon.Style := rs2016;
             dxRibbon.ColorSchemeName := 'Colorful';
             dxRibbon.ColorSchemeAccent := rcsaBlue;
           end;
        10: begin
              dxRibbon.Style := rs2016tablet;
              dxRibbon.ColorSchemeName := 'Colorful';
              dxRibbon.ColorSchemeAccent := rcsaBlue;
            end;
        11: begin
              dxRibbon.Style := rs2019;
              dxRibbon.ColorSchemeName := 'Colorful';
              dxRibbon.ColorSchemeAccent := rcsaBlue;
            end;
      end;
    end;

  {$ENDREGION}

{ TRibbonGetSet }

  {$REGION ' TRibbonGetSet '}

    class procedure TRibbonGetSet.ThemeRibbonConfig(GetOrSet: TMethodTheme; Ribbon: TdxRibbon; User: String; CODE: Integer);

      procedure GetTheme(RibbonSettings: TRibbonSettings;GRibbon:TdxRibbon; GUserData: TUserData);
      begin
        RibbonSettings.GetRibbonTheme(GRibbon, GUserData);
      end;

      procedure SetTheme(RibbonSettings: TRibbonSettings; SSelectedTheme: Integer; SUserData: TUserData);
      begin
        RibbonSettings.SaveRibbonTheme(SSelectedTheme, SUserData);
      end;

      procedure GetColor(RibbonSettings: TRibbonSettings;GRibbon:TdxRibbon; GUserData: TUserData);
      begin
        RibbonSettings.GetRibbonColor(GRibbon, GUserData);
      end;

      procedure SetColor(RibbonSettings: TRibbonSettings; SSelectedColor: Integer; SUserData: TUserData);
      begin
        RibbonSettings.SaveRibbonColor(SSelectedColor, SUserData);
      end;

      procedure GetMinimize(RibbonSettings: TRibbonSettings; GRibbon:TdxRibbon; GUserData: TUserData);
      begin
        RibbonSettings.GetRibbonMinimize(GRibbon, GUserData);
      end;

      procedure SetMinimize(RibbonSettings: TRibbonSettings; SMinimize: String; SUserData: TUserData);
      begin
        RibbonSettings.SaveRibbonMinimize(SMinimize, SUserData);
      end;

    var
      RibbonSettings: TRibbonSettings;
      UserData: TUserData;
      Minimize: string;
    begin

      FGetSetResources.vGetSetObjetct := '';

      UserData.vUsuario := User;

      case CODE of
        0: Minimize := 'False';
        1: Minimize := 'True';
      end;

      if not(Assigned(RibbonSettings)) then
        RibbonSettings := TRibbonSettings.Create;

      try

        case GetOrSet of

          TGetTheme:
          begin
            GetTheme(RibbonSettings, Ribbon, UserData);
            FGetSetResources.vGetSetObjetct := 'TGetTheme';
          end;

          TSetTheme:
          begin
            SetTheme(RibbonSettings, CODE, UserData);
            GetTheme(RibbonSettings, Ribbon, UserData);
            FGetSetResources.vGetSetObjetct := 'TSetTheme';
          end;

          TGetThemeColor:
          begin
            GetColor(RibbonSettings, Ribbon, UserData);
            FGetSetResources.vGetSetObjetct := 'TGetThemeColor';
          end;

          TSetThemeColor:
          begin
            SetColor(RibbonSettings, CODE, UserData);
            GetColor(RibbonSettings, Ribbon, UserData);
            FGetSetResources.vGetSetObjetct := 'TSetThemeColor';
          end;

          TGetRibbonMinimize:
          begin
            GetMinimize(RibbonSettings, Ribbon, UserData);
            FGetSetResources.vGetSetObjetct := 'TGetRibbonMinimize';
          end;

          TSetRibbonMinimize:
          begin
            SetMinimize(RibbonSettings, Minimize, UserData);
            FGetSetResources.vGetSetObjetct := 'TSetRibbonMinimize';
          end;

        end;

      except

        on E: Exception do
        begin
          raise Exception.Create('Erro em RibbonSettings:' + sLineBreak + E.Message );
        end;

      end;

    end;

  {$ENDREGION}

end.
