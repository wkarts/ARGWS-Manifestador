unit uBaseForms;

interface

uses
  uInterfaces,
  StdCtrls,

  DBCtrls,
  DB,
  ExtCtrls,
  Mask,
  TypInfo,
  StrUtils,
  ComCtrls,
  JvExMask,
  JvToolEdit,
  JvDBControls,

  cxContainer,
  cxEdit,
  cxMaskEdit,
  cxDropDownEdit,
  cxImageComboBox,
  cxDBEdit,
  cxDBLookupComboBox,

  DBGridEh,
  DBCtrlsEh,
  DBLookupEh,
  cxButtonEdit,

  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms, Dialogs,
  dxBar, dxRibbon, dxRibbonForm, dxRibbonSkins, cxGraphics, cxControls, cxLookAndFeels,
  cxLookAndFeelPainters, cxClasses, dxRibbonBackstageView, cxBarEditItem,
  dxCore, dxRibbonCustomizationForm,
  cxTextEdit, dxStatusBar, dxRibbonStatusBar, dxSkinsCore, dxSkinBasic,
  dxSkinBlack, dxSkinBlue, dxSkinBlueprint, dxSkinCaramel, dxSkinCoffee,
  dxSkinDarkroom, dxSkinDarkSide, dxSkinDevExpressDarkStyle,
  dxSkinDevExpressStyle, dxSkinFoggy, dxSkinGlassOceans, dxSkinHighContrast,
  dxSkiniMaginary, dxSkinLilian, dxSkinLiquidSky, dxSkinLondonLiquidSky,
  dxSkinMcSkin, dxSkinMetropolis, dxSkinMetropolisDark, dxSkinMoneyTwins,
  dxSkinOffice2007Black, dxSkinOffice2007Blue, dxSkinOffice2007Green,
  dxSkinOffice2007Pink, dxSkinOffice2007Silver, dxSkinOffice2010Black,
  dxSkinOffice2010Blue, dxSkinOffice2010Silver, dxSkinOffice2013DarkGray,
  dxSkinOffice2013LightGray, dxSkinOffice2013White, dxSkinOffice2016Colorful,
  dxSkinOffice2016Dark, dxSkinOffice2019Black, dxSkinOffice2019Colorful,
  dxSkinOffice2019DarkGray, dxSkinOffice2019White, dxSkinPumpkin, dxSkinSeven,
  dxSkinSevenClassic, dxSkinSharp, dxSkinSharpPlus, dxSkinSilver,
  dxSkinSpringtime, dxSkinStardust, dxSkinSummer2008, dxSkinTheAsphaltWorld,
  dxSkinTheBezier, dxSkinsDefaultPainters, dxSkinValentine,
  dxSkinVisualStudio2013Blue, dxSkinVisualStudio2013Dark,
  dxSkinVisualStudio2013Light, dxSkinVS2010, dxSkinWhiteprint,
  dxSkinXmas2008Blue, dxSkinWXI;

type
  TfrmBaseForm = class(TdxRibbonForm)
    RibbonBaseForm: TdxRibbon;
    dxRibbon1Tab1: TdxRibbonTab;
    procedure FormCreate(Sender: TObject);
    procedure FormKeyDown(Sender: TObject; var Key: Word; Shift: TShiftState);
    procedure FormKeyPress(Sender: TObject; var Key: Char);
  private
    { Private declarations }
  public
    { Public declarations }
    //procedure SetRibbonBaseFormVisibility(IsVisible: Boolean);
    {
    procedure TfrmBaseForm.SetRibbonBaseFormVisibility(IsVisible: Boolean);
    begin
      if Assigned(RibbonBaseForm) then
        RibbonBaseForm.Visible := IsVisible;
    end;
    }
  end;

var
  frmBaseForm: TfrmBaseForm;
  function CustomKeyDown(Frm : TForm; var Key : Word; Shift : TShiftState) : Boolean;

implementation
   uses uRibbonSettings;

  {$REGION 'RIBBON CONFIG'}
   {$IFDEF RETAGUARDA}
      //uses uPrincipal;
   {$ENDIF}
  {$ENDREGION}

{$R *.dfm}

{ TForm2 }

function CustomKeyDown(Frm : TForm; var Key: Word; Shift : TShiftState) : Boolean;
var
  cDropDown,
  AControl : TWinControl;
  EControl : TcxCustomEdit;
begin

  Result := false;

  EControl := nil;

  if (not Assigned(Frm)) or (Key = 0) then
    Exit;

  if ((Key = VK_RETURN) or (key = VK_TAB)) and (Shift = []) then
  begin

    if (
         (Frm.ActiveControl is TEdit)
      or (Frm.ActiveControl is TCheckBox)
      or (Frm.ActiveControl is TRadioButton)
      or (Frm.ActiveControl is TComboBox)
      or (Frm.ActiveControl is TMaskEdit)
      or (Frm.ActiveControl is TLabeledEdit)
      or (Frm.ActiveControl is TJvComboEdit)
      or (Frm.ActiveControl is TJvDateEdit)
      or (Frm.ActiveControl is TJvDirectoryEdit)
//      // Controls DevExpress
      or (Frm.ActiveControl is TcxButtonEdit)
      or (Frm.ActiveControl is TcxDBButtonEdit)
      or (Frm.ActiveControl is TcxCustomInnerTextEdit)
      or (Frm.ActiveControl is TcxCustomLookupComboBox)
      or (Frm.ActiveControl is TcxLookupComboBox)
      or (Frm.ActiveControl is TcxDBMemo)
      // DB Controls
      or (Frm.ActiveControl is TDBEdit)
      or (Frm.ActiveControl is TDBCheckBox)
      or (Frm.ActiveControl is TDBRadioGroup)
      or (Frm.ActiveControl is TDBComboBox)
      or (Frm.ActiveControl is TDBLookupComboBox)
      or (Frm.ActiveControl is TDBLookupListBox)
      // DB Controls Jedi
      or (Frm.ActiveControl is TJvDBDateEdit)
      or (Frm.ActiveControl is TJvDBCalcEdit)
      or (Frm.ActiveControl is TJvDBComboEdit)
      //DB EHLib
      or (Frm.ActiveControl is TDBComboBoxEh)
      or (Frm.ActiveControl is TDBLookupComboboxEh)
    ) then

      if (Frm.ActiveControl is TEdit) then
        Result := not ( Assigned(TEdit(Frm.ActiveControl).OnKeyPress) or Assigned(TEdit(Frm.ActiveControl).OnKeyDown) )
      else
      if (Frm.ActiveControl is TCheckBox) then
        Result := not ( Assigned(TCheckBox(Frm.ActiveControl).OnKeyPress) or Assigned(TCheckBox(Frm.ActiveControl).OnKeyDown) )
      else
      if (Frm.ActiveControl is TRadioButton) then
        Result := not ( Assigned(TRadioButton(Frm.ActiveControl).OnKeyPress) or Assigned(TRadioButton(Frm.ActiveControl).OnKeyDown) )
      else
      if (Frm.ActiveControl is TComboBox) then
        Result := not ( Assigned(TComboBox(Frm.ActiveControl).OnKeyPress) or Assigned(TComboBox(Frm.ActiveControl).OnKeyDown) )
      else
      if (Frm.ActiveControl is TMaskEdit) then
        Result := not ( Assigned(TMaskEdit(Frm.ActiveControl).OnKeyPress) or Assigned(TMaskEdit(Frm.ActiveControl).OnKeyDown) )
      else
      if (Frm.ActiveControl is TLabeledEdit) then
        Result := not ( Assigned(TLabeledEdit(Frm.ActiveControl).OnKeyPress) or Assigned(TLabeledEdit(Frm.ActiveControl).OnKeyDown) )
      else
      if (Frm.ActiveControl is TJvComboEdit) then
        Result := not ( Assigned(TJvComboEdit(Frm.ActiveControl).OnKeyPress) or Assigned(TJvComboEdit(Frm.ActiveControl).OnKeyDown) )
      else
      if (Frm.ActiveControl is TJvDateEdit) then
        Result := not ( Assigned(TJvDateEdit(Frm.ActiveControl).OnKeyPress) or Assigned(TJvDateEdit(Frm.ActiveControl).OnKeyDown) )
      else
      if (Frm.ActiveControl is TJvDirectoryEdit) then
        Result := not ( Assigned(TJvDirectoryEdit(Frm.ActiveControl).OnKeyPress) or Assigned(TJvDirectoryEdit(Frm.ActiveControl).OnKeyDown) )
      else
      if (Frm.ActiveControl is TcxButtonEdit) then
        Result := not ( Assigned(TcxButtonEdit(Frm.ActiveControl).OnKeyPress) or Assigned(TcxButtonEdit(Frm.ActiveControl).OnKeyDown) )
      else
      if (Frm.ActiveControl is TcxDBButtonEdit) then
        Result := not ( Assigned(TcxDBButtonEdit(Frm.ActiveControl).OnKeyPress) or Assigned(TcxDBButtonEdit(Frm.ActiveControl).OnKeyDown) )
      else
      // DB Controls
      if (Frm.ActiveControl is TDBEdit) then
        Result := not ( Assigned(TDBEdit(Frm.ActiveControl).OnKeyPress) or Assigned(TDBEdit(Frm.ActiveControl).OnKeyDown) )
      else
      if (Frm.ActiveControl is TDBCheckBox) then
        Result := not ( Assigned(TDBCheckBox(Frm.ActiveControl).OnKeyPress) or Assigned(TDBCheckBox(Frm.ActiveControl).OnKeyDown) )
      else
      if (Frm.ActiveControl is TDBComboBox) then
        Result := not ( Assigned(TDBComboBox(Frm.ActiveControl).OnKeyPress) or Assigned(TDBComboBox(Frm.ActiveControl).OnKeyDown) )
      else
      if (Frm.ActiveControl is TDBLookupComboBox) then
        Result := not ( Assigned(TDBLookupComboBox(Frm.ActiveControl).OnKeyPress) or Assigned(TDBLookupComboBox(Frm.ActiveControl).OnKeyDown) )
      else
      if (Frm.ActiveControl is TDBLookupListBox) then
        Result := not ( Assigned(TDBLookupListBox(Frm.ActiveControl).OnKeyPress) or Assigned(TDBLookupListBox(Frm.ActiveControl).OnKeyDown) )
      else
      // DB Controls Jedi
      if (Frm.ActiveControl is TJvDBDateEdit) then
        Result := not ( Assigned(TJvDBDateEdit(Frm.ActiveControl).OnKeyPress) or Assigned(TJvDBDateEdit(Frm.ActiveControl).OnKeyDown) )
      else
      if (Frm.ActiveControl is TJvDBCalcEdit) then
        Result := not ( Assigned(TJvDBCalcEdit(Frm.ActiveControl).OnKeyPress) or Assigned(TJvDBCalcEdit(Frm.ActiveControl).OnKeyDown) )
      else
      if (Frm.ActiveControl is TJvDBComboEdit) then
        Result := not ( Assigned(TJvDBComboEdit(Frm.ActiveControl).OnKeyPress) or Assigned(TJvDBComboEdit(Frm.ActiveControl).OnKeyDown) )
      else
//      // Controls DevExpress
//      if (Frm.ActiveControl is TcxCustomLookupComboBox) then
//        Result := not ( Assigned(TcxCustomLookupComboBox(Frm.ActiveControl).OnKeyPress) or Assigned(TcxCustomLookupComboBox(Frm.ActiveControl).OnKeyDown) )
//      else
//      if (Frm.ActiveControl is TcxLookupComboBox) then
//        Result := not ( Assigned(TcxLookupComboBox(Frm.ActiveControl).OnKeyPress) or Assigned(TcxLookupComboBox(Frm.ActiveControl).OnKeyDown) )
//      else
        //Controls EH
      if (Frm.ActiveControl is TDBComboBoxEh) then
        Result := not ( Assigned(TDBComboBoxEh(Frm.ActiveControl).OnKeyPress) or Assigned(TDBComboBoxEh(Frm.ActiveControl).OnKeyDown) )
      else
      if (Frm.ActiveControl is TDBLookupComboboxEh) then
        Result := not ( Assigned(TDBLookupComboboxEh(Frm.ActiveControl).OnKeyPress) or Assigned(TDBLookupComboboxEh(Frm.ActiveControl).OnKeyDown) )
      else
        Result := True
    else
    if (Frm.ActiveControl is TDBMemo) then
    begin
      with TDBMemo(Frm.ActiveControl) do
        Result := ( Assigned(DataSource) and Assigned(DataSource.DataSet) and (not (DataSource.DataSet.State in [dsInsert, dsEdit])) );
    end
    else
    if (Frm.ActiveControl is TDBMemoEh) then
    begin
      with TDBMemoEh(Frm.ActiveControl) do
        Result := ( Assigned(DataSource) and Assigned(DataSource.DataSet) and (not (DataSource.DataSet.State in [dsInsert, dsEdit])) );
    end
    else
    if (Frm.ActiveControl is TcxDBMemo) then
    begin
      with TcxDBMemo(Frm.ActiveControl) do
        Result := ( Assigned(DataBinding.DataSource) and Assigned(DataBinding.DataSource.DataSet) and (not (DataBinding.DataSource.DataSet.State in [dsInsert, dsEdit])) );
    end
    else
    if ( (Frm.ActiveControl is TMemo) and TMemo(Frm.ActiveControl).Enabled and (not TMemo(Frm.ActiveControl).ReadOnly) ) then
      Result := False;


    // Controles DevExpress
    if (Frm.ActiveControl is TcxCustomDropDownInnerEdit) then
    begin
      AControl := Screen.ActiveControl;
      if Supports(AControl, IcxInnerEditHelper) or Supports(AControl, IcxContainerInnerControl) then
        EControl := TcxCustomEdit(AControl.Owner)
      else
        if AControl is TcxCustomEdit then
          EControl := TcxCustomEdit(AControl);

      cDropDown := TWinControl(Frm.FindComponent(EControl.Name));

      if (cDropDown is TcxComboBox ) then
        Result := not TcxComboBox(cDropDown).DroppedDown
      else
      if (cDropDown is TcxImageComboBox ) then
        Result := not TcxImageComboBox(cDropDown).DroppedDown
      else
      if (cDropDown is TcxLookupComboBox ) then
        Result := not TcxLookupComboBox(cDropDown).DroppedDown
      else
      if (cDropDown is TcxDBComboBox ) then
        Result := not TcxDBComboBox(cDropDown).DroppedDown
      else
      if (cDropDown is TcxDBImageComboBox ) then
        Result := not TcxDBImageComboBox(cDropDown).DroppedDown
      else
      if (cDropDown is TcxDBLookupComboBox ) then
        Result := not TcxDBLookupComboBox(cDropDown).DroppedDown;
    end;

    if Result then
    begin
      Key := 0;
      Frm.Perform(WM_NEXTDLGCTL, 0, 0);
    end;

  end;

end;

procedure TfrmBaseForm.FormCreate(Sender: TObject);
begin

  {$REGION 'RIBBON CONFIG'}

    DisableAero := True;

  {$REGION ' Carregamento do Thema do Usu�rio '}

    TRibbonGetSet.ThemeRibbonConfig(TGetTheme, RibbonBaseForm, '', 0); //Pega o Thema
    TRibbonGetSet.ThemeRibbonConfig(TGetThemeColor, RibbonBaseForm, '', 0); //Pega a Cor

  {$ENDREGION}

    {$IFDEF RETAGUARDA}
       {
       if (frmPrincipal <> nil) then
       begin
          RibbonBaseForm.ColorSchemeAccent := frmPrincipal.dxRibbon.ColorSchemeAccent;
          RibbonBaseForm.Style             := frmPrincipal.dxRibbon.Style;
          RibbonBaseForm.ColorSchemeName   := frmPrincipal.dxRibbon.ColorSchemeName;
          RibbonBaseForm.ColorSchemeAccent := frmPrincipal.dxRibbon.ColorSchemeAccent;
       end;
       }
    {$ENDIF}

  {$ENDREGION}

end;

procedure TfrmBaseForm.FormKeyDown(Sender: TObject; var Key: Word;
  Shift: TShiftState);
begin
  //CustomKeyDown(Self, Key, Shift);
end;

procedure TfrmBaseForm.FormKeyPress(Sender: TObject; var Key: Char);
begin
  // Tirar o som
  //if (Key = #13) then
  //  Key := #0;
end;


end.

