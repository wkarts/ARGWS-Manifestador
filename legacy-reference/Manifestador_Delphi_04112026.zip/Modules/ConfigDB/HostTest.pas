{
  Criado por Cristiano Kliemann (criskmn@ig.com.br).

  Visite http://www.cristianok.hpg.com.br e veja outros exemplos, dicas e
  tutoriais sobre Delphi e assuntos relacionados.

  Qualquer d�vida ou sugest�o, sinta-se a vontade para enviar um e-mail.

  Voc� pode usar essa unidade em qualquer aplicativo, comercial ou n�o, desde
  que n�o assuma a autoria dele.
}

unit HostTest;

interface

{
  IPAddr � uma string com o endere�o IP do host que quer testar. TCPPort �
  a porta e Timeout � o tempo m�ximo que quer esperar para que a fun��o teste
  a conex�o, em milisegundos. Em m�quinas em LAN, pode ser bem baixo. N�o testei
  ainda, mas � prov�vel que uns 200 milisegundos seja o suficiente.

  A fun��o retorna True se conseguir se conectar � porta do host e False se n�o
  conseguir. � importante lembrar que a fun��o retorna False se n�o conseguir
  testar tamb�m, ou seja, em qualquer erro em fun��es de prepara��o do socket.
}
function TestTCPPort(IPAddr: string; TCPPort: Word; Timeout: Integer): Boolean;

implementation

uses WinSock;

type
  TSimpleFDSet = record
    fd_count: u_int;
    fd_array: array[0..0] of TSocket;
  end;

function SocketsInit: Boolean;
var
  Data: TWSAData;
begin
  Result := WSAStartup($101, Data) = 0;
end;

function TestTCPPort(IPAddr: string; TCPPort: Word; Timeout: Integer): Boolean;
var
  S: TSocket;
  Addr: TSockAddrIn;
  NonBlocking: Integer;
  Sockets: TSimpleFDSet;
  Res: Integer;
  T: TTimeVal;
begin
  Result := False;
  s := socket(PF_INET, SOCK_STREAM, IPPROTO_TCP);
  if s = INVALID_SOCKET then begin
    if WSAGetLastError = WSANOTINITIALISED then begin
      if not SocketsInit then EXIT;
      s := socket(PF_INET, SOCK_STREAM, IPPROTO_TCP);
    end else EXIT;
  end;
  try
    NonBlocking := 1;
    if ioctlsocket(s, FIONBIO, NonBlocking) = SOCKET_ERROR then EXIT;
    FillChar(addr, SizeOf(addr), 0);
    addr.sin_family := PF_INET;
    addr.sin_port := htons(TCPPort);
    addr.sin_addr.S_addr := inet_addr(PAnsiChar(IPAddr));
    Res := connect(s, addr, SizeOf(addr));
    if Res = SOCKET_ERROR then begin
      if WSAGetLastError = WSAEWOULDBLOCK then begin
        Sockets.fd_count := 1;
        Sockets.fd_array[0] := S;
        T.tv_sec := 0;
        T.tv_usec := Timeout * 1000;
        Result := select(0, nil, @Sockets, nil, @T) = 1;
      end;
    end;
  finally
    closesocket(S);
  end;
end;

initialization
finalization
  WSACleanup;
end.
