unit uPorta;

interface

uses
  uBaseForms,
  Winapi.Windows, Winapi.Messages, System.SysUtils, System.Variants, System.Classes, Vcl.Graphics,
  Vcl.Controls, Vcl.Forms, Vcl.Dialogs, Vcl.StdCtrls, HostTest, IdBaseComponent,
  IdComponent, IdTCPConnection, IdTCPClient, Winapi.ShellAPI, AdvGlowButton,
  AdvMetroButton, AdvSmoothPanel, AdvSmoothExpanderPanel, Vcl.ExtCtrls,
  cxGraphics, cxControls, cxLookAndFeels, cxLookAndFeelPainters, dxSkinsCore,
  dxSkinBasic, dxSkinBlack, dxSkinBlue, dxSkinBlueprint, dxSkinCaramel,
  dxSkinCoffee, dxSkinDarkroom, dxSkinDarkSide, dxSkinDevExpressDarkStyle,
  dxSkinDevExpressStyle, dxSkinFoggy, dxSkinGlassOceans, dxSkinHighContrast,
  dxSkiniMaginary, dxSkinLilian, dxSkinLiquidSky, dxSkinLondonLiquidSky,
  dxSkinMcSkin, dxSkinMetropolis, dxSkinMetropolisDark, dxSkinMoneyTwins,
  dxSkinOffice2007Black, dxSkinOffice2007Blue, dxSkinOffice2007Green,
  dxSkinOffice2007Pink, dxSkinOffice2007Silver, dxSkinOffice2010Black,
  dxSkinOffice2010Blue, dxSkinOffice2010Silver, dxSkinOffice2013DarkGray,
  dxSkinOffice2013LightGray, dxSkinOffice2013White, dxSkinOffice2016Colorful,
  dxSkinOffice2016Dark, dxSkinOffice2019Black, dxSkinOffice2019Colorful,
  dxSkinOffice2019DarkGray, dxSkinOffice2019White, dxSkinPumpkin, dxSkinSeven,
  dxSkinSevenClassic, dxSkinSharp, dxSkinSharpPlus, dxSkinSilver,
  dxSkinSpringtime, dxSkinStardust, dxSkinSummer2008, dxSkinTheAsphaltWorld,
  dxSkinTheBezier, dxSkinsDefaultPainters, dxSkinValentine,
  dxSkinVisualStudio2013Blue, dxSkinVisualStudio2013Dark,
  dxSkinVisualStudio2013Light, dxSkinVS2010, dxSkinWhiteprint,
  dxSkinXmas2008Blue, dxCore, dxRibbonSkins, dxRibbonCustomizationForm,
  cxClasses, dxRibbon;

type
  Tvporta = class(TfrmBaseForm)
    porta: TEdit;
    Button1: TButton;
    Label1: TLabel;
    Label2: TLabel;
    ip: TEdit;
    IdTCPClient1: TIdTCPClient;
    Button2: TButton;
    Panel2: TPanel;
    AdvGlowButton1: TAdvGlowButton;
    AdvGlowButton2: TAdvGlowButton;
    procedure Button1Click(Sender: TObject);
    procedure Button2Click(Sender: TObject);
    procedure AdvGlowButton1Click(Sender: TObject);
    procedure AdvGlowButton2Click(Sender: TObject);
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  vporta: Tvporta;

implementation

{$R *.dfm}

procedure Tvporta.AdvGlowButton1Click(Sender: TObject);
begin
  Button1.Click;
end;

procedure Tvporta.AdvGlowButton2Click(Sender: TObject);
begin
  Button2.Click;
end;

procedure Tvporta.Button1Click(Sender: TObject);
begin
  try
    IdTCPClient1.Disconnect;
    IdTCPClient1.Host := Trim(ip.Text);
    IdTCPClient1.Port := StrToInt(porta.Text);
    IdTCPClient1.Connect;
    ShowMessage('Aberta');
  except
    ShowMessage('Fechada');
  end;
end;

procedure Tvporta.Button2Click(Sender: TObject);
begin
 //Permiss�o no Postgre
 WinExec('netsh.exe -c firewall add portopening protocol=TCP port=3050 name=Firebird mode=ENABLE scope=SUBNET', SW_HIDE);
 //Permiss�o no EXE
 ShellExecute(Application.Handle,nil,'netsh.exe',PChar('firewall add allowedprogram "' + Application.exename + '" Anti-Virus ENABLE'),nil,SW_HIDE);
 showmessage ('Porta Liberada com Sucesso!');
  {
  ReleaseCapture;
  PostMessage(vporta.Handle, WM_SYSCOMMAND, $F012, 0);

  ReleaseCapture;
  PostMessage(vporta.Handle, WM_SYSCOMMAND, $F012, 0);
  }
end;

end.
