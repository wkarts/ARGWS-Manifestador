unit uConfiguraDB;

interface

uses
  uBaseForms,
  LocalCache4D,

  Winapi.Windows, Winapi.Messages, System.SysUtils, System.Variants, System.Classes, Vcl.Graphics,
  Vcl.Controls, Vcl.Forms, Vcl.Dialogs, ACBrBase, ACBrEnterTab,
  Vcl.XPMan, Vcl.StdCtrls, Vcl.Mask, JvExMask, JvToolEdit, registry,
  dxGDIPlusClasses, dxBevel, AdvGlowButton, Vcl.ExtCtrls, JvExStdCtrls, JvGroupBox, UniProvider, InterBaseUniProvider, Data.DB,
  DBAccess, Uni, Vcl.ComCtrls, dxBarBuiltInMenu, cxGraphics, cxControls,
  cxLookAndFeels, cxLookAndFeelPainters, cxPC, Vcl.Buttons, cxContainer, cxEdit,
  dxSkinsCore, dxSkinBasic, dxSkinBlack, dxSkinBlue, dxSkinBlueprint,
  dxSkinCaramel, dxSkinCoffee, dxSkinDarkroom, dxSkinDarkSide,
  dxSkinDevExpressDarkStyle, dxSkinDevExpressStyle, dxSkinFoggy,
  dxSkinGlassOceans, dxSkinHighContrast, dxSkiniMaginary, dxSkinLilian,
  dxSkinLiquidSky, dxSkinLondonLiquidSky, dxSkinMcSkin, dxSkinMetropolis,
  dxSkinMetropolisDark, dxSkinMoneyTwins, dxSkinOffice2007Black,
  dxSkinOffice2007Blue, dxSkinOffice2007Green, dxSkinOffice2007Pink,
  dxSkinOffice2007Silver, dxSkinOffice2010Black, dxSkinOffice2010Blue,
  dxSkinOffice2010Silver, dxSkinOffice2013DarkGray, dxSkinOffice2013LightGray,
  dxSkinOffice2013White, dxSkinOffice2016Colorful, dxSkinOffice2016Dark,
  dxSkinOffice2019Black, dxSkinOffice2019Colorful, dxSkinOffice2019DarkGray,
  dxSkinOffice2019White, dxSkinPumpkin, dxSkinSeven, dxSkinSevenClassic,
  dxSkinSharp, dxSkinSharpPlus, dxSkinSilver, dxSkinSpringtime, dxSkinStardust,
  dxSkinSummer2008, dxSkinTheAsphaltWorld, dxSkinTheBezier,
  dxSkinsDefaultPainters, dxSkinValentine, dxSkinVisualStudio2013Blue,
  dxSkinVisualStudio2013Dark, dxSkinVisualStudio2013Light, dxSkinVS2010,
  dxSkinWhiteprint, dxSkinXmas2008Blue, cxCheckBox, dxCore, dxRibbonSkins,
  dxRibbonCustomizationForm, cxClasses, dxRibbon, dxSkinWXI;

type
  TFrmConfiguraDB = class(TfrmBaseForm)
    Panel2: TPanel;
    AdvGlowButton1: TAdvGlowButton;
    AdvGlowButton2: TAdvGlowButton;
    AdvGlowButton3: TAdvGlowButton;
    AdvGlowButton8: TAdvGlowButton;
    dlgOpen1: TOpenDialog;
    ACBrEnterTab1: TACBrEnterTab;
    Base: TUniConnection;
    Firebird_Driver: TInterBaseUniProvider;
    Panel1: TPanel;
    pnl1: TPanel;
    Panel4: TPanel;
    Label1: TLabel;
    Splitter2: TSplitter;
    Splitter15: TSplitter;
    Splitter1: TSplitter;
    Splitter4: TSplitter;
    Splitter5: TSplitter;
    Splitter6: TSplitter;
    Splitter8: TSplitter;
    Splitter9: TSplitter;
    Splitter10: TSplitter;
    XPM: TXPManifest;
    Splitter3: TSplitter;
    Splitter7: TSplitter;
    Splitter11: TSplitter;
    Splitter12: TSplitter;
    Splitter13: TSplitter;
    Splitter14: TSplitter;
    cxPageControl1: TcxPageControl;
    tabConfig: TcxTabSheet;
    tabInstrucoes: TcxTabSheet;
    Label5: TLabel;
    Panel5: TPanel;
    Label43: TLabel;
    Label44: TLabel;
    Label41: TLabel;
    Label42: TLabel;
    Label40: TLabel;
    Label39: TLabel;
    Label38: TLabel;
    btnOpenFile: TSpeedButton;
    SpeedButton1: TSpeedButton;
    Label2: TLabel;
    Label3: TLabel;
    Label4: TLabel;
    Label6: TLabel;
    Label7: TLabel;
    edtLib: TEdit;
    edtDatabase: TComboBox;
    ComboBox2: TComboBox;
    edtPorta: TEdit;
    edtServidor: TEdit;
    ComboBox1: TComboBox;
    edtDBImagens: TComboBox;
    BitBtn9: TBitBtn;
    BitBtn1: TBitBtn;
    edtUsername: TEdit;
    edtPassword: TEdit;
    BitBtn2: TBitBtn;
    edtCompany: TEdit;
    edtRazao: TEdit;
    edtChar: TEdit;
    Memo1: TMemo;
    cbInstanceType: TCheckBox;
    Label8: TLabel;
    Label9: TLabel;
    Label10: TLabel;
    Label11: TLabel;
    rservidor: TRadioButton;
    Image3: TImage;
    Image4: TImage;
    restacao: TRadioButton;
    cbDBImgTest: TcxCheckBox;
    procedure edtDatabaseButtonClick(Sender: TObject);
    procedure edtDBImagensButtonClick(Sender: TObject);
    procedure edtLibButtonClick(Sender: TObject);
    procedure rservidorClick(Sender: TObject);
    procedure restacaoClick(Sender: TObject);
    procedure AdvGlowButton2Click(Sender: TObject);
    procedure AdvGlowButton3Click(Sender: TObject);
    procedure AdvGlowButton1Click(Sender: TObject);
    procedure AdvGlowButton8Click(Sender: TObject);
    procedure FormShow(Sender: TObject);
    procedure scGPGlyphButton1Click(Sender: TObject);
    procedure BitBtn9Click(Sender: TObject);
    procedure BitBtn1Click(Sender: TObject);
    procedure BitBtn2Click(Sender: TObject);
    procedure FormCloseQuery(Sender: TObject; var CanClose: Boolean);
    procedure FormCreate(Sender: TObject);
  private
    procedure CriaReg;
    procedure LeRegConfDB;
    function CheckParametros:Boolean;
    { Private declarations }
  public
    { Public declarations }
  end;

var
  FrmConfiguraDB: TFrmConfiguraDB;

implementation

uses
  uPorta,
  uWKConnectionParams,
  Encriptacao;

{$R *.dfm}

procedure TFrmConfiguraDB.AdvGlowButton1Click(Sender: TObject);
begin

    try

        with Base do
        begin

            try
                Disconnect;
                Database := edtDatabase.Text;
                Server   := edtservidor.Text;
                UserName := edtUsername.Text;
                Password := edtPassword.Text;
                Port := StrToInt(edtporta.Text);
                if combobox2.Text = 'TCP' then
                  SpecificOptions.Values['Protocol'] := 'TCP';
                if combobox2.Text = 'Local' then
                  SpecificOptions.Values['Protocol'] := 'Local';
                SpecificOptions.Values['ClientLibrary'] := edtLib.Text;
                Connect;
            finally
                if Connected then
                 application.messagebox('Banco principal conectado com sucesso!', 'Aten��o', mb_ok + mb_IconInformation);
            end;

            if cbDBImgTest.Checked then
            begin
                try
                    Disconnect;
                    Database := edtDBImagens.Text;
                    Server   := edtservidor.Text;
                    UserName := edtUsername.Text;
                    Password := edtPassword.Text;
                    Port := StrToInt(edtporta.Text);
                    if combobox2.Text = 'TCP' then
                      SpecificOptions.Values['Protocol'] := 'TCP';
                    if combobox2.Text = 'Local' then
                      SpecificOptions.Values['Protocol'] := 'Local';
                    SpecificOptions.Values['ClientLibrary'] := edtLib.Text;
                    Connect;
                finally
                    if Connected then
                     application.messagebox('Banco de Replica��o conectado com sucesso!', 'Aten��o', mb_ok + mb_IconInformation);
                end;
            end;



        end;
    except
        on E: Exception do
        begin
         application.messagebox(PWideChar('N�o foi poss�vel efetuar a conx�o, verfique e tente novamente!'+ sLineBreak +'Erro: ' + sLineBreak + E.Message), 'Aten��o', mb_ok + mb_IconInformation);
        end;
    end;

end;

procedure TFrmConfiguraDB.AdvGlowButton2Click(Sender: TObject);
begin

  if (UpperCase(edtservidor.Text) = 'LOCALHOST') and restacao.Checked then
  begin
    MessageBox(Handle, 'Favor informar o IP do Servidor, para configura��o de esta��o',
      'Configurador', 48 + 0);
    edtservidor.SetFocus;
    Exit;
  end;

  CriaReg;

end;

procedure TFrmConfiguraDB.AdvGlowButton3Click(Sender: TObject);
begin
  Close;
end;

procedure TFrmConfiguraDB.AdvGlowButton8Click(Sender: TObject);
begin

    vporta := tvporta.Create(self);
    vPorta.IP.Text := edtServidor.Text;
    vPorta.Porta.Text := edtPorta.Text;
    vporta.ShowModal;

end;

procedure TFrmConfiguraDB.BitBtn1Click(Sender: TObject);
begin
    with TOpenDialog.Create(Self) do
    begin
      Title   := TWKConnectionClass.NOMEDOSISTEMA + ' ' + TWKConnectionClass.SUBTITULO + ' | Selecione um Banco de Dados do Tipo (FDB)' ;
      Filter := 'DataBase (*.fdb)|*.fdb';
      //Options := [fdoPickFolders, fdoPathMustExist, fdoForceFileSystem];
      InitialDir := ExtractFilePath(Application.ExeName) + 'Dados\';
      if Execute then edtDBImagens.Text := FileName;
    end;
end;

procedure TFrmConfiguraDB.BitBtn2Click(Sender: TObject);
begin
    with TOpenDialog.Create(Self) do
    begin
      Title   := TWKConnectionClass.NOMEDOSISTEMA + ' ' + TWKConnectionClass.SUBTITULO + ' | Selecione uma Lib do Tipo (dll) ';
      Filter := 'Biblioteca (*.dll)|*.dll';
      //Options := [fdoPickFolders, fdoPathMustExist, fdoForceFileSystem];
      InitialDir := ExtractFilePath(Application.ExeName);
      if Execute then edtLib.Text := FileName;
    end;
end;

procedure TFrmConfiguraDB.BitBtn9Click(Sender: TObject);
begin
    with TOpenDialog.Create(Self) do
    begin
      Title   := TWKConnectionClass.NOMEDOSISTEMA + ' ' + TWKConnectionClass.SUBTITULO + ' | Selecione um Banco de Dados do Tipo (FDB)' ;
      Filter := 'DataBase (*.fdb)|*.fdb';
      //Options := [fdoPickFolders, fdoPathMustExist, fdoForceFileSystem];
      InitialDir := ExtractFilePath(Application.ExeName) + 'Dados\';
      if Execute then edtDatabase.Text := FileName;
    end;
end;

function TFrmConfiguraDB.CheckParametros: Boolean;
begin
    Result := True;
    if
       not(edtDatabase.text      =  M_DATABASE)
       or not(edtporta.Text      =  M_PORTA)
       or not(edtservidor.Text   =  M_SERVIDOR)
       or not(combobox2.Text     =  M_PROTOCOL)
       or not(edtDBImagens.text  =  M_DATABASEREP)
       or not(edtLib.Text        =  M_LIBCON)
       or not(edtUsername.Text   =  M_USUARIO_DB)
       or not(edtPassword.Text   =  M_SENHA_DB)
    then
    begin
       Result := False;
    end;
end;

Procedure TFrmConfiguraDB.CriaReg;
begin

  INSTANCE_CACHE_NAME   := 'STAND_DB_PARAMS_CONNECTION';

  if cbInstanceType.Checked then
    INSTANCE_CACHE_NAME := FWKConnectionClass.GetComputer;

  M_SERVIDOR        := edtservidor.Text;
  M_PORTA           := edtporta.Text;
  M_LIBCON          := edtLib.Text;
  M_PROTOCOL        := combobox2.Text;
  M_DATABASE        := edtDatabase.text;
  M_DATABASEREP     := edtDBImagens.text;
  M_USUARIO_DB      := edtUsername.Text;
  M_SENHA_DB        := edtPassword.Text;
  M_CHARSET         := edtChar.Text;
  M_RAZAO           := edtRazao.Text;
  M_NCOMPANY        := EmptyStr;

  if not(edtCompany.Text = EmptyStr) then
    M_NCOMPANY        := FormatFloat('00000000000000', StrToInt64(edtCompany.Text));

  if not(M_NCOMPANY.IsEmpty) then
   INSTANCE_CACHE_NAME := INSTANCE_CACHE_NAME + '|' +  M_NCOMPANY;

  {
  if FParamsOptions.MULTIEMP then
    NCOMPANY    := FormatFloat('00000000000000', StrToInt64(edtCompany.Text))
  else
    NCOMPANY    := EmptyStr;
  }


  LocalCache.Instance(INSTANCE_CACHE_NAME).SetItem('SERVER',   M_SERVIDOR);
  LocalCache.Instance(INSTANCE_CACHE_NAME).SetItem('PORT',     M_PORTA);
  LocalCache.Instance(INSTANCE_CACHE_NAME).SetItem('LIBCON',   M_LIBCON);
  LocalCache.Instance(INSTANCE_CACHE_NAME).SetItem('PROTOCOL', M_PROTOCOL);
  LocalCache.Instance(INSTANCE_CACHE_NAME).SetItem('MAINDB',   M_DATABASE);
  LocalCache.Instance(INSTANCE_CACHE_NAME).SetItem('IMGDB',    M_DATABASEREP);
  LocalCache.Instance(INSTANCE_CACHE_NAME).SetItem('LOGINDB',  Crypt(crEncriptar, M_USUARIO_DB, kCh));
  LocalCache.Instance(INSTANCE_CACHE_NAME).SetItem('PASSWDB',  Crypt(crEncriptar, M_SENHA_DB, kCh));
  LocalCache.Instance(INSTANCE_CACHE_NAME).SetItem('CHARSET',  M_CHARSET);
  LocalCache.Instance(INSTANCE_CACHE_NAME).SetItem('RAZAO',    M_RAZAO);
  LocalCache.SaveToStorage(ExtractFilePath(Application.ExeName) + 'CONF\params.conf');

  Application.messagebox('Par�metros gravados com sucesso!', 'Confirma��o',  mb_ok + mb_IconInformation);

end;

procedure TFrmConfiguraDB.edtDatabaseButtonClick(Sender: TObject);
begin

  if dlgOpen1.Execute then
    edtDatabase.Text := dlgOpen1.FileName;

end;

procedure TFrmConfiguraDB.edtDBImagensButtonClick(Sender: TObject);
begin
  if dlgOpen1.Execute then
    edtDBImagens.Text := dlgOpen1.FileName;
end;

procedure TFrmConfiguraDB.edtLibButtonClick(Sender: TObject);
begin
  if dlgOpen1.Execute then
    edtLib.Text := dlgOpen1.FileName;
end;

procedure TFrmConfiguraDB.FormCloseQuery(Sender: TObject; var CanClose: Boolean);
begin
      if not(CheckParametros) then
       if Application.messagebox('Par�metros alterados, por�m n�o foram salvos!'
                                + sLineBreak + sLineBreak +'Gostaria de salvar?' ,
                               'Aten��o',  MB_YESNO + MB_ICONQUESTION
                                ) = idYES
       then
       begin
         CriaReg;
       end;
end;

procedure TFrmConfiguraDB.FormCreate(Sender: TObject);
begin
  inherited;
  //FParamsOptions.GetParamsOptions;
end;

procedure TFrmConfiguraDB.FormShow(Sender: TObject);
begin
  inherited;
  LeRegConfDB;
end;

procedure TFrmConfiguraDB.restacaoClick(Sender: TObject);
begin

  edtservidor.Enabled := true;
  edtservidor.SetFocus;

  edtDataBase.Text := 'MANIFESTO';


end;

procedure TFrmConfiguraDB.LeRegConfDB;
begin

    FParamsOptions.GetParamsOptions;

    M_NCOMPANY     := FParamsOptions.COMPANY;
    M_SERVIDOR     := FParamsOptions.SERVER;
    M_PORTA        := FParamsOptions.PORT;
    M_LIBCON       := FParamsOptions.LIBCON;
    M_PROTOCOL     := FParamsOptions.PROTOCOL;
    M_DATABASE     := FParamsOptions.MAINDB;
    M_DATABASEREP  := FParamsOptions.IMGDB;
    M_CHARSET      := FParamsOptions.CHARSET;
    M_RAZAO        := FParamsOptions.RAZAO;
    M_USUARIO_DB   := Crypt(crDecriptar, FParamsOptions.LOGINDB, kCh);
    M_SENHA_DB     := Crypt(crDecriptar, FParamsOptions.PASSWDDB, kCh);

    if M_DATABASE.IsEmpty then
      M_DATABASE := 'MANIFESTO';

    if M_PORTA.IsEmpty then
      M_PORTA := '3040';

    if M_SERVIDOR.IsEmpty then
      M_SERVIDOR := '127.0.0.1';

    if M_PROTOCOL.IsEmpty then
      M_PROTOCOL := 'TCP';

    if M_DATABASEREP.IsEmpty then
      M_DATABASEREP := 'MANIFESTOIMG';

    if M_LIBCON.IsEmpty then
      M_LIBCON := 'fbclient.dll';

    if M_USUARIO_DB.IsEmpty then
      M_USUARIO_DB := 'SYSDBA';

    if M_SENHA_DB.IsEmpty then
      M_SENHA_DB := 'masterkey';

    if M_CHARSET.IsEmpty then
      M_CHARSET := 'NONE';


    edtservidor.Text        :=     M_SERVIDOR   ;
    edtporta.Text           :=     M_PORTA      ;
    edtLib.Text             :=     M_LIBCON     ;
    combobox2.Text          :=     M_PROTOCOL   ;
    edtDatabase.text        :=     M_DATABASE   ;
    edtDBImagens.text       :=     M_DATABASEREP;
    edtUsername.Text        :=     M_USUARIO_DB ;
    edtPassword.Text        :=     M_SENHA_DB   ;
    edtChar.Text            :=     M_CHARSET    ;
    cbInstanceType.Checked  :=     FParamsOptions.MCINSTANCE;

    if FParamsOptions.MULTIEMP then
      edtCompany.Text :=  M_NCOMPANY
    else
      edtCompany.Text :=  EmptyStr;

    if not(FParamsOptions.RAZAO.IsEmpty) then
      edtRAZAO.Text :=  M_RAZAO
    else
      edtRAZAO.Text :=  EmptyStr;

end;

procedure TFrmConfiguraDB.rservidorClick(Sender: TObject);
begin

  edtservidor.Text := 'LOCALHOST';
  edtservidor.Enabled := False;

end;

procedure TFrmConfiguraDB.scGPGlyphButton1Click(Sender: TObject);
begin
  Close;
end;

end.
