inherited vporta: Tvporta
  BorderIcons = [biSystemMenu]
  BorderStyle = bsDialog
  Caption = 'Teste e Libera'#231#227'o de Porta'
  ClientHeight = 127
  ClientWidth = 182
  Color = clWhite
  Position = poDesktopCenter
  ExplicitWidth = 198
  ExplicitHeight = 166
  TextHeight = 13
  object Label1: TLabel [0]
    Left = 8
    Top = 30
    Width = 11
    Height = 16
    Caption = 'IP'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWindowText
    Font.Height = -13
    Font.Name = 'Tahoma'
    Font.Style = []
    ParentFont = False
  end
  object Label2: TLabel [1]
    Left = 121
    Top = 30
    Width = 30
    Height = 16
    Caption = 'Porta'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWindowText
    Font.Height = -13
    Font.Name = 'Tahoma'
    Font.Style = []
    ParentFont = False
  end
  inherited RibbonBaseForm: TdxRibbon
    Width = 182
    ExplicitWidth = 182
    inherited dxRibbon1Tab1: TdxRibbonTab
      Index = 0
    end
  end
  object porta: TEdit
    Left = 121
    Top = 49
    Width = 49
    Height = 24
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWindowText
    Font.Height = -13
    Font.Name = 'Tahoma'
    Font.Style = []
    ParentFont = False
    TabOrder = 2
    Text = '3050'
  end
  object Button1: TButton
    Left = 408
    Top = 142
    Width = 109
    Height = 59
    Caption = 'Verificar'
    TabOrder = 4
    OnClick = Button1Click
  end
  object ip: TEdit
    Left = 8
    Top = 49
    Width = 107
    Height = 24
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWindowText
    Font.Height = -13
    Font.Name = 'Tahoma'
    Font.Style = []
    ParentFont = False
    TabOrder = 1
    Text = '127.0.0.1'
  end
  object Button2: TButton
    Left = 526
    Top = 142
    Width = 109
    Height = 59
    Caption = 'Liberar'
    TabOrder = 5
    OnClick = Button2Click
  end
  object Panel2: TPanel
    Left = 0
    Top = 97
    Width = 182
    Height = 30
    Align = alBottom
    BevelOuter = bvNone
    Color = 10114859
    ParentBackground = False
    TabOrder = 3
    object AdvGlowButton1: TAdvGlowButton
      Left = 0
      Top = 0
      Width = 78
      Height = 30
      Align = alLeft
      Caption = 'Verificar'
      Font.Charset = DEFAULT_CHARSET
      Font.Color = clWhite
      Font.Height = -11
      Font.Name = 'Tahoma'
      Font.Style = []
      NotesFont.Charset = DEFAULT_CHARSET
      NotesFont.Color = clWindowText
      NotesFont.Height = -11
      NotesFont.Name = 'Tahoma'
      NotesFont.Style = []
      ParentFont = False
      Picture.Data = {
        89504E470D0A1A0A0000000D494844520000001C0000001C0806000000720DDF
        9400000006624B474400FF00FF00FFA0BDA7930000029949444154480DED96BB
        6B145114876724EADAF8CA03B3429060152C44246011529880B8A821887F824D
        60D53E9034B2A08DF927C4228DC1070A826C0461D30B891AD8428D5A8A8F8DEE
        8EDF6FB8775E99CCCC6A2A7139DF3DCF7BCEDE796CE238FFFAC7EDE6809EE795
        A91F867E907C6279E3BAEE47F4CE0843F6C10D58810E24A54D6019AEC2EEBCA9
        9927A4C1140D1660085A5087066C806490E50C8C410FBC85194EFC045D5C18E4
        C29CE7793AD177F44DD8BF5D0772BD701B54FB0B7D7DBBDAD4381BE641B2CA32
        925A9412A4F614ACC159A5D11370CCC9FA50300D3A99861DCAAA4DCBB17797E2
        E873A013BF42EB722B1C8744099AF00D0A9F2CDEC571D87B095AF005C692F9C0
        275905492D087669B0B9D830F5A5F8256C42D797D2ECBFC8DED8C9F04F2BB705
        1203A077EAE9966481007BD386E9B4BA8F076D0BFF061BE7385AFE0A3A2634D3
        BD1D8D05230EF949DC7BD0812BBC87CB68C9384B094E822F1AE01B2C65907CD0
        92E02EFE73D3183314621378F741BDA619F618DB4AD31803463B2AB2B6D59E35
        22FA0EB6BEFD03065CC0F6C5D80F71DA30991846C8513CAA9D1E79067BB241E3
        078A46759A9F27F00816B12FA3258B2C9B50A1C65E46DC408E1AEB9DD1A1A249
        EE43434D057EC057836C7D91B051C4A2E619B4A12F120E4D12B9AF05357668DE
        B05E6A7FC28B7042C2225905492D918AB914686825164C38D4DC02C94C2215BA
        64F5F8EFC44FDB097AE9FD5B47EF0D27A45814FCED8FF7617ABC860E044F74CA
        A83044E13C48565946C24CB645AD4EB68696CC665747B254BB30E715FF037C80
        DA1AE832EA64B3D86EA46560A6066D964D53D80B30042DA84303364072846514
        C6610F34A1CA3BB984FE336168DE3F513A5183BA6B50CA9BE2E61544F3342CE3
        0F433F483EB3AC73A2F7E8FFE25F81DF93B674653BC155290000000049454E44
        AE426082}
      Rounded = True
      Transparent = True
      TabOrder = 0
      OnClick = AdvGlowButton1Click
      Appearance.BorderColor = 4663573
      Appearance.BorderColorHot = 4663573
      Appearance.BorderColorCheckedHot = 4663573
      Appearance.BorderColorDown = 4663573
      Appearance.BorderColorChecked = 4663573
      Appearance.BorderColorDisabled = 4663573
      Appearance.BorderColorFocused = 4663573
      Appearance.Color = 4663573
      Appearance.ColorTo = 4663573
      Appearance.ColorChecked = 4663573
      Appearance.ColorCheckedTo = 4663573
      Appearance.ColorDisabled = 4663573
      Appearance.ColorDisabledTo = 4663573
      Appearance.ColorDown = 4663573
      Appearance.ColorDownTo = 4663573
      Appearance.ColorHot = 4663573
      Appearance.ColorHotTo = 4663573
      Appearance.ColorMirror = 4663573
      Appearance.ColorMirrorTo = 4663573
      Appearance.ColorMirrorHot = 4663573
      Appearance.ColorMirrorHotTo = 4663573
      Appearance.ColorMirrorDown = 4663573
      Appearance.ColorMirrorDownTo = 4663573
      Appearance.ColorMirrorChecked = 4663573
      Appearance.ColorMirrorCheckedTo = 4663573
      Appearance.ColorMirrorDisabled = 4663573
      Appearance.ColorMirrorDisabledTo = 4663573
      Appearance.GradientHot = ggVertical
      Appearance.GradientMirrorHot = ggVertical
      Appearance.GradientDown = ggVertical
      Appearance.GradientMirrorDown = ggVertical
      Appearance.GradientChecked = ggVertical
      Appearance.TextColorChecked = clWhite
      Appearance.TextColorDown = clWhite
      Appearance.TextColorHot = clWhite
      ExplicitLeft = 2
    end
    object AdvGlowButton2: TAdvGlowButton
      Left = 104
      Top = 0
      Width = 78
      Height = 30
      Align = alRight
      Caption = 'Liberar'
      Font.Charset = DEFAULT_CHARSET
      Font.Color = clWhite
      Font.Height = -11
      Font.Name = 'Tahoma'
      Font.Style = []
      NotesFont.Charset = DEFAULT_CHARSET
      NotesFont.Color = clWindowText
      NotesFont.Height = -11
      NotesFont.Name = 'Tahoma'
      NotesFont.Style = []
      ParentFont = False
      Picture.Data = {
        89504E470D0A1A0A0000000D494844520000001C0000001C0806000000720DDF
        9400000006624B474400FF00FF00FFA0BDA7930000024949444154480DED964F
        48155114C6EF3C10828ADC2598100681E2BF1082162D4C0917698895ABDCB694
        04DB866EA54551BB70DFA68522619410B4548470A5F8E7ED0C41857886686FFC
        7DBE39305CDF9B19EB411B87F39BEF9E73BF73EE7BF31CD0B9F3ABCA4F2038CB
        BC300C6BF1DF83EBAE746D3AE7E68320D843AB171CD4006F601FFC504D7B0DFF
        74225373D0095370008A3CB77178103181E641218FBCEAC9653E9C4E7DDA1DB4
        0016CB2C86A1C61FA41A684F1E9627A15ECD78EDFB4FE5D8DF81E207B7F7D007
        A9BFB53CA06FAE1EF592866F4F1DE01770BD0245BBBF9735A7F9162826FD9E72
        CFBA1099AE449A49981E9F551B35D9AC28752E6EB2E2A62B5D374A927EE7B046
        5C2BE800AA502EDDD02D4E2E9E44EBB5486F469A281C720DC31CE8030A96CE7A
        D79524C280CB7004DFCCC8FA02DCB6DC945A3DAC82E245ACFE9DC2215CB45AA2
        625C02BDD0270DAC3F82F21E6B24AF875550C40FBB44E1372C9A3755318F8362
        50661677E117E8E5EE431B210F4578268F41FE08142FAD96AAB89B41C33E9999
        FC3EE85B16D075508CD9BE29C539284293D532290D5F418D6DD640DE033A1009
        CB1DA6F74F3D9FAD27B332B11B145FB805D6C8BA0B9E5B6E4A2D8079507459FD
        4C4AE72C2846D31A318D806226CD5B719FEE3AF8090770A79291BD0ED05FE616
        7AB5922F539D01BDF00776A1D36FA2A6DF6D1B95A7D7DFFFAB9C61C370043AF4
        B10D21EF07D5B4F7D4EA5551060F4101141FB84D4111547B529543FC210C6F85
        45B05860D1E2FB92F22069B3DC1E07A8E7217B214CF30F9494E579FCA727700C
        59F197B70A916C0B0000000049454E44AE426082}
      Rounded = True
      Transparent = True
      TabOrder = 1
      OnClick = AdvGlowButton2Click
      Appearance.BorderColor = 4663573
      Appearance.BorderColorHot = 4663573
      Appearance.BorderColorCheckedHot = 4663573
      Appearance.BorderColorDown = 4663573
      Appearance.BorderColorChecked = 4663573
      Appearance.BorderColorDisabled = 4663573
      Appearance.BorderColorFocused = 4663573
      Appearance.Color = 4663573
      Appearance.ColorTo = 4663573
      Appearance.ColorChecked = 4663573
      Appearance.ColorCheckedTo = 4663573
      Appearance.ColorDisabled = 4663573
      Appearance.ColorDisabledTo = 4663573
      Appearance.ColorDown = 4663573
      Appearance.ColorDownTo = 4663573
      Appearance.ColorHot = 4663573
      Appearance.ColorHotTo = 4663573
      Appearance.ColorMirror = 4663573
      Appearance.ColorMirrorTo = 4663573
      Appearance.ColorMirrorHot = 4663573
      Appearance.ColorMirrorHotTo = 4663573
      Appearance.ColorMirrorDown = 4663573
      Appearance.ColorMirrorDownTo = 4663573
      Appearance.ColorMirrorChecked = 4663573
      Appearance.ColorMirrorCheckedTo = 4663573
      Appearance.ColorMirrorDisabled = 4663573
      Appearance.ColorMirrorDisabledTo = 4663573
      Appearance.GradientHot = ggVertical
      Appearance.GradientMirrorHot = ggVertical
      Appearance.GradientDown = ggVertical
      Appearance.GradientMirrorDown = ggVertical
      Appearance.GradientChecked = ggVertical
      Appearance.TextColorChecked = clWhite
      Appearance.TextColorDown = clWhite
      Appearance.TextColorHot = clWhite
      ExplicitLeft = 102
    end
  end
  object IdTCPClient1: TIdTCPClient
    ConnectTimeout = 3000
    Host = '192.168.200.1'
    Port = 5432
    ReadTimeout = -1
    Left = 368
    Top = 80
  end
end
