object FrmOpcoesManifestar: TFrmOpcoesManifestar
  Left = 0
  Top = 0
  BorderStyle = bsDialog
  Caption = 'Manifestar'
  ClientHeight = 220
  ClientWidth = 306
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'Tahoma'
  Font.Style = []
  OldCreateOrder = False
  Position = poScreenCenter
  OnClose = FormClose
  PixelsPerInch = 96
  TextHeight = 13
  object RadioGroup1: TRadioGroup
    Left = 8
    Top = 8
    Width = 289
    Height = 129
    ItemIndex = 0
    Items.Strings = (
      'Confirma'#231#227'o de opera'#231#227'o'
      'Ci'#234'ncia da opera'#231#227'o'
      'Opera'#231#227'o n'#227'o realizada'
      'Desconhecimento da opera'#231#227'o')
    TabOrder = 0
    OnClick = RadioGroup1Click
  end
  object Button1: TButton
    Left = 8
    Top = 188
    Width = 75
    Height = 25
    Caption = 'Manifestar'
    ModalResult = 1
    TabOrder = 1
  end
  object Button2: TButton
    Left = 89
    Top = 188
    Width = 75
    Height = 25
    Caption = 'Cancelar'
    ModalResult = 2
    TabOrder = 2
  end
  object gbxMotivo: TGroupBox
    Left = 8
    Top = 137
    Width = 290
    Height = 45
    Caption = 'Motivo'
    TabOrder = 3
    Visible = False
    object edMotivo: TEdit
      Left = 3
      Top = 17
      Width = 279
      Height = 21
      TabOrder = 0
    end
  end
end
