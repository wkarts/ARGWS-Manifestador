unit UfrmEnviarXMLContabilidade;

interface

uses
  Winapi.Windows, Winapi.Messages, System.SysUtils, System.Variants, System.Classes, Vcl.Graphics,
  Vcl.Controls, Vcl.Forms, Vcl.Dialogs, Vcl.StdCtrls, Vcl.ComCtrls, Data.DB,
  Vcl.Grids, Vcl.DBGrids, DateUtils,
  Vcl.Buttons, FireDAC.Stan.Intf, FireDAC.Stan.Option, FireDAC.Stan.Param,
  FireDAC.Stan.Error, FireDAC.DatS, FireDAC.Phys.Intf, FireDAC.DApt.Intf,
  FireDAC.Stan.Async, FireDAC.DApt, FireDAC.Comp.DataSet, FireDAC.Comp.Client,
  MemDS, DBAccess, Uni;

type
  TfrmEnviarXMLContabilidade = class(TForm)
    gbxPeriodo: TGroupBox;
    edIni: TDateTimePicker;
    edFim: TDateTimePicker;
    GroupBox1: TGroupBox;
    edEmail: TEdit;
    Label1: TLabel;
    Label2: TLabel;
    Label3: TLabel;
    gbxNotasFiscais: TGroupBox;
    DBGrid1: TDBGrid;
    dsNF: TDataSource;
    btnEnviar: TBitBtn;
    btnCancelar: TBitBtn;
    ZQueryNF: TUniQuery;
    ZQueryNFCODIGO: TIntegerField;
    ZQueryNFID_EMPRESA: TIntegerField;
    ZQueryNFNUMERO: TStringField;
    ZQueryNFSERIE: TStringField;
    ZQueryNFCNPJ: TStringField;
    ZQueryNFNOME: TStringField;
    ZQueryNFEMISSAO: TDateTimeField;
    ZQueryNFVALOR: TFloatField;
    ZQueryNFTIPO: TStringField;
    ZQueryNFSITUACAO: TStringField;
    ZQueryNFCHAVE: TStringField;
    ZQueryNFIE: TStringField;
    ZQueryNFPROTOCOLO: TStringField;
    ZQueryNFDATAREC: TDateTimeField;
    ZQueryNFMANIFESTACAO: TStringField;
    ZQueryNFDOWNLOAD: TStringField;
    ZQueryNFAMBIENTE: TStringField;
    ZQueryNFNSU: TStringField;
    ZQueryNFVISIVEL: TStringField;
    ZQueryNFTOTAL_PRODUTOS: TFloatField;
    ZQueryNFVALOR_FRETE: TFloatField;
    ZQueryNFVALOR_DESPESAS: TFloatField;
    ZQueryNFVALOR_DESCONTO: TFloatField;
    ZQueryNFVALOR_IPI: TFloatField;
    ZQueryNFVALOR_ICMS: TFloatField;
    ZQueryNFVALOR_ICMSST: TFloatField;
    ZQueryNFENDERECO: TStringField;
    ZQueryNFENDERECO_NUMERO: TStringField;
    ZQueryNFENDERECO_COMPLEMENTO: TStringField;
    ZQueryNFENDERECO_BAIRRO: TStringField;
    ZQueryNFENDERECO_CEP: TStringField;
    ZQueryNFENDERECO_CIDADE: TStringField;
    ZQueryNFENDERECO_CODMUNICIPIO: TStringField;
    ZQueryNFTELEFONE: TStringField;
    procedure FormCreate(Sender: TObject);
    procedure edIniChange(Sender: TObject);
    procedure btnEnviarClick(Sender: TObject);
    procedure ZQueryNFNewRecord(DataSet: TDataSet);
    procedure ZQueryNFBeforeCancel(DataSet: TDataSet);
    procedure ZQueryNFAfterPost(DataSet: TDataSet);
  private

    { Private declarations }
    procedure ListarNotas;

  public

    { Public declarations }
    procedure Enviar;

  end;

var
  frmEnviarXMLContabilidade: TfrmEnviarXMLContabilidade;

implementation

{$R *.dfm}

uses UDMManifestador, uIdGenerator;

procedure TfrmEnviarXMLContabilidade.FormCreate(Sender: TObject);
begin

  edIni.Date := Date;
  edFim.Date := Date;

  if MonthOf(Date) = 1 then
  begin

    edIni.Date := StrToDate('01/12/'+ IntToStr(YearOf(Date) - 1));
    edFim.Date := StrToDate('31/12/'+ IntToStr(YearOf(Date) - 1));

  end
  else
  begin

    edIni.Date := StrToDate('01/'+ IntToStr(MonthOf(Date)-1) + '/' + IntToStr(YearOf(Date) ));
    edFim.Date := StrToDate('01/'+ IntToStr(MonthOf(Date)) + '/' + IntToStr(YearOf(Date) ))-1;

  end;

  ListarNotas;

end;

procedure TfrmEnviarXMLContabilidade.btnEnviarClick(Sender: TObject);
begin

  if (ZQueryNF.RecordCount = 0) then
    raise Exception.Create('N�o existem notas fiscais no per�odo selecionado!');


  if (edEmail.Text = '') then
  begin

    edEmail.SetFocus;
    raise Exception.Create('Digite o endere�o de email do destinat�rio!');

  end;

  if (DMManifestador.ZQueryCFGSMTP.Text = '') or (DMManifestador.ZQueryCFGSMTP_CONTA.AsString = '') or
     (DMManifestador.ZQueryCFGSMTP_REMETENTE.Text = '') or (DMManifestador.ZQueryCFGSMTP_EMAIL.AsString = '') or
     (DMManifestador.ZQueryCFGSMTP_SENHA.Text = '') or (DMManifestador.ZQueryCFGSMTP_PORTA.AsInteger = 0) then
    raise Exception.Create('N�o foram encontradas as configura��es do servidor de email!');

  Enviar;

end;

procedure TfrmEnviarXMLContabilidade.edIniChange(Sender: TObject);
begin

  if (ZQueryNF.Active) then
    ListarNotas;

end;

procedure TfrmEnviarXMLContabilidade.ListarNotas;
begin

  ZQueryNF.Close;
  zQueryNF.ParamByName('ID_EMPRESA').AsInteger := DMManifestador.ZQueryEMPRESACODIGO.AsInteger;
  zQueryNF.ParamByName('INICIO').AsDate := edIni.Date;
  zQueryNF.ParamByName('FIM').AsDate := edFim.Date;
  ZQueryNF.Open;

end;

procedure TfrmEnviarXMLContabilidade.ZQueryNFAfterPost(DataSet: TDataSet);
begin
  GeneratorBuilder(TGenConfirm, DataSet, (DataSet as TUniQuery).Connection);
end;

procedure TfrmEnviarXMLContabilidade.ZQueryNFBeforeCancel(DataSet: TDataSet);
begin
  GeneratorBuilder(TGenCancel, DataSet, (DataSet as TUniQuery).Connection);
end;

procedure TfrmEnviarXMLContabilidade.ZQueryNFNewRecord(DataSet: TDataSet);
begin
  GeneratorBuilder(TGenInsert, DataSet, (DataSet as TUniQuery).Connection);
end;

procedure TfrmEnviarXMLContabilidade.Enviar;
var
  Arquivos: TStringList;
  Arquivo: string;
  ArquivoZip: string;
begin

  Screen.Cursor := crHourGlass;
  Arquivos := TStringList.Create;

  try

    try

      with ZQueryNF do
      begin

        DisableControls;
        First;

        while not Eof do
        begin

          Arquivo := ExtractFilePath(Application.ExeName) +
                     'NotasFornecedores\' +
                     DMManifestador.ZQueryEMPRESACNPJ.AsString + '\' +
                     ZQueryNFCHAVE.AsString + '-nfe.xml';

          if FileExists(Arquivo) then
            Arquivos.Add(Arquivo);

          Next;

        end;

        First;
        EnableControls;

        if (Arquivos.Count > 0) then
        begin

          ArquivoZip := ExtractFilePath(Application.ExeName) +
                       'NotasFornecedores\' +
                        DMManifestador.ZQueryEMPRESACNPJ.AsString + '\NotasFiscais.zip';
          DMManifestador.GerarZip(ArquivoZip,
                                  Arquivos);
          DMManifestador.ConfigurarAcbrMail;
          DMManifestador.ACBrMail1.AddAddress(edEmail.Text);
          DMManifestador.ACBrMail1.AddAttachment(ArquivoZip);
          DMManifestador.ACBrMail1.Send;
          Application.MessageBox('Email enviado com sucesso!', 'Manifestador', MB_OK + MB_ICONINFORMATION);

        end;

      end;

    except

      on E:Exception do
      begin

        raise Exception.Create('TfrmEnviarXMLContabilidade.Enviar -> '+ E.Message);

      end;

    end;

  finally

    Screen.Cursor := crDefault;
    Arquivos.Free;

  end;

end;

end.
