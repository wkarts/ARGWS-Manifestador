object DMManifestador: TDMManifestador
  OnCreate = DataModuleCreate
  Height = 390
  Width = 687
  object ACBrNFe: TACBrNFe
    MAIL = ACBrMail1
    Configuracoes.Geral.SSLLib = libCustom
    Configuracoes.Geral.SSLCryptLib = cryWinCrypt
    Configuracoes.Geral.SSLHttpLib = httpWinHttp
    Configuracoes.Geral.SSLXmlSignLib = xsNone
    Configuracoes.Geral.FormatoAlerta = 'TAG:%TAGNIVEL% ID:%ID%/%TAG%(%DESCRICAO%) - %MSG%.'
    Configuracoes.Arquivos.OrdenacaoPath = <>
    Configuracoes.WebServices.UF = 'BA'
    Configuracoes.WebServices.AguardarConsultaRet = 0
    Configuracoes.WebServices.QuebradeLinha = '|'
    Configuracoes.RespTec.IdCSRT = 0
    Left = 392
    Top = 32
  end
  object ACBrNFeDANFeRL1: TACBrNFeDANFeRL
    Sistema = 'Projeto ACBr - www.projetoacbr.com.br'
    MargemInferior = 0.700000000000000000
    MargemSuperior = 0.700000000000000000
    MargemEsquerda = 0.700000000000000000
    MargemDireita = 0.700000000000000000
    ExpandeLogoMarcaConfig.Altura = 0
    ExpandeLogoMarcaConfig.Esquerda = 0
    ExpandeLogoMarcaConfig.Topo = 0
    ExpandeLogoMarcaConfig.Largura = 0
    ExpandeLogoMarcaConfig.Dimensionar = False
    ExpandeLogoMarcaConfig.Esticar = True
    CasasDecimais.Formato = tdetInteger
    CasasDecimais.qCom = 2
    CasasDecimais.vUnCom = 2
    CasasDecimais.MaskqCom = ',0.00'
    CasasDecimais.MaskvUnCom = ',0.00'
    CasasDecimais.Aliquota = 2
    CasasDecimais.MaskAliquota = ',0.00'
    ACBrNFe = ACBrNFeImprimir
    ExibeCampoFatura = False
    Left = 496
    Top = 32
  end
  object XMLDocument1: TXMLDocument
    Left = 611
    Top = 32
  end
  object ACBrNFeImprimir: TACBrNFe
    MAIL = ACBrMail1
    Configuracoes.Geral.SSLLib = libNone
    Configuracoes.Geral.SSLCryptLib = cryNone
    Configuracoes.Geral.SSLHttpLib = httpNone
    Configuracoes.Geral.SSLXmlSignLib = xsNone
    Configuracoes.Geral.FormatoAlerta = 'TAG:%TAGNIVEL% ID:%ID%/%TAG%(%DESCRICAO%) - %MSG%.'
    Configuracoes.Geral.VersaoQRCode = veqr000
    Configuracoes.Arquivos.OrdenacaoPath = <>
    Configuracoes.WebServices.UF = 'SP'
    Configuracoes.WebServices.AguardarConsultaRet = 0
    Configuracoes.WebServices.QuebradeLinha = '|'
    Configuracoes.RespTec.IdCSRT = 0
    DANFE = ACBrNFeDANFeRL1
    Left = 400
    Top = 104
  end
  object SaveDialogPDF: TSaveDialog
    Filter = 'Arquivos PDF|*.PDF'
    Left = 498
    Top = 104
  end
  object TimerVerificar: TTimer
    Enabled = False
    OnTimer = TimerVerificarTimer
    Left = 611
    Top = 104
  end
  object ACBrMail1: TACBrMail
    Host = '127.0.0.1'
    Port = '25'
    SetSSL = False
    SetTLS = False
    Attempts = 3
    DefaultCharset = UTF_8
    IDECharset = CP1252
    Left = 616
    Top = 167
  end
  object FDConnection1: TUniConnection
    ProviderName = 'InterBase'
    Port = 3050
    Database = 'C:\Manifesto\Dados\MANIFESTO30.FDB'
    SpecificOptions.Strings = (
      
        'InterBase.ClientLibrary=C:\Program Files (x86)\Firebird\Firebird' +
        '_3_0\fbclient.dll'
      'InterBase.IPVersion=ivIPv4'
      'InterBase.Charset=NONE')
    Options.KeepDesignConnected = False
    DefaultTransaction = Transaction
    Username = 'SYSDBA'
    Server = '127.0.0.1'
    LoginPrompt = False
    AfterConnect = FDConnection1AfterConnect
    BeforeConnect = FDConnection1BeforeConnect
    AfterDisconnect = FDConnection1AfterDisconnect
    Left = 32
    Top = 32
    EncryptedPassword = '92FF9EFF8CFF8BFF9AFF8DFF94FF9AFF86FF'
  end
  object FDGUIxWaitCursor1: TFDGUIxWaitCursor
    Provider = 'Forms'
    Left = 400
    Top = 224
  end
  object ZQueryCFG: TUniQuery
    Connection = FDConnection1
    Transaction = Transaction
    SQL.Strings = (
      'SELECT * '
      '  FROM CFG')
    AfterPost = ZQueryCFGAfterPost
    BeforeCancel = ZQueryCFGBeforeCancel
    OnNewRecord = ZQueryCFGNewRecord
    Left = 32
    Top = 104
    object ZQueryCFGCODIGO: TIntegerField
      FieldName = 'CODIGO'
      Required = True
    end
    object ZQueryCFGVERIFICAR_AUTOMATICO: TStringField
      FieldName = 'VERIFICAR_AUTOMATICO'
      Required = True
      Size = 1
    end
    object ZQueryCFGDOWNLOAD_AUTOMATICO: TStringField
      FieldName = 'DOWNLOAD_AUTOMATICO'
      Required = True
      Size = 1
    end
    object ZQueryCFGTIMER: TIntegerField
      FieldName = 'TIMER'
      Required = True
    end
    object ZQueryCFGSMTP: TStringField
      FieldName = 'SMTP'
      Size = 200
    end
    object ZQueryCFGSMTP_CONTA: TStringField
      FieldName = 'SMTP_CONTA'
      Size = 200
    end
    object ZQueryCFGSMTP_REMETENTE: TStringField
      FieldName = 'SMTP_REMETENTE'
      Size = 200
    end
    object ZQueryCFGSMTP_EMAIL: TStringField
      FieldName = 'SMTP_EMAIL'
      Size = 200
    end
    object ZQueryCFGSMTP_SENHA: TStringField
      FieldName = 'SMTP_SENHA'
      Size = 200
    end
    object ZQueryCFGSMTP_PORTA: TStringField
      FieldName = 'SMTP_PORTA'
      Size = 10
    end
  end
  object ZQueryNF: TUniQuery
    Connection = FDConnection1
    Transaction = Transaction
    SQL.Strings = (
      'SELECT *'
      '  FROM NF'
      'WHERE ID_EMPRESA = :ID_EMPRESA'
      '   AND EMISSAO BETWEEN :INICIO AND :FIM'
      '   AND (MANIFESTACAO = :MANIFESTACAO OR :MANIFESTACAO = '#39'T'#39')'
      '   AND (DOWNLOAD = :DOWNLOAD OR :DOWNLOAD = '#39'T'#39')'
      '   AND VISIVEL = '#39'S'#39
      '   AND CHAVE<>'#39'Chave de acesso'#39)
    AfterOpen = ZQueryNFAfterOpen
    AfterPost = ZQueryNFAfterPost
    BeforeCancel = ZQueryNFBeforeCancel
    AfterScroll = ZQueryNFAfterScroll
    OnNewRecord = zQueryNFNewRecord
    Left = 120
    Top = 104
    ParamData = <
      item
        DataType = ftString
        Name = 'ID_EMPRESA'
        ParamType = ptInput
        Value = nil
      end
      item
        DataType = ftString
        Name = 'INICIO'
        ParamType = ptInput
        Value = nil
      end
      item
        DataType = ftString
        Name = 'FIM'
        ParamType = ptInput
        Value = nil
      end
      item
        DataType = ftString
        Name = 'MANIFESTACAO'
        ParamType = ptInput
        Value = nil
      end
      item
        DataType = ftString
        Name = 'DOWNLOAD'
        ParamType = ptInput
        Value = nil
      end>
    object ZQueryNFCODIGO: TIntegerField
      FieldName = 'CODIGO'
      Required = True
    end
    object ZQueryNFID_EMPRESA: TIntegerField
      FieldName = 'ID_EMPRESA'
      Required = True
    end
    object ZQueryNFNUMERO: TStringField
      FieldName = 'NUMERO'
      Required = True
    end
    object ZQueryNFSERIE: TStringField
      FieldName = 'SERIE'
      Required = True
    end
    object ZQueryNFCNPJ: TStringField
      FieldName = 'CNPJ'
      Required = True
    end
    object ZQueryNFNOME: TStringField
      FieldName = 'NOME'
      Required = True
      Size = 200
    end
    object ZQueryNFEMISSAO: TDateTimeField
      FieldName = 'EMISSAO'
      Required = True
    end
    object ZQueryNFVALOR: TFloatField
      FieldName = 'VALOR'
      Required = True
    end
    object ZQueryNFTIPO: TStringField
      FieldName = 'TIPO'
      Required = True
    end
    object ZQueryNFSITUACAO: TStringField
      FieldName = 'SITUACAO'
      Required = True
      Size = 200
    end
    object ZQueryNFCHAVE: TStringField
      FieldName = 'CHAVE'
      Required = True
      Size = 200
    end
    object ZQueryNFIE: TStringField
      FieldName = 'IE'
      Required = True
    end
    object ZQueryNFPROTOCOLO: TStringField
      FieldName = 'PROTOCOLO'
      Required = True
      Size = 200
    end
    object ZQueryNFDATAREC: TDateTimeField
      FieldName = 'DATAREC'
      Required = True
    end
    object ZQueryNFMANIFESTACAO: TStringField
      FieldName = 'MANIFESTACAO'
      Required = True
      Size = 1
    end
    object ZQueryNFDOWNLOAD: TStringField
      FieldName = 'DOWNLOAD'
      Required = True
      Size = 1
    end
    object ZQueryNFAMBIENTE: TStringField
      FieldName = 'AMBIENTE'
      Required = True
      Size = 1
    end
    object ZQueryNFNSU: TStringField
      FieldName = 'NSU'
      Required = True
      Size = 30
    end
    object ZQueryNFVISIVEL: TStringField
      FieldName = 'VISIVEL'
      Required = True
      Size = 1
    end
    object ZQueryNFTOTAL_PRODUTOS: TFloatField
      FieldName = 'TOTAL_PRODUTOS'
    end
    object ZQueryNFVALOR_FRETE: TFloatField
      FieldName = 'VALOR_FRETE'
    end
    object ZQueryNFVALOR_DESPESAS: TFloatField
      FieldName = 'VALOR_DESPESAS'
    end
    object ZQueryNFVALOR_DESCONTO: TFloatField
      FieldName = 'VALOR_DESCONTO'
    end
    object ZQueryNFVALOR_IPI: TFloatField
      FieldName = 'VALOR_IPI'
    end
    object ZQueryNFVALOR_ICMS: TFloatField
      FieldName = 'VALOR_ICMS'
    end
    object ZQueryNFVALOR_ICMSST: TFloatField
      FieldName = 'VALOR_ICMSST'
    end
    object ZQueryNFENDERECO: TStringField
      FieldName = 'ENDERECO'
      Size = 200
    end
    object ZQueryNFENDERECO_NUMERO: TStringField
      FieldName = 'ENDERECO_NUMERO'
      Size = 30
    end
    object ZQueryNFENDERECO_COMPLEMENTO: TStringField
      FieldName = 'ENDERECO_COMPLEMENTO'
      Size = 200
    end
    object ZQueryNFENDERECO_BAIRRO: TStringField
      FieldName = 'ENDERECO_BAIRRO'
      Size = 200
    end
    object ZQueryNFENDERECO_CEP: TStringField
      FieldName = 'ENDERECO_CEP'
      Size = 200
    end
    object ZQueryNFENDERECO_CIDADE: TStringField
      FieldName = 'ENDERECO_CIDADE'
      Size = 200
    end
    object ZQueryNFENDERECO_CODMUNICIPIO: TStringField
      FieldName = 'ENDERECO_CODMUNICIPIO'
      Size = 30
    end
    object ZQueryNFTELEFONE: TStringField
      FieldName = 'TELEFONE'
      Size = 30
    end
    object ZQueryNFXML: TBlobField
      FieldName = 'XML'
    end
    object ZQueryNFXML_PATH: TStringField
      FieldName = 'XML_PATH'
      Size = 600
    end
  end
  object ZQueryExisteNota: TUniQuery
    Connection = FDConnection1
    Transaction = Transaction
    SQL.Strings = (
      'SELECT COUNT(*) TOTAL'
      '  FROM NF'
      ' WHERE CHAVE = :CHAVE')
    AfterPost = ZQueryExisteNotaAfterPost
    BeforeCancel = ZQueryExisteNotaBeforeCancel
    OnNewRecord = ZQueryExisteNotaNewRecord
    Left = 208
    Top = 104
    ParamData = <
      item
        DataType = ftString
        Name = 'CHAVE'
        ParamType = ptInput
        Value = nil
      end>
  end
  object ZQueryNSU: TUniQuery
    Connection = FDConnection1
    Transaction = Transaction
    SQL.Strings = (
      'SELECT MAX(NSU)  NSU'
      ' FROM NF        '
      ' WHERE ID_EMPRESA= :ID_EMPRESA'
      '   AND AMBIENTE = :AMBIENTE')
    AfterPost = ZQueryNSUAfterPost
    BeforeCancel = ZQueryNSUBeforeCancel
    OnNewRecord = ZQueryNSUNewRecord
    Left = 208
    Top = 168
    ParamData = <
      item
        DataType = ftString
        Name = 'ID_EMPRESA'
        ParamType = ptInput
        Value = nil
      end
      item
        DataType = ftString
        Name = 'AMBIENTE'
        ParamType = ptInput
        Value = nil
      end>
  end
  object ZQueryEmpresa: TUniQuery
    Connection = FDConnection1
    Transaction = Transaction
    SQL.Strings = (
      'SELECT *'
      '  FROM EMPRESA')
    AfterPost = ZQueryEmpresaAfterPost
    BeforeCancel = ZQueryEmpresaBeforeCancel
    OnNewRecord = ZQueryEmpresaNewRecord
    Left = 32
    Top = 168
    object ZQueryEmpresaCODIGO: TIntegerField
      FieldName = 'CODIGO'
      Required = True
    end
    object ZQueryEmpresaCNPJ: TStringField
      FieldName = 'CNPJ'
      Required = True
    end
    object ZQueryEmpresaCERTIFICADO: TStringField
      FieldName = 'CERTIFICADO'
      Size = 200
    end
    object ZQueryEmpresaSENHA: TStringField
      FieldName = 'SENHA'
      Size = 200
    end
    object ZQueryEmpresaUF: TStringField
      FieldName = 'UF'
    end
    object ZQueryEmpresaCAMINHO: TStringField
      FieldName = 'CAMINHO'
      Size = 200
    end
    object ZQueryEmpresaNOME: TStringField
      FieldName = 'NOME'
      Size = 200
    end
    object ZQueryEmpresaNUMERO_SERIE: TStringField
      FieldName = 'NUMERO_SERIE'
      Size = 200
    end
    object ZQueryEmpresaCAMINHO_COPIA_XML: TStringField
      FieldName = 'CAMINHO_COPIA_XML'
      Size = 600
    end
    object ZQueryEmpresaCAMINHO_RESPONSE: TStringField
      FieldName = 'CAMINHO_RESPONSE'
      Size = 600
    end
    object ZQueryEmpresaDATA_MANIFESTACAO: TDateTimeField
      FieldName = 'DATA_MANIFESTACAO'
    end
  end
  object ZQueryNF_LOG: TUniQuery
    Connection = FDConnection1
    Transaction = Transaction
    SQL.Strings = (
      'SELECT CODIGO,'
      '       ID_NF,'
      '       OPERACAO,'
      '       DATAHORA,'
      '       HISTORICO'
      '  FROM NF_LOG'
      ' WHERE ID_NF = :ID_NF')
    BeforeOpen = ZQueryNF_LOGBeforeOpen
    AfterPost = ZQueryNF_LOGAfterPost
    BeforeCancel = ZQueryNF_LOGBeforeCancel
    OnNewRecord = ZQueryNF_LOGNewRecord
    Left = 120
    Top = 168
    ParamData = <
      item
        DataType = ftString
        Name = 'ID_NF'
        ParamType = ptInput
        Value = nil
      end>
    object ZQueryNF_LOGCODIGO: TIntegerField
      FieldName = 'CODIGO'
      Required = True
    end
    object ZQueryNF_LOGID_NF: TIntegerField
      FieldName = 'ID_NF'
      Required = True
    end
    object ZQueryNF_LOGOPERACAO: TIntegerField
      FieldName = 'OPERACAO'
      Required = True
    end
    object ZQueryNF_LOGDATAHORA: TDateTimeField
      FieldName = 'DATAHORA'
      Required = True
    end
    object ZQueryNF_LOGHISTORICO: TStringField
      FieldName = 'HISTORICO'
      Required = True
      Size = 200
    end
  end
  object Firebird: TInterBaseUniProvider
    Left = 128
    Top = 32
  end
  object Transaction: TUniTransaction
    DefaultConnection = FDConnection1
    Left = 208
    Top = 32
  end
  object ACBrPosPrinter: TACBrPosPrinter
    ConfigBarras.MostrarCodigo = False
    ConfigBarras.LarguraLinha = 0
    ConfigBarras.Altura = 0
    ConfigBarras.Margem = 0
    ConfigQRCode.Tipo = 2
    ConfigQRCode.LarguraModulo = 4
    ConfigQRCode.ErrorLevel = 0
    LinhasEntreCupons = 0
    Left = 400
    Top = 167
  end
  object ACBrNFeDANFeESCPOS: TACBrNFeDANFeESCPOS
    Sistema = 'Projeto ACBr - www.projetoacbr.com.br'
    MargemInferior = 8.000000000000000000
    MargemSuperior = 8.000000000000000000
    MargemEsquerda = 6.000000000000000000
    MargemDireita = 5.100000000000000000
    ExpandeLogoMarcaConfig.Altura = 0
    ExpandeLogoMarcaConfig.Esquerda = 0
    ExpandeLogoMarcaConfig.Topo = 0
    ExpandeLogoMarcaConfig.Largura = 0
    ExpandeLogoMarcaConfig.Dimensionar = False
    ExpandeLogoMarcaConfig.Esticar = True
    CasasDecimais.Formato = tdetInteger
    CasasDecimais.qCom = 2
    CasasDecimais.vUnCom = 2
    CasasDecimais.MaskqCom = ',0.00'
    CasasDecimais.MaskvUnCom = ',0.00'
    CasasDecimais.Aliquota = 2
    CasasDecimais.MaskAliquota = ',0.00'
    Left = 515
    Top = 167
  end
end
